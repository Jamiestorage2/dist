KeyHunt Browser Miner - WordPress Plugin
========================================

This plugin allows website visitors to opt-in and contribute their browser's
computing power to help mine Bitcoin puzzle keys. Found keys are saved privately
to the database and emailed to the site admin - they are NOT shown to visitors.

FEATURES
========

- Opt-in only: Visitors must click "Start Helping" to begin
- Visible widget: Mining activity is clearly shown with progress
- Privacy: Found keys are saved privately, not displayed to finders
- Email alerts: Admin receives email immediately when key is found
- Statistics: Track total keys checked and active miners
- Configurable: Adjust threads, batch size, puzzle target

INSTALLATION
============

1. Upload the 'keyhunt-browser-miner' folder to your WordPress site:
   - Via FTP: Upload to /wp-content/plugins/
   - Via ZIP: Create a zip file and upload through WordPress admin
     (Plugins > Add New > Upload Plugin)

2. Activate the plugin in WordPress Admin > Plugins

3. Go to WordPress Admin > Browser Miner (or KeyHunt Sync > Browser Miner
   if the sync plugin is installed)

4. Configure settings:
   - Enable browser mining (checkbox)
   - Select puzzle number (71, 72, or 73)
   - Verify target address
   - Adjust threads and batch size


HOW IT WORKS
============

1. Widget appears in bottom-right corner of your site (after 2 seconds)

2. Visitors see:
   - Explanation of what they're helping with
   - Start button to opt-in
   - Live statistics (keys checked, active helpers)

3. When mining:
   - Web Workers run in background (won't freeze browser)
   - Progress bar shows current batch
   - "Pause" button to stop anytime

4. Results:
   - All scanned blocks saved to database
   - Statistics updated in real-time
   - If key found: saved privately, admin emailed
   - Visitor sees generic "success" - no key reveal


WIDGET CUSTOMIZATION
====================

From the admin settings page, you can customize:

- Widget Title: Headline text shown to visitors
- Widget Text: Description explaining the mining purpose

Example titles:
- "Help Solve Bitcoin Puzzle #71"
- "Contribute Computing Power"
- "Join Our Crypto Research"


SECURITY & PRIVACY
==================

For Visitors:
- IP addresses are hashed (not stored raw)
- User agents are hashed
- Session IDs are anonymous
- No personal data collected

For Found Keys:
- Stored only in database and backup log file
- Emailed only to WordPress admin
- Never displayed in widget or to visitors
- Log file: /wp-content/khbm_found_keys.log

For Your Site:
- Mining is CPU-intensive but runs in Web Workers
- Visitors can pause/stop anytime
- Widget can be closed


PERFORMANCE NOTES
=================

Browser mining is much slower than native CUDA mining:
- Native KeyHunt CUDA: ~1 billion+ keys/second
- Browser JavaScript: ~100-1000 keys/second per thread

However, with many visitors contributing, coverage adds up.
Best for supplemental coverage while native miners focus elsewhere.


TROUBLESHOOTING
===============

Widget not showing:
- Check "Enable Browser Mining" is checked in settings
- Verify you're viewing a frontend page (not admin)
- Check browser console for JavaScript errors

Mining not starting:
- Check REST API is accessible: /wp-json/khbm/v1/task
- Verify no CORS issues if using CDN

Low key counts:
- Increase batch_size for less server round-trips
- Increase threads (but be mindful of visitor CPU usage)
- Browser EC math is slow - this is expected

No email when key found (testing):
- Check WordPress mail configuration
- Verify admin_email setting
- Check backup log: /wp-content/khbm_found_keys.log


API ENDPOINTS
=============

GET  /wp-json/khbm/v1/task    - Get mining task
POST /wp-json/khbm/v1/submit  - Submit results
GET  /wp-json/khbm/v1/stats   - Get public stats


DATABASE TABLES
===============

{prefix}_khbm_scanned_blocks  - All scanned blocks
{prefix}_khbm_found_keys      - Found private keys (PRIVATE!)
{prefix}_khbm_miner_stats     - Daily statistics


SYNCING WITH KEYHUNT SYNC PLUGIN
================================

If you have both plugins installed, scanned blocks from browser miners
can be synced to your other KeyHunt instances via the Sync plugin.
The Browser Miner creates its own table, so manual export would be needed.


LEGAL NOTES
===========

This plugin enables opt-in computing contribution. Visitors must click
to start mining - it does not run automatically without consent.

Ensure your site's terms of service disclose the mining functionality.
