#!/usr/bin/env python3
"""
KeyHunt ULTIMATE GUI - Complete Edition
Features:
- GPU Key Mining (KeyHunt-Cuda)
- BIP39 Seed Attack (Multi-threaded, Word-Range Filtering)
- Weak Key Pattern Detection
- Progressive Search
- Checkpoint/Resume
- GPU Cooldown
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Pango
import subprocess
import threading
import os
import json
import time
from datetime import datetime, timedelta
import itertools
from queue import Queue

# Import our modules
try:
    from bip39_attack import BIP39Attack, COMMON_PATHS
    BIP39_AVAILABLE = True
except ImportError:
    BIP39_AVAILABLE = False
    print("Warning: BIP39 modules not available")

class KeyHuntUltimateGUI(Gtk.Window):
    """The ultimate cryptocurrency key recovery interface"""
    
    def __init__(self):
        super().__init__(title="KeyHunt ULTIMATE - Professional Key Recovery Suite")
        self.set_default_size(1400, 950)
        self.set_border_width(10)
        
        # State variables
        self.process = None
        self.is_running = False
        self.attack_type = "keyhunt"
        self.start_time = None
        self.keys_checked = 0
        self.matches_found = 0
        self.current_speed = 0
        
        # BIP39 state
        self.bip39_engine = None
        self.bip39_threads = []
        self.bip39_results = Queue()
        self.bip39_stop_flag = threading.Event()
        
        # Weak key detector state
        self.weak_key_patterns = []
        self.pattern_test_count = 0        
        # Attack mode radio buttons (set in create_control_buttons)
        self.auto_mode = None
        self.manual_gpu = None
        self.manual_bip39 = None

        
        # Initialize engines
        if BIP39_AVAILABLE:
            self.bip39_engine = BIP39Attack()
            if os.path.exists('bip39_wordlist.txt'):
                try:
                    self.bip39_engine.load_wordlist('bip39_wordlist.txt')
                except Exception as e:
                    print(f"Error loading wordlist: {e}")
        
        # Build UI
        self.build_ui()
        
        # Start update timer
        GLib.timeout_add(1000, self.update_status)
    
    def build_ui(self):
        """Build the complete user interface"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Header
        header = self.create_header()
        main_box.pack_start(header, False, False, 0)
        
        # Status bar
        status_frame = self.create_status_bar()
        main_box.pack_start(status_frame, False, False, 0)
        
        # Main notebook (tabs)
        notebook = Gtk.Notebook()
        notebook.set_tab_pos(Gtk.PositionType.TOP)
        main_box.pack_start(notebook, True, True, 0)
        
        # Tab 1: KeyHunt GPU Mining
        tab1 = self.create_keyhunt_tab()
        label1 = Gtk.Label(label="⚡ GPU Mining")
        notebook.append_page(tab1, label1)
        
        # Tab 2: BIP39 Seed Attack (Enhanced!)
        tab2 = self.create_bip39_tab()
        label2 = Gtk.Label(label="🔐 BIP39 Attack")
        notebook.append_page(tab2, label2)
        
        # Tab 3: Weak Key Pattern Detector (NEW!)
        tab3 = self.create_weak_key_tab()
        label3 = Gtk.Label(label="🎯 Weak Keys")
        notebook.append_page(tab3, label3)
        
        # Tab 4: Advanced Settings
        tab4 = self.create_advanced_tab()
        label4 = Gtk.Label(label="⚙️ Advanced")
        notebook.append_page(tab4, label4)
        
        # Tab 5: Console
        tab5 = self.create_console_tab()
        label5 = Gtk.Label(label="📝 Console")
        notebook.append_page(tab5, label5)
        
        # Tab 6: Results
        tab6 = self.create_results_tab()
        label6 = Gtk.Label(label="✅ Results")
        notebook.append_page(tab6, label6)
        
        # Control buttons
        control_box = self.create_control_buttons()
        main_box.pack_start(control_box, False, False, 10)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(True)
        self.progress_bar.set_text("Ready")
        main_box.pack_start(self.progress_bar, False, False, 0)
    
    def create_header(self):
        """Create header with logo and title"""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        title = Gtk.Label()
        title.set_markup("<span size='xx-large' weight='bold'>⚡ KEYHUNT ULTIMATE ⚡</span>")
        box.pack_start(title, False, False, 0)
        
        subtitle = Gtk.Label()
        subtitle.set_markup("<span size='small'>Professional Cryptocurrency Key Recovery Suite</span>")
        box.pack_start(subtitle, False, False, 0)
        
        features = Gtk.Label()
        features.set_markup("<span size='x-small'>GPU Mining • BIP39 Attack • Weak Key Detection • Multi-Threading • Pattern Analysis</span>")
        box.pack_start(features, False, False, 0)
        
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        box.pack_start(separator, False, False, 10)
        
        return box
    
    def create_status_bar(self):
        """Create live status display"""
        frame = Gtk.Frame()
        frame.set_label("Live Status")
        
        grid = Gtk.Grid()
        grid.set_column_homogeneous(True)
        grid.set_column_spacing(15)
        grid.set_row_spacing(5)
        grid.set_margin_start(10)
        grid.set_margin_end(10)
        grid.set_margin_top(10)
        grid.set_margin_bottom(10)
        frame.add(grid)
        
        # Status indicators
        labels = [
            ("Mode:", 0, 0), ("Speed:", 1, 0), ("Tested:", 2, 0),
            ("Found:", 3, 0), ("Runtime:", 4, 0), ("Progress:", 5, 0)
        ]
        
        self.status_labels = {}
        for label_text, col, row in labels:
            label = Gtk.Label(label=label_text)
            label.set_halign(Gtk.Align.START)
            grid.attach(label, col, row, 1, 1)
            
            value = Gtk.Label(label="--")
            value.set_markup("<b>--</b>")
            value.set_halign(Gtk.Align.START)
            grid.attach(value, col, row + 1, 1, 1)
            
            key = label_text.rstrip(':')
            self.status_labels[key] = value
        
        return frame
    
    def create_keyhunt_tab(self):
        """Create KeyHunt GPU mining configuration tab"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(15)
        box.set_margin_end(15)
        box.set_margin_top(15)
        scroll.add(box)
        
        # Info
        info = Gtk.Label()
        info.set_markup("<b>GPU-Accelerated Random Key Search</b>\n"
                       "Use your GPU to test millions of keys per second against target addresses.")
        info.set_line_wrap(True)
        box.pack_start(info, False, False, 10)
        
        # KeyHunt path
        frame = Gtk.Frame(label="KeyHunt Binary")
        hbox = Gtk.Box(spacing=10)
        hbox.set_margin_start(10)
        hbox.set_margin_end(10)
        hbox.set_margin_top(10)
        hbox.set_margin_bottom(10)
        
        hbox.pack_start(Gtk.Label(label="Path:"), False, False, 0)
        self.keyhunt_path = Gtk.Entry()
        self.keyhunt_path.set_text("./KeyHunt-Cuda")
        self.keyhunt_path.set_hexpand(True)
        hbox.pack_start(self.keyhunt_path, True, True, 0)
        
        browse_btn = Gtk.Button(label="Browse...")
        browse_btn.connect("clicked", self.on_browse_keyhunt)
        hbox.pack_start(browse_btn, False, False, 0)
        
        frame.add(hbox)
        box.pack_start(frame, False, False, 0)
        
        # GPU Settings
        gpu_frame = Gtk.Frame(label="GPU Configuration")
        gpu_grid = Gtk.Grid()
        gpu_grid.set_column_spacing(10)
        gpu_grid.set_row_spacing(5)
        gpu_grid.set_margin_start(10)
        gpu_grid.set_margin_end(10)
        gpu_grid.set_margin_top(10)
        gpu_grid.set_margin_bottom(10)
        
        # GPU ID
        gpu_grid.attach(Gtk.Label(label="GPU Device ID:"), 0, 0, 1, 1)
        self.gpu_id = Gtk.SpinButton()
        self.gpu_id.set_range(0, 10)
        self.gpu_id.set_increments(1, 1)
        self.gpu_id.set_value(0)
        gpu_grid.attach(self.gpu_id, 1, 0, 1, 1)
        
        # Grid size
        gpu_grid.attach(Gtk.Label(label="Grid Size (X × Y):"), 0, 1, 1, 1)
        grid_box = Gtk.Box(spacing=5)
        self.grid_x = Gtk.SpinButton()
        self.grid_x.set_range(1, 1024)
        self.grid_x.set_increments(16, 64)
        self.grid_x.set_value(256)
        grid_box.pack_start(self.grid_x, True, True, 0)
        grid_box.pack_start(Gtk.Label(label="×"), False, False, 0)
        self.grid_y = Gtk.SpinButton()
        self.grid_y.set_range(1, 1024)
        self.grid_y.set_increments(16, 64)
        self.grid_y.set_value(256)
        grid_box.pack_start(self.grid_y, True, True, 0)
        gpu_grid.attach(grid_box, 1, 1, 1, 1)
        
        gpu_frame.add(gpu_grid)
        box.pack_start(gpu_frame, False, False, 0)
        
        # Search range
        range_frame = Gtk.Frame(label="Key Range (Hexadecimal)")
        range_grid = Gtk.Grid()
        range_grid.set_column_spacing(10)
        range_grid.set_row_spacing(5)
        range_grid.set_margin_start(10)
        range_grid.set_margin_end(10)
        range_grid.set_margin_top(10)
        range_grid.set_margin_bottom(10)
        
        range_grid.attach(Gtk.Label(label="Start:"), 0, 0, 1, 1)
        self.range_start = Gtk.Entry()
        self.range_start.set_text("1")
        self.range_start.set_hexpand(True)
        range_grid.attach(self.range_start, 1, 0, 1, 1)
        
        range_grid.attach(Gtk.Label(label="End:"), 0, 1, 1, 1)
        self.range_end = Gtk.Entry()
        self.range_end.set_text("FFFFFFFFFFFFFFFF")
        self.range_end.set_hexpand(True)
        range_grid.attach(self.range_end, 1, 1, 1, 1)
        
        range_frame.add(range_grid)
        box.pack_start(range_frame, False, False, 0)
        
        # Target
        target_frame = Gtk.Frame(label="Target Addresses")
        target_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        target_box.set_margin_start(10)
        target_box.set_margin_end(10)
        target_box.set_margin_top(10)
        target_box.set_margin_bottom(10)
        
        hbox = Gtk.Box(spacing=10)
        hbox.pack_start(Gtk.Label(label="Address/File:"), False, False, 0)
        self.keyhunt_target = Gtk.Entry()
        self.keyhunt_target.set_placeholder_text("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa or path to addresses.bin")
        self.keyhunt_target.set_hexpand(True)
        hbox.pack_start(self.keyhunt_target, True, True, 0)
        
        browse_target = Gtk.Button(label="Browse...")
        browse_target.connect("clicked", self.on_browse_target)
        hbox.pack_start(browse_target, False, False, 0)
        target_box.pack_start(hbox, False, False, 0)
        
        target_frame.add(target_box)
        box.pack_start(target_frame, False, False, 0)
        
        return scroll
    
    def create_bip39_tab(self):
        """Create BIP39 seed attack tab with multi-threading and word-range filtering"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(15)
        box.set_margin_end(15)
        box.set_margin_top(15)
        scroll.add(box)
        
        # Info
        info = Gtk.Label()
        info.set_markup("<b>Advanced BIP39 Seed Phrase Recovery</b>\n"
                       "Multi-threaded attacks with word-range filtering and progressive narrowing.")
        info.set_line_wrap(True)
        
        # === BIP39 Wordlist Loader ===
        wordlist_frame = Gtk.Frame(label="📚 BIP39 Wordlist")
        wl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        wl_box.set_margin_start(10)
        wl_box.set_margin_end(10)
        wl_box.set_margin_top(10)
        wl_box.set_margin_bottom(10)
        
        hbox = Gtk.Box(spacing=10)
        hbox.pack_start(Gtk.Label(label="Wordlist:"), False, False, 0)
        self.bip39_wordlist_path = Gtk.Entry()
        self.bip39_wordlist_path.set_text("bip39_wordlist.txt")
        hbox.pack_start(self.bip39_wordlist_path, True, True, 0)
        
        btn_browse_wl = Gtk.Button(label="Browse")
        btn_browse_wl.connect("clicked", self.on_browse_wordlist)
        hbox.pack_start(btn_browse_wl, False, False, 0)
        
        btn_load_wl = Gtk.Button(label="Load")
        btn_load_wl.connect("clicked", self.on_load_wordlist)
        hbox.pack_start(btn_load_wl, False, False, 0)
        wl_box.pack_start(hbox, False, False, 0)
        
        self.wordlist_status = Gtk.Label()
        self.wordlist_status.set_markup("<i>Wordlist not loaded</i>")
        self.wordlist_status.set_halign(Gtk.Align.START)
        wl_box.pack_start(self.wordlist_status, False, False, 0)
        
        wordlist_frame.add(wl_box)
        box.pack_start(wordlist_frame, False, False, 0)
        # === End Wordlist Loader ===
        
        box.pack_start(info, False, False, 10)
        
        # Attack type
        attack_frame = Gtk.Frame(label="Attack Strategy")
        attack_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        attack_box.set_margin_start(10)
        attack_box.set_margin_end(10)
        attack_box.set_margin_top(10)
        attack_box.set_margin_bottom(10)
        
        self.bip39_attack_type = Gtk.ComboBoxText()
        self.bip39_attack_type.append_text("Last Word Attack (11 known words)")
        self.bip39_attack_type.append_text("Missing Words Attack (1-3 missing)")
        self.bip39_attack_type.append_text("Dictionary/Common Words")
        self.bip39_attack_type.set_active(0)
        attack_box.pack_start(self.bip39_attack_type, False, False, 0)
        
        attack_frame.add(attack_box)
        box.pack_start(attack_frame, False, False, 0)
        
        # Seed phrase input
        seed_frame = Gtk.Frame(label="Seed Phrase")
        seed_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        seed_box.set_margin_start(10)
        seed_box.set_margin_end(10)
        seed_box.set_margin_top(10)
        seed_box.set_margin_bottom(10)
        
        scroll_seed = Gtk.ScrolledWindow()
        scroll_seed.set_size_request(-1, 100)
        scroll_seed.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.bip39_seed_input = Gtk.TextView()
        self.bip39_seed_input.set_wrap_mode(Gtk.WrapMode.WORD)
        scroll_seed.add(self.bip39_seed_input)
        seed_box.pack_start(scroll_seed, True, True, 0)
        
        hint = Gtk.Label()
        hint.set_markup("<i>Enter words separated by spaces. Use '???' for unknown positions.</i>")
        hint.set_halign(Gtk.Align.START)
        seed_box.pack_start(hint, False, False, 0)
        
        seed_frame.add(seed_box)
        box.pack_start(seed_frame, False, False, 0)
        
        # Word Range Filtering (NEW!)
        wordrange_frame = Gtk.Frame(label="🎯 Word Range Filtering (Performance Boost!)")
        wordrange_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        wordrange_box.set_margin_start(10)
        wordrange_box.set_margin_end(10)
        wordrange_box.set_margin_top(10)
        wordrange_box.set_margin_bottom(10)
        
        # Enable word filtering
        self.wordrange_enable = Gtk.CheckButton(label="Enable word range filtering")
        self.wordrange_enable.set_active(False)
        wordrange_box.pack_start(self.wordrange_enable, False, False, 0)
        
        # Preset ranges
        preset_box = Gtk.Box(spacing=10)
        preset_box.pack_start(Gtk.Label(label="Preset:"), False, False, 0)
        
        self.wordrange_preset = Gtk.ComboBoxText()
        self.wordrange_preset.append_text("A-D (564 words) - Fast")
        self.wordrange_preset.append_text("A-G (824 words) - Medium")
        self.wordrange_preset.append_text("A-N (1220 words) - Broad")
        self.wordrange_preset.append_text("Common Words (~300) - Very Fast")
        self.wordrange_preset.append_text("Custom Range")
        self.wordrange_preset.set_active(0)
        self.wordrange_preset.connect("changed", self.on_wordrange_preset_changed)
        preset_box.pack_start(self.wordrange_preset, True, True, 0)
        wordrange_box.pack_start(preset_box, False, False, 0)
        
        # Custom range
        custom_box = Gtk.Box(spacing=10)
        custom_box.pack_start(Gtk.Label(label="Custom:"), False, False, 0)
        self.wordrange_start = Gtk.Entry()
        self.wordrange_start.set_text("A")
        self.wordrange_start.set_max_length(1)
        self.wordrange_start.set_width_chars(3)
        custom_box.pack_start(self.wordrange_start, False, False, 0)
        custom_box.pack_start(Gtk.Label(label="to"), False, False, 0)
        self.wordrange_end = Gtk.Entry()
        self.wordrange_end.set_text("D")
        self.wordrange_end.set_max_length(1)
        self.wordrange_end.set_width_chars(3)
        custom_box.pack_start(self.wordrange_end, False, False, 0)
        
        self.wordrange_custom_box = custom_box
        custom_box.set_sensitive(False)
        wordrange_box.pack_start(custom_box, False, False, 0)
        
        # Progressive narrowing
        self.progressive_enable = Gtk.CheckButton(
            label="Progressive narrowing (try narrow ranges first, auto-expand if no match)"
        )
        self.progressive_enable.set_active(True)
        wordrange_box.pack_start(self.progressive_enable, False, False, 0)
        
        # Speedup estimate
        self.speedup_label = Gtk.Label()
        self.speedup_label.set_markup("<span foreground='green'><b>Estimated speedup: 13x faster</b></span>")
        self.speedup_label.set_halign(Gtk.Align.START)
        wordrange_box.pack_start(self.speedup_label, False, False, 0)
        
        wordrange_frame.add(wordrange_box)
        box.pack_start(wordrange_frame, False, False, 0)
        
        # Multi-threading (NEW!)
        thread_frame = Gtk.Frame(label="⚡ Multi-Threading")
        thread_grid = Gtk.Grid()
        thread_grid.set_column_spacing(10)
        thread_grid.set_row_spacing(5)
        thread_grid.set_margin_start(10)
        thread_grid.set_margin_end(10)
        thread_grid.set_margin_top(10)
        thread_grid.set_margin_bottom(10)
        
        thread_grid.attach(Gtk.Label(label="Number of threads:"), 0, 0, 1, 1)
        self.bip39_threads_spin = Gtk.SpinButton()
        self.bip39_threads_spin.set_range(1, 32)
        self.bip39_threads_spin.set_increments(1, 4)
        self.bip39_threads_spin.set_value(8)
        thread_grid.attach(self.bip39_threads_spin, 1, 0, 1, 1)
        
        auto_detect = Gtk.Button(label="Auto-detect CPU cores")
        auto_detect.connect("clicked", self.on_auto_detect_cores)
        thread_grid.attach(auto_detect, 2, 0, 1, 1)
        
        thread_frame.add(thread_grid)
        box.pack_start(thread_frame, False, False, 0)
        
        # Derivation paths
        path_frame = Gtk.Frame(label="BIP32 Derivation Paths")
        path_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        path_box.set_margin_start(10)
        path_box.set_margin_end(10)
        path_box.set_margin_top(10)
        path_box.set_margin_bottom(10)
        
        self.path_bip44 = Gtk.CheckButton(label="m/44'/0'/0'/0/0 (BIP44 Legacy - addresses starting with 1)")
        self.path_bip44.set_active(True)
        path_box.pack_start(self.path_bip44, False, False, 0)
        
        self.path_bip49 = Gtk.CheckButton(label="m/49'/0'/0'/0/0 (BIP49 P2SH-SegWit - addresses starting with 3) [Not supported yet]")
        self.path_bip49.set_active(False)
        self.path_bip49.set_sensitive(False)
        path_box.pack_start(self.path_bip49, False, False, 0)
        
        self.path_bip84 = Gtk.CheckButton(label="m/84'/0'/0'/0/0 (BIP84 Native SegWit - bc1...) [Not supported yet]")
        self.path_bip84.set_active(False)
        self.path_bip84.set_sensitive(False)
        path_box.pack_start(self.path_bip84, False, False, 0)
        
        path_frame.add(path_box)
        box.pack_start(path_frame, False, False, 0)
        
        # Target
        target_frame = Gtk.Frame(label="Target Address(es)")
        target_box = Gtk.Box(spacing=10)
        target_box.set_margin_start(10)
        target_box.set_margin_end(10)
        target_box.set_margin_top(10)
        target_box.set_margin_bottom(10)
        
        target_box.pack_start(Gtk.Label(label="Address/File:"), False, False, 0)
        self.bip39_target = Gtk.Entry()
        self.bip39_target.set_placeholder_text("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa or leave blank to show first derived address")
        target_box.pack_start(self.bip39_target, True, True, 0)
        
        target_frame.add(target_box)
        box.pack_start(target_frame, False, False, 0)
        
        return scroll
    
    def create_weak_key_tab(self):
        """Create weak key pattern detection tab"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(15)
        box.set_margin_end(15)
        box.set_margin_top(15)
        scroll.add(box)
        
        # Info
        info = Gtk.Label()
        info.set_markup("<b>🎯 Weak Key Pattern Detection</b>\n\n"
                       "Detect predictable patterns in key generation:\n"
                       "• Sequential keys (k, k+1, k+2, ...)\n"
                       "• Linear congruential generators\n"
                       "• Timestamp-based keys\n"
                       "• Brain wallet patterns\n"
                       "• Low entropy seeds")
        info.set_line_wrap(True)
        info.set_justify(Gtk.Justification.LEFT)
        box.pack_start(info, False, False, 10)
        
        # Pattern detection mode
        mode_frame = Gtk.Frame(label="Detection Mode")
        mode_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        mode_box.set_margin_start(10)
        mode_box.set_margin_end(10)
        mode_box.set_margin_top(10)
        mode_box.set_margin_bottom(10)
        
        self.weak_mode = Gtk.ComboBoxText()
        self.weak_mode.append_text("Sequential Scan (test k, k+1, k+2, ...)")
        self.weak_mode.append_text("Low Range Scan (1 to 1 billion)")
        self.weak_mode.append_text("Brain Wallet Dictionary")
        self.weak_mode.append_text("Timestamp Pattern (2009-2025)")
        self.weak_mode.append_text("Pattern Analysis (requires known keys)")
        self.weak_mode.set_active(0)
        mode_box.pack_start(self.weak_mode, False, False, 0)
        
        mode_frame.add(mode_box)
        box.pack_start(mode_frame, False, False, 0)
        
        # Range configuration
        range_frame = Gtk.Frame(label="Scan Configuration")
        range_grid = Gtk.Grid()
        range_grid.set_column_spacing(10)
        range_grid.set_row_spacing(5)
        range_grid.set_margin_start(10)
        range_grid.set_margin_end(10)
        range_grid.set_margin_top(10)
        range_grid.set_margin_bottom(10)
        
        range_grid.attach(Gtk.Label(label="Start value:"), 0, 0, 1, 1)
        self.weak_start = Gtk.Entry()
        self.weak_start.set_text("1")
        range_grid.attach(self.weak_start, 1, 0, 1, 1)
        
        range_grid.attach(Gtk.Label(label="End value:"), 0, 1, 1, 1)
        self.weak_end = Gtk.Entry()
        self.weak_end.set_text("1000000")
        range_grid.attach(self.weak_end, 1, 1, 1, 1)
        
        range_grid.attach(Gtk.Label(label="Step size:"), 0, 2, 1, 1)
        self.weak_step = Gtk.SpinButton()
        self.weak_step.set_range(1, 1000)
        self.weak_step.set_increments(1, 10)
        self.weak_step.set_value(1)
        range_grid.attach(self.weak_step, 1, 2, 1, 1)
        
        range_frame.add(range_grid)
        box.pack_start(range_frame, False, False, 0)
        
        # Pattern analysis (for known keys)
        pattern_frame = Gtk.Frame(label="Pattern Analysis (Optional)")
        pattern_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        pattern_box.set_margin_start(10)
        pattern_box.set_margin_end(10)
        pattern_box.set_margin_top(10)
        pattern_box.set_margin_bottom(10)
        
        label = Gtk.Label()
        label.set_markup("<i>If you have known private keys from the same wallet,\nenter them here to detect the generation pattern:</i>")
        label.set_halign(Gtk.Align.START)
        pattern_box.pack_start(label, False, False, 0)
        
        scroll_pattern = Gtk.ScrolledWindow()
        scroll_pattern.set_size_request(-1, 80)
        self.weak_known_keys = Gtk.TextView()
        self.weak_known_keys.set_wrap_mode(Gtk.WrapMode.WORD)
        scroll_pattern.add(self.weak_known_keys)
        pattern_box.pack_start(scroll_pattern, True, True, 0)
        
        hint = Gtk.Label()
        hint.set_markup("<span size='x-small'>One private key per line (hex or decimal)</span>")
        hint.set_halign(Gtk.Align.START)
        pattern_box.pack_start(hint, False, False, 0)
        
        pattern_frame.add(pattern_box)
        box.pack_start(pattern_frame, False, False, 0)
        
        # Target
        target_frame = Gtk.Frame(label="Target Addresses")
        target_box = Gtk.Box(spacing=10)
        target_box.set_margin_start(10)
        target_box.set_margin_end(10)
        target_box.set_margin_top(10)
        target_box.set_margin_bottom(10)
        
        target_box.pack_start(Gtk.Label(label="Address file:"), False, False, 0)
        self.weak_target = Gtk.Entry()
        self.weak_target.set_placeholder_text("Path to addresses.bin or addresses.txt")
        target_box.pack_start(self.weak_target, True, True, 0)
        
        browse_weak = Gtk.Button(label="Browse...")
        browse_weak.connect("clicked", self.on_browse_weak_target)
        target_box.pack_start(browse_weak, False, False, 0)
        
        target_frame.add(target_box)
        box.pack_start(target_frame, False, False, 0)
        
        return scroll
    
    def create_advanced_tab(self):
        """Create advanced settings tab"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(15)
        box.set_margin_end(15)
        box.set_margin_top(15)
        scroll.add(box)
        
        # Checkpoint
        checkpoint_frame = Gtk.Frame(label="Checkpoint & Resume")
        checkpoint_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        checkpoint_box.set_margin_start(10)
        checkpoint_box.set_margin_end(10)
        checkpoint_box.set_margin_top(10)
        checkpoint_box.set_margin_bottom(10)
        
        self.checkpoint_enable = Gtk.CheckButton(label="Enable automatic checkpointing")
        self.checkpoint_enable.set_active(True)
        checkpoint_box.pack_start(self.checkpoint_enable, False, False, 0)
        
        hbox = Gtk.Box(spacing=10)
        hbox.pack_start(Gtk.Label(label="Save every:"), False, False, 0)
        self.checkpoint_interval = Gtk.SpinButton()
        self.checkpoint_interval.set_range(10, 10000)
        self.checkpoint_interval.set_increments(10, 100)
        self.checkpoint_interval.set_value(100)
        hbox.pack_start(self.checkpoint_interval, False, False, 0)
        hbox.pack_start(Gtk.Label(label="million keys/tests"), False, False, 0)
        checkpoint_box.pack_start(hbox, False, False, 0)
        
        checkpoint_frame.add(checkpoint_box)
        box.pack_start(checkpoint_frame, False, False, 0)
        
        # GPU Cooldown
        cooldown_frame = Gtk.Frame(label="GPU Cooldown Scheduler")
        cooldown_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        cooldown_box.set_margin_start(10)
        cooldown_box.set_margin_end(10)
        cooldown_box.set_margin_top(10)
        cooldown_box.set_margin_bottom(10)
        
        self.cooldown_enable = Gtk.CheckButton(label="Enable GPU cooldown (recommended for 24/7 operation)")
        cooldown_box.pack_start(self.cooldown_enable, False, False, 0)
        
        hbox = Gtk.Box(spacing=10)
        hbox.pack_start(Gtk.Label(label="Run for:"), False, False, 0)
        self.cooldown_run = Gtk.SpinButton()
        self.cooldown_run.set_range(1, 1440)
        self.cooldown_run.set_increments(5, 15)
        self.cooldown_run.set_value(60)
        hbox.pack_start(self.cooldown_run, False, False, 0)
        hbox.pack_start(Gtk.Label(label="minutes"), False, False, 0)
        cooldown_box.pack_start(hbox, False, False, 0)
        
        hbox = Gtk.Box(spacing=10)
        hbox.pack_start(Gtk.Label(label="Pause for:"), False, False, 0)
        self.cooldown_pause = Gtk.SpinButton()
        self.cooldown_pause.set_range(1, 1440)
        self.cooldown_pause.set_increments(5, 15)
        self.cooldown_pause.set_value(15)
        hbox.pack_start(self.cooldown_pause, False, False, 0)
        hbox.pack_start(Gtk.Label(label="minutes"), False, False, 0)
        cooldown_box.pack_start(hbox, False, False, 0)
        
        cooldown_frame.add(cooldown_box)
        box.pack_start(cooldown_frame, False, False, 0)
        
        return scroll
    
    def create_console_tab(self):
        """Create console output tab"""
        scroll = Gtk.ScrolledWindow()
        
        self.console_view = Gtk.TextView()
        self.console_view.set_editable(False)
        self.console_view.set_cursor_visible(False)
        self.console_view.set_wrap_mode(Gtk.WrapMode.WORD)
        
        # Set monospace font
        font_desc = Pango.FontDescription("monospace 10")
        self.console_view.modify_font(font_desc)
        
        self.console_buffer = self.console_view.get_buffer()
        
        # Create tags for colored output
        self.console_buffer.create_tag("info", foreground="black")
        self.console_buffer.create_tag("success", foreground="green", weight=Pango.Weight.BOLD)
        self.console_buffer.create_tag("warning", foreground="orange", weight=Pango.Weight.BOLD)
        self.console_buffer.create_tag("error", foreground="red", weight=Pango.Weight.BOLD)
        self.console_buffer.create_tag("match", foreground="blue", weight=Pango.Weight.BOLD, size=12*1024)
        
        scroll.add(self.console_view)
        return scroll
    
    def create_results_tab(self):
        """Create results display tab"""
        scroll = Gtk.ScrolledWindow()
        
        self.results_view = Gtk.TextView()
        self.results_view.set_editable(False)
        self.results_view.set_cursor_visible(False)
        self.results_view.set_wrap_mode(Gtk.WrapMode.WORD)
        
        font_desc = Pango.FontDescription("monospace 10")
        self.results_view.modify_font(font_desc)
        
        self.results_buffer = self.results_view.get_buffer()
        
        scroll.add(self.results_view)
        return scroll
    
    def create_control_buttons(self):
        """Create main control buttons with attack mode selector"""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_halign(Gtk.Align.CENTER)
        
        # Attack Mode Selector
        mode_frame = Gtk.Frame(label="Attack Mode")
        mode_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        mode_box.set_margin_start(10)
        mode_box.set_margin_end(10)
        mode_box.set_margin_top(5)
        mode_box.set_margin_bottom(5)
        
        self.auto_mode = Gtk.RadioButton(label="🎯 Auto-detect from active tab")
        self.auto_mode.set_active(True)
        mode_box.pack_start(self.auto_mode, False, False, 0)
        
        self.manual_gpu = Gtk.RadioButton(group=self.auto_mode, label="⚡ GPU Mining")
        mode_box.pack_start(self.manual_gpu, False, False, 0)
        
        self.manual_bip39 = Gtk.RadioButton(group=self.auto_mode, label="🔐 BIP39 Attack")
        mode_box.pack_start(self.manual_bip39, False, False, 0)
        
        mode_frame.add(mode_box)
        box.pack_start(mode_frame, False, False, 0)
        
        # Control Buttons
        button_box = Gtk.Box(spacing=10)
        button_box.set_halign(Gtk.Align.CENTER)
        
        check_btn = Gtk.Button(label="🔍 Check System")
        check_btn.connect("clicked", self.on_check_system)
        button_box.pack_start(check_btn, False, False, 0)
        
        self.start_btn = Gtk.Button(label="▶ START ATTACK")
        self.start_btn.connect("clicked", self.on_start_attack)
        self.start_btn.get_style_context().add_class("suggested-action")
        button_box.pack_start(self.start_btn, False, False, 0)
        
        self.stop_btn = Gtk.Button(label="■ STOP")
        self.stop_btn.connect("clicked", self.on_stop_attack)
        self.stop_btn.set_sensitive(False)
        self.stop_btn.get_style_context().add_class("destructive-action")
        button_box.pack_start(self.stop_btn, False, False, 0)
        
        clear_btn = Gtk.Button(label="🗑 Clear Console")
        clear_btn.connect("clicked", lambda b: self.console_buffer.set_text(""))
        button_box.pack_start(clear_btn, False, False, 0)
        
        box.pack_start(button_box, False, False, 0)
        return box
    
    # Event handlers
    
    def on_browse_keyhunt(self, button):
        """Browse for KeyHunt binary"""
        dialog = Gtk.FileChooserDialog(
            title="Select KeyHunt-Cuda binary",
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.keyhunt_path.set_text(dialog.get_filename())
        dialog.destroy()
    
    def on_browse_target(self, button):
        """Browse for target address file"""
        dialog = Gtk.FileChooserDialog(
            title="Select address file",
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.keyhunt_target.set_text(dialog.get_filename())
        dialog.destroy()
    
    def on_browse_weak_target(self, button):
        """Browse for weak key target file"""
        dialog = Gtk.FileChooserDialog(
            title="Select address file",
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.weak_target.set_text(dialog.get_filename())
        dialog.destroy()
    
    def on_wordrange_preset_changed(self, combo):
        """Handle word range preset change"""
        active = combo.get_active()
        
        if active == 4:  # Custom
            self.wordrange_custom_box.set_sensitive(True)
        else:
            self.wordrange_custom_box.set_sensitive(False)
        
        # Update speedup estimate
        speedups = {
            0: ("13x faster", 564),     # A-D
            1: ("6x faster", 824),       # A-G
            2: ("2.8x faster", 1220),    # A-N
            3: ("46x faster!", 300),     # Common
            4: ("Variable", "?")         # Custom
        }
        
        speedup_text, word_count = speedups.get(active, ("", ""))
        self.speedup_label.set_markup(
            f"<span foreground='green'><b>Estimated speedup: {speedup_text}</b> "
            f"({word_count} words)</span>"
        )
    
    def on_auto_detect_cores(self, button):
        """Auto-detect CPU cores"""
        try:
            import multiprocessing
            cores = multiprocessing.cpu_count()
            self.bip39_threads_spin.set_value(cores)
            self.log(f"Detected {cores} CPU cores", "success")
        except:
            self.log("Could not detect CPU cores", "warning")
    
    def on_check_system(self, button):
        """Check system configuration"""
        self.log("=== SYSTEM CHECK ===", "info")
        
        # Check KeyHunt
        keyhunt_path = self.keyhunt_path.get_text()
        if os.path.exists(keyhunt_path):
            self.log(f"✓ KeyHunt found: {keyhunt_path}", "success")
            
            # Run system check
            try:
                result = subprocess.run(
                    [keyhunt_path, "-c"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                for line in result.stdout.split('\n'):
                    if line.strip():
                        if 'GPU' in line:
                            self.log(line, "success")
                        else:
                            self.log(line, "info")
            except Exception as e:
                self.log(f"Error running KeyHunt check: {e}", "error")
        else:
            self.log(f"✗ KeyHunt not found: {keyhunt_path}", "error")
        
        # Check BIP39
        if BIP39_AVAILABLE and self.bip39_engine and self.bip39_engine.WORDLIST:
            self.log(f"✓ BIP39 engine ready ({len(self.bip39_engine.WORDLIST)} words loaded)", "success")
        else:
            self.log("✗ BIP39 wordlist not loaded", "warning")
        
        # Check CPU
        try:
            import multiprocessing
            cores = multiprocessing.cpu_count()
            self.log(f"✓ CPU: {cores} cores available", "success")
        except:
            self.log("? CPU core count unknown", "warning")
        
        self.log("=== CHECK COMPLETE ===", "info")
    
    def on_start_attack(self, button):
        """Start attack with smart routing"""
        if self.is_running:
            return
        
        # Get attack mode
        if self.manual_gpu.get_active():
            mode = "keyhunt"
        elif self.manual_bip39.get_active():
            mode = "bip39"
        else:  # Auto-detect from tab
            page = self.notebook.get_current_page()
            mode_map = {0: "keyhunt", 1: "bip39", 2: "weak"}
            mode = mode_map.get(page)
        
        if not mode:
            self.log("Cannot start attack from this tab. Select an attack tab.", "warning")
            return
        
        # Validate configuration
        if mode == "keyhunt":
            if not os.path.exists(self.keyhunt_path.get_text()):
                self.log("KeyHunt binary not found", "error")
                return
            if not self.keyhunt_target.get_text():
                self.log("No target address/file specified", "error")
                return
        elif mode == "bip39":
            if not self.bip39_engine or not hasattr(self.bip39_engine, 'WORDLIST') or not self.bip39_engine.WORDLIST:
                self.log("BIP39 wordlist not loaded! Please load wordlist first.", "error")
                return
        
        # Start attack
        self.is_running = True
        self.start_btn.set_sensitive(False)
        self.stop_btn.set_sensitive(True)
        self.start_time = datetime.now()
        
        self.log("=" * 80, "info")
        self.log(f"ATTACK STARTED: {mode.upper()}", "success")
        self.log("=" * 80, "info")
        
        self.status_labels["Mode"].set_markup(f"<b><span foreground='green'>{mode.upper()}</span></b>")

    def on_stop_attack(self, button):
        """Stop the attack"""
        self.log("Stopping attack...", "warning")
        
        self.bip39_stop_flag.set()
        
        if self.process:
            self.process.terminate()
            self.process = None
        
        self.is_running = False
        self.start_btn.set_sensitive(True)
        self.stop_btn.set_sensitive(False)
        
        self.status_labels["Mode"].set_markup("<b>Stopped</b>")
        self.log("Attack stopped", "warning")
    
    def update_status(self):
        """Update status display (called every second)"""
        if not self.is_running:
            return True
        
        # Update runtime
        if self.start_time:
            elapsed = datetime.now() - self.start_time
            hours, remainder = divmod(int(elapsed.total_seconds()), 3600)
            minutes, seconds = divmod(remainder, 60)
            self.status_labels["Runtime"].set_markup(f"<b>{hours:02d}:{minutes:02d}:{seconds:02d}</b>")
        
        # Update other stats
        self.status_labels["Speed"].set_markup(f"<b>{self.current_speed:.1f} Mk/s</b>")
        self.status_labels["Tested"].set_markup(f"<b>{self.format_number(self.keys_checked)}</b>")
        self.status_labels["Found"].set_markup(f"<b>{self.matches_found}</b>")
        
        return True
    
    def format_number(self, num):
        """Format large numbers with K/M/B/T suffixes"""
        if num < 1000:
            return str(num)
        elif num < 1000000:
            return f"{num/1000:.1f}K"
        elif num < 1000000000:
            return f"{num/1000000:.1f}M"
        elif num < 1000000000000:
            return f"{num/1000000000:.1f}B"
        else:
            return f"{num/1000000000000:.1f}T"
    
    def log(self, message, tag="info"):
        """Log message to console"""
        end_iter = self.console_buffer.get_end_iter()
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        self.console_buffer.insert(end_iter, f"[{timestamp}] ")
        self.console_buffer.insert_with_tags_by_name(end_iter, f"{message}\n", tag)
        
        # Auto-scroll
        mark = self.console_buffer.get_insert()
        self.console_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)


    def on_browse_wordlist(self, button):
        """Browse for BIP39 wordlist"""
        dialog = Gtk.FileChooserDialog(
            "Select BIP39 Wordlist", self, Gtk.FileChooserAction.OPEN,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        if dialog.run() == Gtk.ResponseType.OK:
            self.bip39_wordlist_path.set_text(dialog.get_filename())
        dialog.destroy()
    
    def on_load_wordlist(self, button):
        """Load BIP39 wordlist from file"""
        path = self.bip39_wordlist_path.get_text()
        if not os.path.exists(path):
            self.log(f"Wordlist not found: {path}", "error")
            self.wordlist_status.set_markup("<span foreground='red'>Error: File not found</span>")
            return
        
        try:
            with open(path, 'r') as f:
                words = [line.strip() for line in f if line.strip()]
            
            if len(words) != 2048:
                self.log(f"Warning: Got {len(words)} words, expected 2048", "warning")
            else:
                self.log(f"Successfully loaded {len(words)} words", "success")
            
            self.wordlist_status.set_markup(
                f"<span foreground='green'><b>✓ Loaded:</b> {len(words)} words</span>"
            )
            
            if self.bip39_engine:
                self.bip39_engine.WORDLIST = words
                self.log("BIP39 engine ready", "success")
        except Exception as e:
            self.log(f"Error loading wordlist: {e}", "error")
            self.wordlist_status.set_markup(f"<span foreground='red'>Error: {e}</span>")
    
def main():
    app = KeyHuntUltimateGUI()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
