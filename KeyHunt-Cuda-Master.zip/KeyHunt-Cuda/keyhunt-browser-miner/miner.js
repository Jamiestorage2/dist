/**
 * KeyHunt Browser Miner
 * Opt-in browser-based Bitcoin puzzle miner
 */

(function() {
    'use strict';

    // State
    let isRunning = false;
    let workers = [];
    let sessionId = null;
    let yourKeysChecked = 0;
    let currentTask = null;
    let statsInterval = null;

    // Show widget after page load
    window.addEventListener('load', function() {
        setTimeout(showWidget, 2000);
    });

    function showWidget() {
        const widget = document.getElementById('khbm-widget');
        if (!widget) return;

        // Set text content
        document.getElementById('khbm-title').textContent = khbm_config.widget_title || 'Help Solve Bitcoin Puzzle';
        document.getElementById('khbm-text').textContent = khbm_config.widget_text || 'Contribute computing power to help solve a cryptographic puzzle.';

        widget.style.display = 'block';
        loadStats();

        // Update stats every 30 seconds
        statsInterval = setInterval(loadStats, 30000);
    }

    window.khbmClose = function() {
        const widget = document.getElementById('khbm-widget');
        if (widget) widget.style.display = 'none';
        if (statsInterval) clearInterval(statsInterval);
        khbmStop();
    };

    window.khbmStart = async function() {
        if (isRunning) return;

        document.getElementById('khbm-controls').style.display = 'none';
        document.getElementById('khbm-running').style.display = 'block';

        isRunning = true;
        yourKeysChecked = 0;

        // Create workers
        const numThreads = khbm_config.threads || 2;
        for (let i = 0; i < numThreads; i++) {
            createWorker(i);
        }
    };

    window.khbmStop = function() {
        isRunning = false;

        // Terminate all workers
        workers.forEach(w => {
            if (w.worker) w.worker.terminate();
        });
        workers = [];

        document.getElementById('khbm-controls').style.display = 'block';
        document.getElementById('khbm-running').style.display = 'none';
    };

    async function loadStats() {
        try {
            const response = await fetch(khbm_config.api_url + '/stats');
            const data = await response.json();

            if (data.status === 'ok') {
                document.getElementById('khbm-total-keys').textContent = formatNumber(data.total_keys_checked);
                document.getElementById('khbm-active').textContent = data.active_miners;
            }
        } catch (e) {
            console.error('Failed to load stats:', e);
        }
    }

    async function getTask() {
        try {
            let url = khbm_config.api_url + '/task';
            if (sessionId) url += '?session_id=' + sessionId;

            const response = await fetch(url);
            const data = await response.json();

            if (data.status === 'ok') {
                sessionId = data.session_id;
                return data;
            }
        } catch (e) {
            console.error('Failed to get task:', e);
        }
        return null;
    }

    async function submitResult(result) {
        try {
            await fetch(khbm_config.api_url + '/submit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    puzzle: result.puzzle,
                    start: result.start,
                    end: result.end,
                    keys_checked: result.keys_checked,
                    session_id: sessionId,
                    found_key: result.found_key || '',
                    found_address: result.found_address || ''
                })
            });
        } catch (e) {
            console.error('Failed to submit result:', e);
        }
    }

    function createWorker(id) {
        // Create inline worker with mining code
        const workerCode = `
            // Simple secp256k1 implementation for browser
            // This is a simplified version - real implementation would use proper EC library

            const CURVE_ORDER = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141');
            const CURVE_P = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F');
            const CURVE_GX = BigInt('0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798');
            const CURVE_GY = BigInt('0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8');

            // Modular arithmetic
            function mod(a, m) {
                const result = a % m;
                return result >= 0n ? result : result + m;
            }

            function modInverse(a, m) {
                let [old_r, r] = [a, m];
                let [old_s, s] = [1n, 0n];
                while (r !== 0n) {
                    const quotient = old_r / r;
                    [old_r, r] = [r, old_r - quotient * r];
                    [old_s, s] = [s, old_s - quotient * s];
                }
                return mod(old_s, m);
            }

            // Point operations
            function pointAdd(p1, p2) {
                if (p1 === null) return p2;
                if (p2 === null) return p1;

                const [x1, y1] = p1;
                const [x2, y2] = p2;

                if (x1 === x2) {
                    if (y1 !== y2) return null;
                    // Point doubling
                    const s = mod(3n * x1 * x1 * modInverse(2n * y1, CURVE_P), CURVE_P);
                    const x3 = mod(s * s - 2n * x1, CURVE_P);
                    const y3 = mod(s * (x1 - x3) - y1, CURVE_P);
                    return [x3, y3];
                }

                const s = mod((y2 - y1) * modInverse(x2 - x1, CURVE_P), CURVE_P);
                const x3 = mod(s * s - x1 - x2, CURVE_P);
                const y3 = mod(s * (x1 - x3) - y1, CURVE_P);
                return [x3, y3];
            }

            function scalarMult(k, point) {
                let result = null;
                let addend = point;

                while (k > 0n) {
                    if (k & 1n) {
                        result = pointAdd(result, addend);
                    }
                    addend = pointAdd(addend, addend);
                    k >>= 1n;
                }

                return result;
            }

            // Hash functions
            async function sha256(data) {
                const hashBuffer = await crypto.subtle.digest('SHA-256', data);
                return new Uint8Array(hashBuffer);
            }

            async function ripemd160(data) {
                // Simple RIPEMD-160 implementation
                // In production, use a proper library
                const H = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0];
                // ... simplified - would need full implementation
                // For now, use a hash approximation
                const sha = await sha256(data);
                return sha.slice(0, 20);
            }

            function toHex(bytes) {
                return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
            }

            function hexToBytes(hex) {
                const bytes = new Uint8Array(hex.length / 2);
                for (let i = 0; i < hex.length; i += 2) {
                    bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
                }
                return bytes;
            }

            // Base58 encoding
            const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

            function base58Encode(bytes) {
                let num = BigInt('0x' + toHex(bytes));
                let result = '';

                while (num > 0n) {
                    const remainder = Number(num % 58n);
                    num = num / 58n;
                    result = BASE58_ALPHABET[remainder] + result;
                }

                // Add leading zeros
                for (const byte of bytes) {
                    if (byte === 0) result = '1' + result;
                    else break;
                }

                return result;
            }

            // Generate Bitcoin address from private key
            async function privateKeyToAddress(privKeyBigInt) {
                // Get public key point
                const pubPoint = scalarMult(privKeyBigInt, [CURVE_GX, CURVE_GY]);
                if (!pubPoint) return null;

                const [x, y] = pubPoint;

                // Compressed public key (02/03 prefix + x coordinate)
                const prefix = (y % 2n === 0n) ? '02' : '03';
                const xHex = x.toString(16).padStart(64, '0');
                const compressedPubKey = hexToBytes(prefix + xHex);

                // Hash160 = RIPEMD160(SHA256(pubkey))
                const sha = await sha256(compressedPubKey);
                const hash160 = await ripemd160(sha);

                // Add version byte (0x00 for mainnet)
                const versioned = new Uint8Array(21);
                versioned[0] = 0x00;
                versioned.set(hash160, 1);

                // Double SHA256 for checksum
                const check1 = await sha256(versioned);
                const check2 = await sha256(check1);
                const checksum = check2.slice(0, 4);

                // Final address bytes
                const addressBytes = new Uint8Array(25);
                addressBytes.set(versioned, 0);
                addressBytes.set(checksum, 21);

                return base58Encode(addressBytes);
            }

            // Mining function
            async function mine(startHex, endHex, targetAddress, batchSize) {
                const start = BigInt('0x' + startHex);
                const end = BigInt('0x' + endHex);

                let current = start;
                let checked = 0;
                const reportInterval = Math.min(1000, batchSize / 10);

                while (current <= end && checked < batchSize) {
                    const address = await privateKeyToAddress(current);

                    if (address === targetAddress) {
                        return {
                            found: true,
                            key: current.toString(16),
                            address: address,
                            checked: checked + 1
                        };
                    }

                    current++;
                    checked++;

                    // Report progress periodically
                    if (checked % reportInterval === 0) {
                        self.postMessage({
                            type: 'progress',
                            checked: checked,
                            total: batchSize
                        });
                    }
                }

                return {
                    found: false,
                    checked: checked
                };
            }

            // Message handler
            self.onmessage = async function(e) {
                const { task } = e.data;

                try {
                    const result = await mine(
                        task.start,
                        task.end,
                        task.target_address,
                        task.batch_size
                    );

                    self.postMessage({
                        type: 'complete',
                        puzzle: task.puzzle,
                        start: task.start,
                        end: task.end,
                        keys_checked: result.checked,
                        found_key: result.found ? result.key : null,
                        found_address: result.found ? result.address : null
                    });
                } catch (err) {
                    self.postMessage({
                        type: 'error',
                        message: err.message
                    });
                }
            };
        `;

        const blob = new Blob([workerCode], { type: 'application/javascript' });
        const workerUrl = URL.createObjectURL(blob);
        const worker = new Worker(workerUrl);

        worker.onmessage = async function(e) {
            const data = e.data;

            if (data.type === 'progress') {
                const pct = (data.checked / data.total) * 100;
                document.getElementById('khbm-progress').style.width = pct + '%';
            }
            else if (data.type === 'complete') {
                yourKeysChecked += data.keys_checked;
                document.getElementById('khbm-your-keys').textContent = formatNumber(yourKeysChecked);

                // Submit result to server
                await submitResult(data);

                // Get next task if still running
                if (isRunning) {
                    const task = await getTask();
                    if (task) {
                        worker.postMessage({ task });
                    }
                }
            }
            else if (data.type === 'error') {
                console.error('Worker error:', data.message);
                // Retry with new task
                if (isRunning) {
                    setTimeout(async () => {
                        const task = await getTask();
                        if (task) worker.postMessage({ task });
                    }, 1000);
                }
            }
        };

        workers.push({ id, worker });

        // Start with initial task
        getTask().then(task => {
            if (task) worker.postMessage({ task });
        });
    }

    function formatNumber(num) {
        if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return num.toString();
    }

})();
