#!/bin/bash
# Test KeyHunt-Cuda Multi-Range Capabilities
# Run this to see what batching options are available

echo "========================================"
echo "KeyHunt-Cuda Capability Tests"
echo "========================================"
echo ""

KEYHUNT_PATH="./KeyHunt-Cuda"
TARGET_ADDRESS="1BWo3JeB9jrGwfHDNpdGK54CRas7fsVzXU"

# Check if KeyHunt exists
if [ ! -f "$KEYHUNT_PATH" ]; then
    echo "❌ KeyHunt-Cuda not found at $KEYHUNT_PATH"
    echo "   Please update KEYHUNT_PATH in this script"
    exit 1
fi

echo "✅ Found KeyHunt at: $KEYHUNT_PATH"
echo ""

# Test 1: Check help for range options
echo "TEST 1: Checking help for range options..."
echo "----------------------------------------"
$KEYHUNT_PATH --help 2>&1 | grep -i "range" | head -10
echo ""

# Test 2: Try multiple --range flags
echo "TEST 2: Testing multiple --range flags..."
echo "----------------------------------------"
echo "Command: $KEYHUNT_PATH --range 4000000000000000:4000000000000100 --range 5000000000000000:5000000000000100 -m address --coin BTC -o test_multi.txt $TARGET_ADDRESS"
echo ""

timeout 10s $KEYHUNT_PATH \
    --range 4000000000000000:4000000000000100 \
    --range 5000000000000000:5000000000000100 \
    -m address --coin BTC -o test_multi.txt $TARGET_ADDRESS 2>&1 | head -20

RESULT1=$?
echo ""
if [ $RESULT1 -eq 0 ] || [ $RESULT1 -eq 124 ]; then
    echo "✅ Multiple --range flags MIGHT be supported (didn't error immediately)"
    echo "   Check output above for two separate range searches"
else
    echo "❌ Multiple --range flags NOT supported (error code: $RESULT1)"
fi
echo ""

# Test 3: Try range file
echo "TEST 3: Testing --range-file option..."
echo "----------------------------------------"

# Create test range file
cat > test_ranges.txt << EOF
4000000000000000:4000000000000100
5000000000000000:5000000000000100
EOF

echo "Created test_ranges.txt with 2 ranges"
echo "Command: $KEYHUNT_PATH --range-file test_ranges.txt -m address --coin BTC -o test_file.txt $TARGET_ADDRESS"
echo ""

timeout 10s $KEYHUNT_PATH \
    --range-file test_ranges.txt \
    -m address --coin BTC -o test_file.txt $TARGET_ADDRESS 2>&1 | head -20

RESULT2=$?
echo ""
if [ $RESULT2 -eq 0 ] || [ $RESULT2 -eq 124 ]; then
    echo "✅ --range-file MIGHT be supported (didn't error immediately)"
else
    echo "❌ --range-file NOT supported (error code: $RESULT2)"
fi
echo ""

# Test 4: Check for stdin input
echo "TEST 4: Testing stdin range input..."
echo "----------------------------------------"
echo "Command: echo '4000000000000000:4000000000000100' | $KEYHUNT_PATH -m address --coin BTC -o test_stdin.txt $TARGET_ADDRESS"
echo ""

echo "4000000000000000:4000000000000100" | timeout 10s $KEYHUNT_PATH \
    -m address --coin BTC -o test_stdin.txt $TARGET_ADDRESS 2>&1 | head -20

RESULT3=$?
echo ""
if [ $RESULT3 -eq 0 ] || [ $RESULT3 -eq 124 ]; then
    echo "✅ Stdin input MIGHT be supported"
else
    echo "❌ Stdin input NOT supported (error code: $RESULT3)"
fi
echo ""

# Summary
echo "========================================"
echo "SUMMARY"
echo "========================================"
echo ""
echo "Multiple --range flags:  $([ $RESULT1 -eq 0 ] || [ $RESULT1 -eq 124 ] && echo '✅ Possible' || echo '❌ No')"
echo "--range-file option:     $([ $RESULT2 -eq 0 ] || [ $RESULT2 -eq 124 ] && echo '✅ Possible' || echo '❌ No')"
echo "Stdin range input:       $([ $RESULT3 -eq 0 ] || [ $RESULT3 -eq 124 ] && echo '✅ Possible' || echo '❌ No')"
echo ""
echo "Recommendation:"
if [ $RESULT1 -eq 0 ] || [ $RESULT1 -eq 124 ]; then
    echo "  → Try implementing multi-range batching (BEST performance)"
elif [ $RESULT2 -eq 0 ] || [ $RESULT2 -eq 124 ]; then
    echo "  → Try implementing range-file batching (GOOD performance)"
else
    echo "  → Implement sequential batching (ACCEPTABLE performance)"
fi
echo ""
echo "Clean up test files:"
echo "  rm -f test_multi.txt test_file.txt test_stdin.txt test_ranges.txt"
echo ""
