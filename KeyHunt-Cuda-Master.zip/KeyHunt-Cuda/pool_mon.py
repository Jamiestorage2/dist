#!/usr/bin/env python3
"""
Pool Monitor Daemon - OPTIMIZED VERSION
Best settings: --interval 1 --wait 120
"""

try:
    from selenium import webdriver
    from selenium.webdriver.firefox.options import Options
except ImportError:
    print("❌ Selenium not installed!")
    print("Install: pip install selenium --break-system-packages")
    exit(1)

import time
import re
import sqlite3
import signal
import sys
from datetime import datetime

class PoolMonitorDaemon:
    def __init__(self, puzzle_num=71, interval=1, wait_time=120):
        self.puzzle_num = puzzle_num
        self.interval = interval
        self.wait_time = wait_time
        self.running = True
        self.db_file = f"scan_data_puzzle_{puzzle_num}.db"
        
        # Stats
        self.total_scans = 0
        self.total_new_blocks = 0
        self.total_ranges_seen = 0
        self.last_scan_time = None
        
        # Track ranges over time
        self.range_history = []
        
        # Setup signal handler
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, sig, frame):
        """Handle shutdown gracefully"""
        print("\n\n⏹️  Shutting down pool monitor...")
        self.running = False
    
    def connect_db(self):
        """Connect to coordinator's database"""
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='pool_scanned'")
            if not cursor.fetchone():
                print(f"❌ Database {self.db_file} doesn't have pool_scanned table!")
                return None
            return conn
        except Exception as e:
            print(f"❌ Database error: {e}")
            return None
    
    def decode_range_id(self, range_id):
        """Decode pool range ID to blocks"""
        hex_prefix = range_id[0:2]
        hex_suffix = range_id[3:]
        
        blocks = []
        for x in '0123456789ABCDEF':
            block_start_hex = hex_prefix + x + hex_suffix + '3000000000'
            block_end_hex = hex_prefix + x + hex_suffix + '3FFFFFFFFF'
            
            block_start = int(block_start_hex, 16)
            block_end = int(block_end_hex, 16)
            blocks.append((block_start, block_end))
        
        return blocks
    
    def get_puzzle_from_hex(self, hex_value):
        """Determine puzzle number from hex value"""
        if hex_value < (1 << 70):
            return None
        
        puzzle = hex_value.bit_length()
        
        if 71 <= puzzle <= 160:
            return puzzle
        
        return None
    
    def get_database_for_puzzle(self, puzzle_num):
        """Get database filename for a puzzle"""
        return f"scan_data_puzzle_{puzzle_num}.db"
    
    def add_pool_blocks(self, conn, blocks):
        """Add blocks to pool_scanned table"""
        cursor = conn.cursor()
        added_count = 0
        
        for block_start, block_end in blocks:
            block_start_hex = hex(block_start)[2:].upper()
            block_end_hex = hex(block_end)[2:].upper()
            
            try:
                cursor.execute('''
                    INSERT OR IGNORE INTO pool_scanned (block_start, block_end)
                    VALUES (?, ?)
                ''', (block_start_hex, block_end_hex))
                
                if cursor.rowcount > 0:
                    added_count += 1
            except Exception as e:
                print(f"   ⚠️  Error adding block: {e}")
        
        conn.commit()
        return added_count
    
    def scrape_with_selenium(self):
        """Scrape status page using Selenium"""
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--disable-gpu')
        options.add_argument('--no-sandbox')
        
        driver = None
        try:
            driver = webdriver.Firefox(options=options)
            driver.set_page_load_timeout(30)
            
            url = "https://btcpuzzle.info/status"
            driver.get(url)
            
            # Wait for WebSocket data with progress
            wait_intervals = self.wait_time // 10
            print(f"⏳ Loading data ({self.wait_time}s)", end="", flush=True)
            
            for i in range(wait_intervals):
                time.sleep(10)
                print(".", end="", flush=True)
            
            # Get page source
            page_source = driver.page_source
            
            # Extract range IDs
            range_pattern = re.compile(r'[0-9A-F]{2}X[0-9A-F]{4,5}')
            ranges = set(range_pattern.findall(page_source))
            
            driver.quit()
            
            return list(ranges)
            
        except Exception as e:
            print(f" ❌ {e}")
            if driver:
                try:
                    driver.quit()
                except:
                    pass
            return []
    
    def run_scan_cycle(self):
        """Run one scan cycle"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        self.total_scans += 1
        
        print(f"\n[{timestamp}] 🔍 Scan #{self.total_scans}")
        print("-" * 70)
        
        # Scrape
        range_ids = self.scrape_with_selenium()
        
        if not range_ids:
            print(" ❌ No ranges found")
            return
        
        print(f" ✅ {len(range_ids)} ranges")
        self.total_ranges_seen += len(range_ids)
        
        # Track history
        self.range_history.append({
            'timestamp': datetime.now(),
            'count': len(range_ids),
            'ranges': set(range_ids)
        })
        
        # Keep only last 10 scans in history
        if len(self.range_history) > 10:
            self.range_history.pop(0)
        
        # Show compact list
        for r in sorted(range_ids):
            blocks = self.decode_range_id(r)
            puzzle = self.get_puzzle_from_hex(blocks[0][0]) if blocks else '?'
            print(f"   {r} (P{puzzle})", end="  ")
        print()
        
        # Organize by puzzle
        blocks_by_puzzle = {}
        for range_id in range_ids:
            blocks = self.decode_range_id(range_id)
            for block_start, block_end in blocks:
                puzzle = self.get_puzzle_from_hex(block_start)
                if puzzle is None:
                    continue
                if puzzle not in blocks_by_puzzle:
                    blocks_by_puzzle[puzzle] = []
                blocks_by_puzzle[puzzle].append((block_start, block_end))
        
        # Update databases
        total_new = 0
        for puzzle, blocks in blocks_by_puzzle.items():
            db_file = self.get_database_for_puzzle(puzzle)
            
            try:
                conn = sqlite3.connect(db_file)
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='pool_scanned'")
                if not cursor.fetchone():
                    conn.close()
                    continue
                
                new_count = self.add_pool_blocks(conn, blocks)
                conn.close()
                total_new += new_count
                
                if new_count > 0:
                    print(f"   💾 P{puzzle}: +{new_count} new blocks")
                
            except Exception as e:
                print(f"   ❌ P{puzzle}: {e}")
        
        self.total_new_blocks += total_new
        self.last_scan_time = datetime.now()
        
        # Summary
        if total_new == 0:
            print(f"   ✓ All ranges already in database")
    
    def run(self):
        """Main daemon loop"""
        print("=" * 70)
        print("🚀 POOL MONITOR DAEMON - OPTIMIZED")
        print("=" * 70)
        print(f"⚙️  Settings:")
        print(f"   Puzzle: {self.puzzle_num}")
        print(f"   Scan interval: {self.interval}s")
        print(f"   WebSocket wait: {self.wait_time}s")
        print(f"   Database: {self.db_file}")
        print("\n💡 Tip: This runs alongside your coordinator")
        print("   Any new pool blocks are instantly excluded!")
        print("\n⏹️  Press Ctrl+C to stop")
        print("=" * 70)
        
        # Verify database
        conn = self.connect_db()
        if not conn:
            print("\n❌ Cannot start - database not accessible")
            return
        
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM pool_scanned")
        initial_count = cursor.fetchone()[0]
        conn.close()
        
        print(f"📊 Current pool blocks: {initial_count}\n")
        
        # Main loop
        while self.running:
            try:
                self.run_scan_cycle()
                
                # Wait for next scan
                if self.running and self.interval > 0:
                    for _ in range(self.interval):
                        if not self.running:
                            break
                        time.sleep(1)
                
            except Exception as e:
                print(f"\n❌ Error: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(5)
        
        self.print_final_stats()
    
    def print_final_stats(self):
        """Print final statistics"""
        print("\n" + "=" * 70)
        print("📊 FINAL STATISTICS")
        print("=" * 70)
        print(f"Total scans: {self.total_scans}")
        print(f"Total ranges seen: {self.total_ranges_seen}")
        print(f"New blocks added to DB: {self.total_new_blocks}")
        if self.last_scan_time:
            print(f"Last scan: {self.last_scan_time.strftime('%H:%M:%S')}")
        print("=" * 70)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Pool Monitor Daemon - Optimized for real-time updates',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  %(prog)s                          # Use optimized defaults (1s interval, 120s wait)
  %(prog)s --interval 30            # Scan every 30 seconds
  %(prog)s --wait 90                # Wait 90s for WebSocket data
  %(prog)s --test 75X457E           # Test decode a range ID
        '''
    )
    parser.add_argument('--puzzle', type=int, default=71, help='Puzzle number (default: 71)')
    parser.add_argument('--interval', type=int, default=1, help='Scan interval in seconds (default: 1 - OPTIMIZED)')
    parser.add_argument('--wait', type=int, default=120, help='WebSocket wait time (default: 120s - OPTIMIZED)')
    parser.add_argument('--test', type=str, help='Test decode a range ID')
    
    args = parser.parse_args()
    
    # Test mode
    if args.test:
        daemon = PoolMonitorDaemon(puzzle_num=args.puzzle, interval=args.interval, wait_time=args.wait)
        
        print("=" * 70)
        print(f"🧪 TESTING RANGE ID: {args.test}")
        print("=" * 70)
        
        blocks = daemon.decode_range_id(args.test)
        print(f"Decodes to {len(blocks)} blocks:\n")
        
        for i, (start, end) in enumerate(blocks[:3], 1):
            puzzle = daemon.get_puzzle_from_hex(start)
            print(f"{i}. 0x{start:X} → 0x{end:X}")
            print(f"   Puzzle {puzzle}, {end - start + 1:,} keys\n")
        
        if len(blocks) > 3:
            print(f"... and {len(blocks) - 3} more")
        
        first_puzzle = daemon.get_puzzle_from_hex(blocks[0][0])
        print(f"✅ Puzzle {first_puzzle} → {daemon.get_database_for_puzzle(first_puzzle)}")
        
        sys.exit(0)
    
    # Normal mode
    daemon = PoolMonitorDaemon(puzzle_num=args.puzzle, interval=args.interval, wait_time=args.wait)
    daemon.run()
