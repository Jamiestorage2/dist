<?php
/**
 * Plugin Name: KeyHunt Browser Miner
 * Description: Allow visitors to help mine Bitcoin puzzle keys using their browser. Opt-in only.
 * Version: 1.0.0
 * Author: KeyHunt Team
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('KHBM_VERSION', '1.0.0');
define('KHBM_TABLE_BLOCKS', 'khbm_scanned_blocks');
define('KHBM_TABLE_FOUND', 'khbm_found_keys');
define('KHBM_TABLE_STATS', 'khbm_miner_stats');

/**
 * Activation - create tables
 */
function khbm_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Scanned blocks from browser miners
    $table_blocks = $wpdb->prefix . KHBM_TABLE_BLOCKS;
    $sql_blocks = "CREATE TABLE $table_blocks (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        puzzle INT(11) NOT NULL,
        block_start VARCHAR(64) NOT NULL,
        block_end VARCHAR(64) NOT NULL,
        keys_checked BIGINT(20) UNSIGNED DEFAULT 0,
        session_id VARCHAR(64),
        ip_hash VARCHAR(64),
        user_agent_hash VARCHAR(64),
        scanned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY puzzle_idx (puzzle),
        KEY session_idx (session_id)
    ) $charset_collate;";

    // Found keys - PRIVATE!
    $table_found = $wpdb->prefix . KHBM_TABLE_FOUND;
    $sql_found = "CREATE TABLE $table_found (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        puzzle INT(11) NOT NULL,
        private_key VARCHAR(128) NOT NULL,
        address VARCHAR(64),
        block_start VARCHAR(64),
        block_end VARCHAR(64),
        session_id VARCHAR(64),
        found_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Miner statistics
    $table_stats = $wpdb->prefix . KHBM_TABLE_STATS;
    $sql_stats = "CREATE TABLE $table_stats (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        date DATE NOT NULL,
        total_miners INT(11) DEFAULT 0,
        total_keys BIGINT(20) UNSIGNED DEFAULT 0,
        total_blocks INT(11) DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY date_idx (date)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_blocks);
    dbDelta($sql_found);
    dbDelta($sql_stats);

    // Default options
    add_option('khbm_enabled', '1');
    add_option('khbm_puzzle', '71');
    add_option('khbm_target_address', '1PWo3JeB9jrGwfHDNpdGK54CRas7fsVzXU');
    add_option('khbm_threads', '2');
    add_option('khbm_batch_size', '10000');
    add_option('khbm_widget_title', 'Help Us Solve Bitcoin Puzzle #71');
    add_option('khbm_widget_text', 'Contribute your browser\'s computing power to help solve a Bitcoin cryptographic puzzle.');

    // C&C options
    add_option('khbm_use_cnc', '1');
    add_option('khbm_cnc_url', ''); // Empty = use local sync plugin
}
register_activation_hook(__FILE__, 'khbm_activate');

/**
 * Register REST API routes
 */
function khbm_register_routes() {
    // Get mining task
    register_rest_route('khbm/v1', '/task', array(
        'methods' => 'GET',
        'callback' => 'khbm_get_task',
        'permission_callback' => '__return_true'
    ));

    // Submit results
    register_rest_route('khbm/v1', '/submit', array(
        'methods' => 'POST',
        'callback' => 'khbm_submit_result',
        'permission_callback' => '__return_true'
    ));

    // Get public stats
    register_rest_route('khbm/v1', '/stats', array(
        'methods' => 'GET',
        'callback' => 'khbm_get_public_stats',
        'permission_callback' => '__return_true'
    ));
}
add_action('rest_api_init', 'khbm_register_routes');

/**
 * Get a mining task for browser
 * Uses C&C system to avoid scanning already-mined blocks
 */
function khbm_get_task($request) {
    if (get_option('khbm_enabled') !== '1') {
        return new WP_REST_Response(array('status' => 'disabled'), 200);
    }

    $puzzle = intval(get_option('khbm_puzzle', 71));
    $target_address = get_option('khbm_target_address');
    $batch_size = intval(get_option('khbm_batch_size', 10000));

    // Generate session ID if not provided
    $session_id = $request->get_param('session_id');
    if (!$session_id) {
        $session_id = bin2hex(random_bytes(16));
    }

    // Try to use C&C for smart range allocation
    $cnc_enabled = get_option('khbm_use_cnc', '1') === '1';

    if ($cnc_enabled) {
        // Use the C&C system for smart allocation
        $work = khbm_get_cnc_work($puzzle, $batch_size, $session_id);
        if ($work) {
            return new WP_REST_Response(array(
                'status' => 'ok',
                'puzzle' => $puzzle,
                'target_address' => $target_address,
                'start' => $work['start'],
                'end' => $work['end'],
                'batch_size' => $batch_size,
                'session_id' => $session_id,
                'source' => 'cnc',
                'cnc_attempts' => $work['attempts'] ?? 1
            ), 200);
        }
    }

    // Fallback to random assignment if C&C fails or is disabled
    $puzzle_ranges = array(
        66 => array('start' => '20000000000000000', 'end' => '3FFFFFFFFFFFFFFFF'),
        67 => array('start' => '40000000000000000', 'end' => '7FFFFFFFFFFFFFFFF'),
        68 => array('start' => '80000000000000000', 'end' => 'FFFFFFFFFFFFFFFFF'),
        69 => array('start' => '100000000000000000', 'end' => '1FFFFFFFFFFFFFFFFF'),
        70 => array('start' => '200000000000000000', 'end' => '3FFFFFFFFFFFFFFFFF'),
        71 => array('start' => '400000000000000000', 'end' => '7FFFFFFFFFFFFFFFFF'),
        72 => array('start' => '800000000000000000', 'end' => 'FFFFFFFFFFFFFFFFFF'),
        73 => array('start' => '1000000000000000000', 'end' => '1FFFFFFFFFFFFFFFFFF'),
        74 => array('start' => '2000000000000000000', 'end' => '3FFFFFFFFFFFFFFFFFF'),
        75 => array('start' => '4000000000000000000', 'end' => '7FFFFFFFFFFFFFFFFFF'),
    );

    if (!isset($puzzle_ranges[$puzzle])) {
        return new WP_REST_Response(array('status' => 'error', 'message' => 'Invalid puzzle'), 400);
    }

    $range = $puzzle_ranges[$puzzle];

    // Generate random starting point within range
    $start_int = gmp_init($range['start'], 16);
    $end_int = gmp_init($range['end'], 16);
    $range_size = gmp_sub($end_int, $start_int);

    // Random offset
    $random_offset = gmp_random_range(gmp_init(0), $range_size);
    $task_start = gmp_add($start_int, $random_offset);

    // Task end (batch_size keys)
    $task_end = gmp_add($task_start, gmp_init($batch_size));
    if (gmp_cmp($task_end, $end_int) > 0) {
        $task_end = $end_int;
    }

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'target_address' => $target_address,
        'start' => strtoupper(gmp_strval($task_start, 16)),
        'end' => strtoupper(gmp_strval($task_end, 16)),
        'batch_size' => $batch_size,
        'session_id' => $session_id,
        'source' => 'random'
    ), 200);
}

/**
 * Get work from C&C system (checks all sources for duplicates)
 */
function khbm_get_cnc_work($puzzle, $batch_size, $miner_id) {
    global $wpdb;

    // Check if sync plugin is available
    if (!function_exists('keyhunt_cnc_get_work')) {
        // Sync plugin not installed, try remote C&C
        $cnc_url = get_option('khbm_cnc_url', '');
        if (!empty($cnc_url)) {
            return khbm_get_remote_cnc_work($cnc_url, $puzzle, $batch_size, $miner_id);
        }
        return null;
    }

    // Use local C&C (sync plugin on same WordPress)
    $max_attempts = 50;

    $puzzle_ranges = array(
        66 => array('start' => '20000000000000000', 'end' => '3FFFFFFFFFFFFFFFF'),
        67 => array('start' => '40000000000000000', 'end' => '7FFFFFFFFFFFFFFFF'),
        68 => array('start' => '80000000000000000', 'end' => 'FFFFFFFFFFFFFFFFF'),
        69 => array('start' => '100000000000000000', 'end' => '1FFFFFFFFFFFFFFFFF'),
        70 => array('start' => '200000000000000000', 'end' => '3FFFFFFFFFFFFFFFFF'),
        71 => array('start' => '400000000000000000', 'end' => '7FFFFFFFFFFFFFFFFF'),
        72 => array('start' => '800000000000000000', 'end' => 'FFFFFFFFFFFFFFFFFF'),
        73 => array('start' => '1000000000000000000', 'end' => '1FFFFFFFFFFFFFFFFFF'),
        74 => array('start' => '2000000000000000000', 'end' => '3FFFFFFFFFFFFFFFFFF'),
        75 => array('start' => '4000000000000000000', 'end' => '7FFFFFFFFFFFFFFFFFF'),
    );

    if (!isset($puzzle_ranges[$puzzle])) {
        return null;
    }

    $range = $puzzle_ranges[$puzzle];
    $start_int = gmp_init($range['start'], 16);
    $end_int = gmp_init($range['end'], 16);
    $range_size = gmp_sub($end_int, $start_int);

    for ($attempt = 0; $attempt < $max_attempts; $attempt++) {
        // Generate random starting point
        $random_offset = gmp_random_range(gmp_init(0), $range_size);
        $task_start = gmp_add($start_int, $random_offset);
        $task_end = gmp_add($task_start, gmp_init($batch_size));

        if (gmp_cmp($task_end, $end_int) > 0) {
            $task_end = $end_int;
        }

        $start_hex = strtoupper(gmp_strval($task_start, 16));
        $end_hex = strtoupper(gmp_strval($task_end, 16));

        // Check ALL sources for overlaps
        if (!khbm_range_is_scanned($puzzle, $start_hex, $end_hex)) {
            return array(
                'start' => $start_hex,
                'end' => $end_hex,
                'attempts' => $attempt + 1
            );
        }
    }

    // Couldn't find unscanned range, return random anyway
    $random_offset = gmp_random_range(gmp_init(0), $range_size);
    $task_start = gmp_add($start_int, $random_offset);
    $task_end = gmp_add($task_start, gmp_init($batch_size));

    return array(
        'start' => strtoupper(gmp_strval($task_start, 16)),
        'end' => strtoupper(gmp_strval($task_end, 16)),
        'attempts' => $max_attempts,
        'warning' => 'exhausted_attempts'
    );
}

/**
 * Check if range is scanned by any source
 */
function khbm_range_is_scanned($puzzle, $start_hex, $end_hex) {
    global $wpdb;

    // Use the sync plugin function if available
    if (function_exists('keyhunt_range_is_scanned')) {
        return keyhunt_range_is_scanned($puzzle, $start_hex, $end_hex) !== false;
    }

    // Fallback: just check browser miner table
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
    $start_dec = gmp_strval(gmp_init($start_hex, 16), 10);
    $end_dec = gmp_strval(gmp_init($end_hex, 16), 10);

    $overlap = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $browser_table WHERE puzzle = %d
         AND CONV(block_start, 16, 10) <= %s AND CONV(block_end, 16, 10) >= %s",
        $puzzle, $end_dec, $start_dec
    ));

    return $overlap > 0;
}

/**
 * Get work from remote C&C server
 */
function khbm_get_remote_cnc_work($cnc_url, $puzzle, $batch_size, $miner_id) {
    $url = rtrim($cnc_url, '/') . '/cnc/get-work/' . $puzzle;
    $url .= '?batch_size=' . $batch_size . '&miner_id=' . urlencode($miner_id);

    $response = wp_remote_get($url, array(
        'timeout' => 10,
        'headers' => array(
            'Accept' => 'application/json'
        )
    ));

    if (is_wp_error($response)) {
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($data && $data['status'] === 'ok') {
        return array(
            'start' => $data['start'],
            'end' => $data['end'],
            'attempts' => $data['attempts'] ?? 1
        );
    }

    return null;
}

/**
 * Submit mining results
 */
function khbm_submit_result($request) {
    global $wpdb;

    $params = $request->get_json_params();
    $puzzle = intval($params['puzzle'] ?? 0);
    $block_start = sanitize_text_field($params['start'] ?? '');
    $block_end = sanitize_text_field($params['end'] ?? '');
    $keys_checked = intval($params['keys_checked'] ?? 0);
    $session_id = sanitize_text_field($params['session_id'] ?? '');
    $found_key = sanitize_text_field($params['found_key'] ?? '');
    $found_address = sanitize_text_field($params['found_address'] ?? '');

    if (empty($block_start) || empty($block_end)) {
        return new WP_REST_Response(array('status' => 'error'), 400);
    }

    // Hash IP and user agent for privacy
    $ip_hash = hash('sha256', $_SERVER['REMOTE_ADDR'] . 'khbm_salt_2024');
    $ua_hash = hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . 'khbm_salt_2024');

    // Save scanned block
    $table_blocks = $wpdb->prefix . KHBM_TABLE_BLOCKS;
    $wpdb->insert($table_blocks, array(
        'puzzle' => $puzzle,
        'block_start' => strtoupper($block_start),
        'block_end' => strtoupper($block_end),
        'keys_checked' => $keys_checked,
        'session_id' => $session_id,
        'ip_hash' => substr($ip_hash, 0, 16),
        'user_agent_hash' => substr($ua_hash, 0, 16)
    ));

    // Update daily stats
    $table_stats = $wpdb->prefix . KHBM_TABLE_STATS;
    $today = date('Y-m-d');
    $wpdb->query($wpdb->prepare(
        "INSERT INTO $table_stats (date, total_miners, total_keys, total_blocks)
         VALUES (%s, 1, %d, 1)
         ON DUPLICATE KEY UPDATE
            total_keys = total_keys + %d,
            total_blocks = total_blocks + 1",
        $today, $keys_checked, $keys_checked
    ));

    // If key was found - SAVE PRIVATELY!
    if (!empty($found_key)) {
        $table_found = $wpdb->prefix . KHBM_TABLE_FOUND;
        $wpdb->insert($table_found, array(
            'puzzle' => $puzzle,
            'private_key' => $found_key,
            'address' => $found_address,
            'block_start' => strtoupper($block_start),
            'block_end' => strtoupper($block_end),
            'session_id' => $session_id
        ));

        // Send email to admin
        $admin_email = get_option('admin_email');
        $subject = "BROWSER MINER FOUND KEY! Puzzle #$puzzle";
        $message = "A browser miner found a private key!\n\n";
        $message .= "Puzzle: #$puzzle\n";
        $message .= "Private Key: $found_key\n";
        $message .= "Address: $found_address\n";
        $message .= "Time: " . current_time('mysql') . "\n";
        $message .= "\nCheck WordPress admin immediately!";

        wp_mail($admin_email, $subject, $message);

        // Log to file as backup
        $log_file = WP_CONTENT_DIR . '/khbm_found_keys.log';
        file_put_contents($log_file, date('Y-m-d H:i:s') . " | Puzzle: $puzzle | Key: $found_key | Address: $found_address\n", FILE_APPEND | LOCK_EX);
    }

    // Return generic success - don't reveal if key was found
    return new WP_REST_Response(array(
        'status' => 'ok',
        'next' => true
    ), 200);
}

/**
 * Get public stats (no sensitive info)
 */
function khbm_get_public_stats($request) {
    global $wpdb;

    $table_stats = $wpdb->prefix . KHBM_TABLE_STATS;
    $table_blocks = $wpdb->prefix . KHBM_TABLE_BLOCKS;

    $total = $wpdb->get_row("SELECT SUM(total_keys) as keys_checked, SUM(total_blocks) as blocks FROM $table_stats", ARRAY_A);
    $today = $wpdb->get_row($wpdb->prepare(
        "SELECT total_keys, total_blocks FROM $table_stats WHERE date = %s",
        date('Y-m-d')
    ), ARRAY_A);

    $active_miners = $wpdb->get_var(
        "SELECT COUNT(DISTINCT session_id) FROM $table_blocks WHERE scanned_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
    );

    return new WP_REST_Response(array(
        'status' => 'ok',
        'total_keys_checked' => intval($total['keys_checked'] ?? 0),
        'total_blocks' => intval($total['blocks'] ?? 0),
        'today_keys' => intval($today['total_keys'] ?? 0),
        'active_miners' => intval($active_miners)
    ), 200);
}

/**
 * Enqueue miner script
 */
function khbm_enqueue_scripts() {
    if (get_option('khbm_enabled') !== '1') {
        return;
    }

    // Only load on frontend, not admin
    if (is_admin()) {
        return;
    }

    wp_enqueue_script(
        'khbm-miner',
        plugin_dir_url(__FILE__) . 'miner.js',
        array(),
        KHBM_VERSION,
        true
    );

    wp_localize_script('khbm-miner', 'khbm_config', array(
        'api_url' => rest_url('khbm/v1'),
        'threads' => intval(get_option('khbm_threads', 2)),
        'auto_start' => false, // User must click to start
        'widget_title' => get_option('khbm_widget_title'),
        'widget_text' => get_option('khbm_widget_text')
    ));
}
add_action('wp_enqueue_scripts', 'khbm_enqueue_scripts');

/**
 * Add miner widget to footer
 */
function khbm_add_widget() {
    if (get_option('khbm_enabled') !== '1' || is_admin()) {
        return;
    }
    ?>
    <div id="khbm-widget" style="display:none; position:fixed; bottom:20px; right:20px; background:#1a1a2e; color:#fff; padding:20px; border-radius:10px; box-shadow:0 4px 20px rgba(0,0,0,0.3); z-index:9999; max-width:320px; font-family:system-ui,-apple-system,sans-serif;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <strong id="khbm-title" style="font-size:14px;"></strong>
            <button onclick="khbmClose()" style="background:none; border:none; color:#888; cursor:pointer; font-size:18px;">&times;</button>
        </div>
        <p id="khbm-text" style="font-size:12px; color:#aaa; margin-bottom:15px;"></p>
        <div id="khbm-stats" style="font-size:11px; color:#888; margin-bottom:15px;">
            <div>Your contribution: <span id="khbm-your-keys">0</span> keys</div>
            <div>Community total: <span id="khbm-total-keys">0</span> keys</div>
            <div>Active helpers: <span id="khbm-active">0</span></div>
        </div>
        <div id="khbm-controls">
            <button id="khbm-start-btn" onclick="khbmStart()" style="width:100%; padding:10px; background:linear-gradient(135deg,#00d4ff,#00ff88); color:#000; border:none; border-radius:5px; cursor:pointer; font-weight:bold;">
                Start Helping
            </button>
        </div>
        <div id="khbm-running" style="display:none;">
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                <div class="khbm-spinner" style="width:20px; height:20px; border:2px solid #333; border-top-color:#00ff88; border-radius:50%; animation:khbm-spin 1s linear infinite;"></div>
                <span style="color:#00ff88; font-size:12px;">Mining...</span>
            </div>
            <div style="background:#333; border-radius:3px; height:6px; overflow:hidden;">
                <div id="khbm-progress" style="background:linear-gradient(90deg,#00d4ff,#00ff88); height:100%; width:0%; transition:width 0.3s;"></div>
            </div>
            <button onclick="khbmStop()" style="width:100%; margin-top:10px; padding:8px; background:#333; color:#fff; border:none; border-radius:5px; cursor:pointer; font-size:12px;">
                Pause
            </button>
        </div>
        <style>
            @keyframes khbm-spin { to { transform: rotate(360deg); } }
        </style>
    </div>
    <?php
}
add_action('wp_footer', 'khbm_add_widget');

/**
 * Admin menu
 */
function khbm_admin_menu() {
    // Include plugin functions if not available
    if (!function_exists('is_plugin_active')) {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }

    // Check if KeyHunt Sync plugin is active
    $sync_active = get_option('keyhunt_sync_menu_exists') ||
                   is_plugin_active('keyhunt-sync-plugin/keyhunt-sync.php') ||
                   is_plugin_active('keyhunt-sync/keyhunt-sync.php');

    if ($sync_active) {
        // Add as submenu under KeyHunt Sync
        add_submenu_page(
            'keyhunt-sync',
            'Browser Miner',
            'Browser Miner',
            'manage_options',
            'keyhunt-browser-miner',
            'khbm_admin_page'
        );
    } else {
        // Add as standalone top-level menu
        add_menu_page(
            'Browser Miner',
            'Browser Miner',
            'manage_options',
            'keyhunt-browser-miner',
            'khbm_admin_page',
            'dashicons-desktop',
            31
        );
    }
}
add_action('admin_menu', 'khbm_admin_menu', 10);

/**
 * Admin page
 */
function khbm_admin_page() {
    global $wpdb;

    // Handle form submission
    if (isset($_POST['khbm_save']) && wp_verify_nonce($_POST['_wpnonce'], 'khbm_settings')) {
        update_option('khbm_enabled', isset($_POST['khbm_enabled']) ? '1' : '0');
        update_option('khbm_puzzle', intval($_POST['khbm_puzzle']));
        update_option('khbm_target_address', sanitize_text_field($_POST['khbm_target_address']));
        update_option('khbm_threads', intval($_POST['khbm_threads']));
        update_option('khbm_batch_size', intval($_POST['khbm_batch_size']));
        update_option('khbm_widget_title', sanitize_text_field($_POST['khbm_widget_title']));
        update_option('khbm_widget_text', sanitize_textarea_field($_POST['khbm_widget_text']));
        update_option('khbm_use_cnc', isset($_POST['khbm_use_cnc']) ? '1' : '0');
        update_option('khbm_cnc_url', sanitize_text_field($_POST['khbm_cnc_url']));
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }

    // Get stats
    $table_blocks = $wpdb->prefix . KHBM_TABLE_BLOCKS;
    $table_found = $wpdb->prefix . KHBM_TABLE_FOUND;
    $table_stats = $wpdb->prefix . KHBM_TABLE_STATS;

    $total_blocks = $wpdb->get_var("SELECT COUNT(*) FROM $table_blocks");
    $total_keys = $wpdb->get_var("SELECT SUM(keys_checked) FROM $table_blocks");
    $found_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_found");
    $found_keys = $wpdb->get_results("SELECT * FROM $table_found ORDER BY found_at DESC", ARRAY_A);

    $active_5min = $wpdb->get_var(
        "SELECT COUNT(DISTINCT session_id) FROM $table_blocks WHERE scanned_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
    );

    ?>
    <div class="wrap">
        <h1>KeyHunt Browser Miner</h1>

        <?php if ($found_count > 0): ?>
        <div class="notice notice-success" style="border-left-color: #00ff00; background: #e8ffe8; padding: 20px;">
            <h2 style="color: #006600; margin-top: 0;">KEYS FOUND!</h2>
            <table class="widefat" style="max-width: 800px;">
                <thead>
                    <tr><th>Puzzle</th><th>Private Key</th><th>Address</th><th>Found At</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($found_keys as $key): ?>
                    <tr>
                        <td>#<?php echo esc_html($key['puzzle']); ?></td>
                        <td><code style="word-break:break-all;"><?php echo esc_html($key['private_key']); ?></code></td>
                        <td><code><?php echo esc_html($key['address']); ?></code></td>
                        <td><?php echo esc_html($key['found_at']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <div class="card" style="max-width: 600px; padding: 20px; margin-bottom: 20px;">
            <h2>Statistics</h2>
            <table class="widefat" style="max-width: 300px;">
                <tr><td>Total Blocks Scanned</td><td><strong><?php echo number_format($total_blocks); ?></strong></td></tr>
                <tr><td>Total Keys Checked</td><td><strong><?php echo number_format($total_keys); ?></strong></td></tr>
                <tr><td>Active Miners (5 min)</td><td><strong style="color:green;"><?php echo number_format($active_5min); ?></strong></td></tr>
                <tr><td>Keys Found</td><td><strong style="color:<?php echo $found_count > 0 ? 'green' : 'inherit'; ?>;"><?php echo number_format($found_count); ?></strong></td></tr>
            </table>
        </div>

        <div class="card" style="max-width: 600px; padding: 20px;">
            <h2>Settings</h2>
            <form method="post">
                <?php wp_nonce_field('khbm_settings'); ?>

                <table class="form-table">
                    <tr>
                        <th>Enable Browser Mining</th>
                        <td>
                            <label>
                                <input type="checkbox" name="khbm_enabled" value="1" <?php checked(get_option('khbm_enabled'), '1'); ?>>
                                Show mining widget to visitors
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>Puzzle Number</th>
                        <td>
                            <select name="khbm_puzzle">
                                <option value="71" <?php selected(get_option('khbm_puzzle'), '71'); ?>>Puzzle #71</option>
                                <option value="72" <?php selected(get_option('khbm_puzzle'), '72'); ?>>Puzzle #72</option>
                                <option value="73" <?php selected(get_option('khbm_puzzle'), '73'); ?>>Puzzle #73</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Target Address</th>
                        <td><input type="text" name="khbm_target_address" value="<?php echo esc_attr(get_option('khbm_target_address')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Worker Threads</th>
                        <td>
                            <input type="number" name="khbm_threads" value="<?php echo esc_attr(get_option('khbm_threads', 2)); ?>" min="1" max="8" style="width:80px;">
                            <p class="description">Number of Web Workers (1-8)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Batch Size</th>
                        <td>
                            <input type="number" name="khbm_batch_size" value="<?php echo esc_attr(get_option('khbm_batch_size', 10000)); ?>" min="1000" max="100000" style="width:100px;">
                            <p class="description">Keys per batch (1000-100000)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Widget Title</th>
                        <td><input type="text" name="khbm_widget_title" value="<?php echo esc_attr(get_option('khbm_widget_title')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Widget Text</th>
                        <td><textarea name="khbm_widget_text" rows="3" class="large-text"><?php echo esc_textarea(get_option('khbm_widget_text')); ?></textarea></td>
                    </tr>
                </table>

                <h3 style="margin-top: 30px;">Command & Control (C&C) Settings</h3>
                <p class="description">C&C ensures browser miners don't scan ranges already mined by your local KeyHunt or the btcpuzzle.info pool.</p>
                <table class="form-table">
                    <tr>
                        <th>Enable C&C Integration</th>
                        <td>
                            <label>
                                <input type="checkbox" name="khbm_use_cnc" value="1" <?php checked(get_option('khbm_use_cnc', '1'), '1'); ?>>
                                Use smart range allocation (avoids duplicate work)
                            </label>
                            <p class="description">When enabled, browser miners will avoid ranges already scanned by desktop KeyHunt, pool miners, or other browser miners.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Remote C&C URL (Optional)</th>
                        <td>
                            <input type="text" name="khbm_cnc_url" value="<?php echo esc_attr(get_option('khbm_cnc_url')); ?>" class="regular-text" placeholder="Leave empty to use local sync plugin">
                            <p class="description">If KeyHunt Sync plugin is on a different server, enter its API URL here (e.g., https://example.com/wp-json/keyhunt/v1)</p>
                        </td>
                    </tr>
                </table>

                <p><button type="submit" name="khbm_save" class="button button-primary">Save Settings</button></p>
            </form>
        </div>

        <?php
        // Show C&C Status
        $puzzle = intval(get_option('khbm_puzzle', 71));
        $sync_installed = function_exists('keyhunt_cnc_get_unified_stats') || class_exists('KeyHunt_Sync');

        // Try to get unified stats
        $cnc_stats = null;
        if (function_exists('keyhunt_get_all_scanned_ranges')) {
            $all_ranges = keyhunt_get_all_scanned_ranges($puzzle);
            $by_source = array('desktop' => 0, 'pool' => 0, 'browser' => 0);
            foreach ($all_ranges as $r) {
                if (isset($by_source[$r['source']])) {
                    $by_source[$r['source']]++;
                }
            }
            $cnc_stats = $by_source;
        }
        ?>

        <div class="card" style="max-width: 600px; padding: 20px; margin-top: 20px;">
            <h2>C&C Status for Puzzle #<?php echo esc_html($puzzle); ?></h2>
            <?php if ($sync_installed && $cnc_stats): ?>
                <table class="widefat" style="max-width: 400px;">
                    <tr>
                        <td>Sync Plugin</td>
                        <td><strong style="color: green;">Installed</strong></td>
                    </tr>
                    <tr>
                        <td>Desktop Scanned Blocks</td>
                        <td><strong style="color: #00d4ff;"><?php echo number_format($cnc_stats['desktop']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Pool Blocks (btcpuzzle.info)</td>
                        <td><strong style="color: #ff9900;"><?php echo number_format($cnc_stats['pool']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Browser Miner Blocks</td>
                        <td><strong style="color: #00ff88;"><?php echo number_format($cnc_stats['browser']); ?></strong></td>
                    </tr>
                    <tr>
                        <td><strong>Total Exclusions</strong></td>
                        <td><strong><?php echo number_format(array_sum($cnc_stats)); ?></strong></td>
                    </tr>
                </table>
                <p class="description" style="margin-top: 10px;">Browser miners will automatically avoid these <?php echo number_format(array_sum($cnc_stats)); ?> already-scanned ranges.</p>
            <?php else: ?>
                <p style="color: #666;">
                    <?php if (!$sync_installed): ?>
                        <strong>KeyHunt Sync plugin not detected.</strong><br>
                        Install the KeyHunt Sync plugin for full C&C functionality, or configure a remote C&C URL above.
                    <?php else: ?>
                        Unable to retrieve C&C statistics.
                    <?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
