# Claude Code Implementation Prompts
**Sequential prompts for implementing Smart Batch Filtering**

Use these prompts in order. Wait for Claude Code to complete each prompt before moving to the next.

---

## PROMPT 1: Project Setup & Version Bump

```
I'm integrating smart batch filtering into KeyHunt Smart Coordinator.

Context:
- Current file: keyhunt_smart_coordinator_v3.7.0.py
- Target version: v3.8.0
- Feature: Smart batch filtering to skip addresses with vanity patterns

Please:
1. Create keyhunt_smart_coordinator_v3.8.0.py (copy from v3.7.0)
2. Update these lines:
   - __version__ = "3.8.0"
   - __build_date__ = "2026-01-05"
   - __build_name__ = "Smart Batch Filtering Integration"
3. Update window title to include "v3.8.0"
4. Add comment at top of file explaining v3.8.0 changes

Show me the changes made.
```

---

## PROMPT 2: Add SmartBatchFilter Class

```
Add the SmartBatchFilter class to keyhunt_smart_coordinator_v3.8.0.py

Location: After the PoolScraper class definition (around line 200), before BlockManager

Here's the complete class to add:

```python
class SmartBatchFilter:
    """
    Pre-filter large blocks into clean sub-ranges by detecting pattern addresses.
    
    Filters out addresses with:
    - 3+ repeated characters (AAA, FFF, 111, etc.)
    - 4+ repeated characters (AAAA, FFFF, 1111, etc.)
    - All-letters (ABCDEF...) or all-numbers (123456...)
    
    This dramatically reduces search space for vanity address research.
    """
    
    def __init__(self, block_start, block_end, subrange_size=10_000_000,
                 exclude_iter3=True, exclude_iter4=False, exclude_alphanum=True):
        """
        Initialize filter.
        
        Args:
            block_start: Starting address (int)
            block_end: Ending address (int)
            subrange_size: Keys per sub-range (default 10M)
            exclude_iter3: Exclude 3+ repeated chars
            exclude_iter4: Exclude 4+ repeated chars
            exclude_alphanum: Exclude all-letters/numbers
        """
        self.block_start = block_start
        self.block_end = block_end
        self.subrange_size = subrange_size
        self.exclude_iter3 = exclude_iter3
        self.exclude_iter4 = exclude_iter4
        self.exclude_alphanum = exclude_alphanum
    
    def generate_clean_subranges(self):
        """
        Break block into sub-ranges and filter out patterns.
        
        Returns:
            List of (start, end) tuples for clean sub-ranges
        """
        clean_ranges = []
        current = self.block_start
        
        while current <= self.block_end:
            subrange_end = min(current + self.subrange_size - 1, self.block_end)
            
            # Sample 5 points in this sub-range to detect patterns
            sample_points = [
                current,
                current + self.subrange_size // 4,
                current + self.subrange_size // 2,
                current + self.subrange_size * 3 // 4,
                subrange_end
            ]
            
            # Check if ANY sample has patterns
            has_pattern = False
            for sample_addr in sample_points:
                if sample_addr > self.block_end:
                    continue
                
                skip, _ = self.check_address_for_patterns(sample_addr)
                if skip:
                    has_pattern = True
                    break
            
            # Keep only clean sub-ranges
            if not has_pattern:
                clean_ranges.append((current, subrange_end))
            
            current = subrange_end + 1
        
        return clean_ranges
    
    def check_address_for_patterns(self, address):
        """
        Check if address has patterns.
        
        Args:
            address: Address to check (int)
            
        Returns:
            (should_skip, reason) tuple
        """
        hex_str = hex(address)[2:].upper()
        
        # Check iter3
        if self.exclude_iter3 and self.has_repeated_chars(hex_str, 3):
            return True, "repeated-3+"
        
        # Check iter4
        if self.exclude_iter4 and self.has_repeated_chars(hex_str, 4):
            return True, "repeated-4+"
        
        # Check alphanum
        if self.exclude_alphanum and self.is_all_alpha_or_numeric(hex_str):
            return True, "all-alpha/numeric"
        
        return False, None
    
    def has_repeated_chars(self, hex_string, min_repeats=3):
        """
        Check if hex string has N or more repeated characters.
        
        Args:
            hex_string: Hex string to check
            min_repeats: Minimum repeats to trigger (default 3)
            
        Returns:
            True if has N+ repeated chars (ignoring zeros)
        """
        count = 1
        prev_char = ''
        
        for char in hex_string:
            if char == prev_char:
                count += 1
                # Ignore repeated zeros - they're common in valid ranges
                if count >= min_repeats and char != '0':
                    return True
            else:
                count = 1
                prev_char = char
        
        return False
    
    def is_all_alpha_or_numeric(self, hex_string):
        """
        Check if hex string is entirely letters (A-F) or numbers (0-9).
        
        Args:
            hex_string: Hex string to check
            
        Returns:
            True if all letters OR all numbers
        """
        has_alpha = any(c in 'ABCDEF' for c in hex_string)
        has_numeric = any(c in '0123456789' for c in hex_string)
        
        # XOR: true if only one type is present
        return has_alpha ^ has_numeric
```

Please add this class and confirm it's in the right location.
```

---

## PROMPT 3: Add GUI Variables in __init__

```
In the __init__ method of KeyHuntCoordinator class, add these new variables for smart filtering.

Location: In __init__, after the existing filter variables (around line 85)

Add these lines:
```python
        # Smart batch filtering settings (v3.8.0)
        self.enable_smart_filtering = None
        self.subrange_size_entry = None
        self.inter_range_delay_entry = None
        self.filter_stats_label = None
        self.last_filter_stats = {"clean": 0, "total": 0, "saved_keys": 0}
```

Please add these and show me the updated __init__ section.
```

---

## PROMPT 4: Add GUI Components to Configuration Tab

```
Add smart filtering UI controls to the Configuration tab.

Location: In create_config_page() method, find the pattern exclusion section (around line 1575). Add the new section AFTER pattern_reduction_label.

Add this complete section:

```python
        # Connect pattern filter updates
        self.exclude_iter3.connect("toggled", self.update_pattern_reduction)
        self.exclude_iter4.connect("toggled", self.update_pattern_reduction)
        self.exclude_alphanum.connect("toggled", self.update_pattern_reduction)
        
        pattern_frame.add(pattern_box)
        grid.attach(pattern_frame, 0, row, 3, 1)
        row += 1
        
        # ============================================================
        # SMART BATCH FILTERING (v3.8.0)
        # ============================================================
        
        smart_frame = Gtk.Frame(label="🚀 Smart Batch Filtering (Advanced)")
        smart_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        smart_box.set_margin_start(10)
        smart_box.set_margin_end(10)
        smart_box.set_margin_top(10)
        smart_box.set_margin_bottom(10)
        
        # Enable checkbox
        self.enable_smart_filtering = Gtk.CheckButton()
        enable_lbl = Gtk.Label()
        enable_lbl.set_markup("<span foreground='#000000' weight='bold'>Enable Smart Batch Filtering</span>")
        self.enable_smart_filtering.add(enable_lbl)
        self.enable_smart_filtering.set_active(False)
        smart_box.pack_start(self.enable_smart_filtering, False, False, 0)
        
        # Info label
        info_lbl = Gtk.Label()
        info_lbl.set_markup(
            "<span size='small' foreground='#666666'>"
            "Breaks blocks into sub-ranges and filters out pattern addresses (AAA, FFF, all-letters, etc.)\n"
            "Reduces search space by ~50-60% for vanity address vulnerability research"
            "</span>"
        )
        info_lbl.set_xalign(0)
        info_lbl.set_line_wrap(True)
        smart_box.pack_start(info_lbl, False, False, 0)
        
        # Sub-range size
        size_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        size_lbl = Gtk.Label()
        size_lbl.set_markup("<span foreground='#000000'>Sub-range Size (keys):</span>")
        size_box.pack_start(size_lbl, False, False, 0)
        
        self.subrange_size_entry = Gtk.Entry()
        self.subrange_size_entry.set_text("10000000")  # 10M default
        self.subrange_size_entry.set_width_chars(12)
        self.subrange_size_entry.set_tooltip_text("Recommended: 1M-100M keys. Smaller = better filtering but more overhead.")
        size_box.pack_start(self.subrange_size_entry, False, False, 0)
        
        size_hint = Gtk.Label()
        size_hint.set_markup("<span size='small' foreground='#888888'>(1M - 100M recommended)</span>")
        size_box.pack_start(size_hint, False, False, 0)
        smart_box.pack_start(size_box, False, False, 0)
        
        # Inter-range delay
        delay_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        delay_lbl = Gtk.Label()
        delay_lbl.set_markup("<span foreground='#000000'>Inter-range Delay (ms):</span>")
        delay_box.pack_start(delay_lbl, False, False, 0)
        
        self.inter_range_delay_entry = Gtk.Entry()
        self.inter_range_delay_entry.set_text("0")  # 0ms default (max speed)
        self.inter_range_delay_entry.set_width_chars(6)
        self.inter_range_delay_entry.set_tooltip_text("0ms = max speed, 100ms = let GPU cool between ranges")
        delay_box.pack_start(self.inter_range_delay_entry, False, False, 0)
        
        delay_hint = Gtk.Label()
        delay_hint.set_markup("<span size='small' foreground='#888888'>(0 for max speed, 100 for GPU cooling)</span>")
        delay_box.pack_start(delay_hint, False, False, 0)
        smart_box.pack_start(delay_box, False, False, 0)
        
        # Filter stats display
        self.filter_stats_label = Gtk.Label()
        self.filter_stats_label.set_markup(
            "<span foreground='#00FFFF' weight='bold'>Last filter: No data yet</span>"
        )
        self.filter_stats_label.set_xalign(0)
        smart_box.pack_start(self.filter_stats_label, False, False, 0)
        
        smart_frame.add(smart_box)
        grid.attach(smart_frame, 0, row, 3, 1)
        row += 1
```

Important: Make sure this goes AFTER the pattern exclusion frame but BEFORE the next section.

Please add this and confirm the location.
```

---

## PROMPT 5: Modify on_start() Method

```
Update the on_start() method to support smart batch filtering.

Find the on_start() method (around line 2450).

After all validation (KeyHunt path check, range validation, etc.), find where it starts the search thread. Replace the thread creation section with this:

```python
        # ... existing validation code above ...
        
        # Choose search method based on smart filtering setting
        if hasattr(self, 'enable_smart_filtering') and self.enable_smart_filtering and self.enable_smart_filtering.get_active():
            self.log("=" * 60, "info")
            self.log("🚀 SMART BATCH FILTERING ENABLED", "success")
            self.log("=" * 60, "info")
            
            try:
                subrange_size = int(self.subrange_size_entry.get_text())
                inter_range_delay = int(self.inter_range_delay_entry.get_text())
                
                self.log(f"   Sub-range size: {subrange_size:,} keys", "info")
                self.log(f"   Inter-range delay: {inter_range_delay}ms", "info")
                self.log(f"   Filters: iter3={self.exclude_iter3.get_active()}, "
                        f"iter4={self.exclude_iter4.get_active()}, "
                        f"alphanum={self.exclude_alphanum.get_active()}", "info")
                self.log("=" * 60, "info")
            except ValueError:
                self.log("❌ Invalid sub-range size or delay value", "error")
                return
            
            # Start smart batch search
            thread = threading.Thread(target=self.run_smart_batch_search, daemon=True)
        else:
            # Start normal search
            thread = threading.Thread(target=self.run_block_search, daemon=True)
        
        thread.start()
```

Please make this modification and show me the updated on_start() method around the thread creation.
```

---

## PROMPT 6: Add run_smart_batch_search() Method

```
Add the run_smart_batch_search() method.

Location: After the run_block_search() method (around line 3000)

Add this complete method:

```python
    def run_smart_batch_search(self):
        """
        Search using smart batch filtering.
        
        Breaks blocks into sub-ranges, filters out pattern addresses,
        and searches only clean sub-ranges sequentially.
        """
        # Main search loop
        while self.is_running and self.current_block_index < self.block_mgr.total_blocks:
            # Find next unscanned block
            self.find_next_block_for_batch()
            
            if not self.current_block:
                break
            
            block_start, block_end = self.current_block
            
            # Get user settings
            try:
                subrange_size = int(self.subrange_size_entry.get_text())
                inter_range_delay = int(self.inter_range_delay_entry.get_text())
            except ValueError:
                GLib.idle_add(self.log, "❌ Invalid sub-range size or delay", "error")
                self.is_running = False
                return
            
            # Pre-filter block
            GLib.idle_add(self.log, f"🔍 Pre-filtering block #{self.current_block_index}...", "info")
            
            filter_obj = SmartBatchFilter(
                block_start,
                block_end,
                subrange_size,
                exclude_iter3=self.exclude_iter3.get_active(),
                exclude_iter4=self.exclude_iter4.get_active(),
                exclude_alphanum=self.exclude_alphanum.get_active()
            )
            
            clean_ranges = filter_obj.generate_clean_subranges()
            
            # Calculate statistics
            total_ranges = (block_end - block_start) // subrange_size + 1
            clean_pct = (len(clean_ranges) / total_ranges * 100) if total_ranges > 0 else 0
            total_keys = block_end - block_start + 1
            clean_keys = sum(end - start + 1 for start, end in clean_ranges)
            skipped_keys = total_keys - clean_keys
            skipped_pct = (skipped_keys / total_keys * 100) if total_keys > 0 else 0
            
            # Update stats display
            GLib.idle_add(
                self.filter_stats_label.set_markup,
                f"<span foreground='#00FFFF' weight='bold'>"
                f"Last filter: {len(clean_ranges)}/{total_ranges} ranges ({clean_pct:.1f}%), "
                f"saved {skipped_keys:,} keys ({skipped_pct:.1f}%)"
                f"</span>"
            )
            
            # Log statistics
            GLib.idle_add(self.log, "=" * 60, "info")
            GLib.idle_add(self.log, "📊 PRE-FILTER RESULTS", "success")
            GLib.idle_add(self.log, "=" * 60, "info")
            GLib.idle_add(self.log, f"   Total sub-ranges: {total_ranges}", "info")
            GLib.idle_add(self.log, f"   Clean ranges: {len(clean_ranges)} ({clean_pct:.1f}%)", "success")
            GLib.idle_add(self.log, f"   Skipped ranges: {total_ranges - len(clean_ranges)} ({100-clean_pct:.1f}%)", "info")
            GLib.idle_add(self.log, f"   Keys to search: {clean_keys:,} ({100-skipped_pct:.1f}%)", "info")
            GLib.idle_add(self.log, f"   Keys skipped: {skipped_keys:,} ({skipped_pct:.1f}%)", "success")
            GLib.idle_add(self.log, "=" * 60, "info")
            
            if len(clean_ranges) == 0:
                GLib.idle_add(self.log, "⚠️ No clean ranges found in this block, skipping", "warning")
                self.current_block_index += 1
                continue
            
            # Search each clean sub-range
            GLib.idle_add(self.log, f"🚀 Searching {len(clean_ranges)} clean sub-ranges...", "info")
            
            for i, (range_start, range_end) in enumerate(clean_ranges):
                if not self.is_running or self.is_paused:
                    break
                
                range_num = i + 1
                range_keys = range_end - range_start + 1
                
                GLib.idle_add(self.log, 
                             f"📍 Sub-range {range_num}/{len(clean_ranges)}: "
                             f"{hex(range_start)} → {hex(range_end)} ({range_keys:,} keys)",
                             "info")
                
                # Build command for this sub-range
                cmd = self.build_keyhunt_command(range_start, range_end)
                
                try:
                    # Start KeyHunt
                    with self.process_lock:
                        self.process = subprocess.Popen(
                            cmd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            text=True,
                            bufsize=1
                        )
                    
                    # Read output (simplified - just check for matches and errors)
                    keyhunt_error = False
                    lines_read = 0
                    
                    for line in iter(self.process.stdout.readline, ''):
                        if not self.is_running or self.is_paused:
                            break
                        
                        line = line.strip()
                        if line:
                            lines_read += 1
                            
                            # Check for errors
                            if 'Wrong args' in line or 'ERROR' in line or 'Error:' in line:
                                keyhunt_error = True
                                GLib.idle_add(self.log, f"🚨 ERROR: {line}", "error")
                            
                            # Check for match
                            elif 'PubAddress:' in line or 'Priv' in line:
                                self.matches_found += 1
                                GLib.idle_add(self.matches_value.set_text, str(self.matches_found))
                                GLib.idle_add(self.log, f"🎉 MATCH FOUND: {line}", "match")
                                GLib.idle_add(self.show_match_alert, line)
                                
                                # Stop searching on match
                                self.is_running = False
                                if self.process:
                                    with self.process_lock:
                                        self.process.terminate()
                                break
                            
                            # Log speed updates
                            elif 'Mk/s' in line or 'GPU' in line:
                                GLib.idle_add(self.log, f"   {line}", "info")
                    
                    # Wait for process completion
                    with self.process_lock:
                        if self.process:
                            try:
                                self.process.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                self.process.kill()
                                self.process.wait(timeout=2)
                            self.process = None
                    
                    # Inter-range delay
                    if inter_range_delay > 0 and range_num < len(clean_ranges):
                        time.sleep(inter_range_delay / 1000.0)
                
                except Exception as e:
                    GLib.idle_add(self.log, f"❌ Error in sub-range {range_num}: {e}", "error")
                    with self.process_lock:
                        if self.process:
                            try:
                                self.process.terminate()
                                self.process.wait(timeout=2)
                            except:
                                pass
                            self.process = None
                    continue
            
            # Mark block complete
            if self.is_running:
                GLib.idle_add(self.on_block_completed)
        
        # Search complete
        if not self.current_block:
            GLib.idle_add(self.log, "✅ All blocks searched!", "success")
            self.is_running = False
    
    def find_next_block_for_batch(self):
        """Find next unscanned block for batch processing"""
        while self.current_block_index < self.block_mgr.total_blocks:
            block = self.block_mgr.get_block(self.current_block_index)
            scanned, by_whom = self.scan_db.is_block_scanned(block[0], block[1])
            
            if not scanned:
                self.current_block = block
                self.keys_checked = 0
                GLib.idle_add(self.log, 
                             f"📍 Block #{self.current_block_index}: "
                             f"{hex(block[0])} → {hex(block[1])}",
                             "info")
                GLib.idle_add(self.block_value.set_text, f"#{self.current_block_index}")
                return
            
            self.current_block_index += 1
        
        self.current_block = None
```

Please add both methods and confirm they're in the right location.
```

---

## PROMPT 7: Create Test File

```
Create a new file: integration_tests.py

This file should test the SmartBatchFilter class.

```python
#!/usr/bin/env python3
"""
Integration tests for Smart Batch Filtering v3.8.0
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the filter class
from keyhunt_smart_coordinator_v3_8_0 import SmartBatchFilter

def test_pattern_detection():
    """Test pattern detection methods"""
    print("Testing pattern detection...")
    
    filter_obj = SmartBatchFilter(0, 0, 1000000)
    
    # Test has_repeated_chars
    assert filter_obj.has_repeated_chars("7AAA", 3) == True, "Should detect AAA"
    assert filter_obj.has_repeated_chars("7AA", 3) == False, "AA is only 2"
    assert filter_obj.has_repeated_chars("7000", 3) == False, "Should ignore zeros"
    assert filter_obj.has_repeated_chars("7FFF", 3) == True, "Should detect FFF"
    assert filter_obj.has_repeated_chars("7AAAA", 4) == True, "Should detect AAAA"
    assert filter_obj.has_repeated_chars("7AAA", 4) == False, "AAA is only 3"
    
    # Test is_all_alpha_or_numeric
    assert filter_obj.is_all_alpha_or_numeric("ABCDEF") == True, "All letters"
    assert filter_obj.is_all_alpha_or_numeric("123456") == True, "All numbers"
    assert filter_obj.is_all_alpha_or_numeric("A1B2C3") == False, "Mixed"
    assert filter_obj.is_all_alpha_or_numeric("7A1B") == False, "Mixed"
    
    print("✅ Pattern detection tests passed")

def test_subrange_generation():
    """Test sub-range generation"""
    print("Testing sub-range generation...")
    
    # 10M key block
    filter_obj = SmartBatchFilter(
        0x7000000000000000,
        0x7000000000989680,
        1_000_000  # 1M per range
    )
    
    clean_ranges = filter_obj.generate_clean_subranges()
    
    assert len(clean_ranges) > 0, "Should find some clean ranges"
    assert len(clean_ranges) < 11, "Should skip some ranges (not all 10 are clean)"
    
    # Verify ranges are valid
    for start, end in clean_ranges:
        assert start < end, "Start should be less than end"
        assert start >= filter_obj.block_start, "Start should be >= block start"
        assert end <= filter_obj.block_end, "End should be <= block end"
    
    print(f"✅ Sub-range generation test passed ({len(clean_ranges)} clean ranges out of ~10)")

def test_filter_effectiveness():
    """Test that filtering achieves reasonable percentages"""
    print("Testing filter effectiveness...")
    
    # Larger block for better statistics
    filter_obj = SmartBatchFilter(
        0x7000000000000000,
        0x70000000FFFFFFFF,
        10_000_000,  # 10M per range
        exclude_iter3=True,
        exclude_iter4=True,
        exclude_alphanum=True
    )
    
    clean_ranges = filter_obj.generate_clean_subranges()
    total_ranges = (0x70000000FFFFFFFF - 0x7000000000000000) // 10_000_000 + 1
    clean_pct = (len(clean_ranges) / total_ranges * 100)
    
    print(f"   Total ranges: {total_ranges}")
    print(f"   Clean ranges: {len(clean_ranges)}")
    print(f"   Clean percentage: {clean_pct:.1f}%")
    
    # Should filter out 30-70% (we expect ~40-60% clean)
    assert 30 < clean_pct < 70, f"Clean % should be 30-70%, got {clean_pct:.1f}%"
    
    print(f"✅ Filter effectiveness test passed ({clean_pct:.1f}% clean)")

def main():
    print("="*70)
    print("Smart Batch Filtering Integration Tests")
    print("="*70)
    print()
    
    try:
        test_pattern_detection()
        print()
        test_subrange_generation()
        print()
        test_filter_effectiveness()
        print()
        print("="*70)
        print("✅ ALL TESTS PASSED!")
        print("="*70)
        return 0
    except AssertionError as e:
        print()
        print("="*70)
        print(f"❌ TEST FAILED: {e}")
        print("="*70)
        return 1
    except Exception as e:
        print()
        print("="*70)
        print(f"❌ ERROR: {e}")
        print("="*70)
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
```

Please create this file.
```

---

## PROMPT 8: Update Documentation

```
Update the file docstring at the top of keyhunt_smart_coordinator_v3.8.0.py

Find the docstring at the top (around line 2-22). Update it to:

```python
"""
KeyHunt Smart Coordinator v3.8.0
=================================
Enhanced KeyHunt GUI with:
- Hourly pool scraping (btcpuzzle.info)
- Challenge tracking (✅7FXXXXX patterns)
- Local scan tracking
- Block-based searching
- Pause/Resume with state persistence
- Automatic exclusion management
- Smart batch filtering (v3.8.0 NEW!)
- Backup/restore exclusions
- Block manager with delete functionality

v3.8.0 Changes:
- Smart Batch Filtering: Pre-filters blocks to skip pattern addresses
- Reduces search space by ~50-60% for vanity address research
- Configurable sub-range size and inter-range delay
- Real-time filtering statistics display
- Works with all existing features (pause/resume, pool coordination, etc.)

Version: 3.8.0
Build Date: 2026-01-05
Smart Filtering: Sequences sub-ranges, skips AAA/FFF/all-letters/all-numbers
"""
```

Please update this docstring.
```

---

## PROMPT 9: Final Review & Testing

```
Please review the complete v3.8.0 implementation for:

1. Code quality:
   - All methods have docstrings?
   - Error handling present?
   - Thread safety (process_lock used correctly)?
   - GUI updates use GLib.idle_add?

2. Integration:
   - New code doesn't break existing features?
   - Smart filtering can be disabled?
   - Variables properly initialized?

3. Functionality:
   - Pattern detection logic correct?
   - Sub-range generation correct?
   - Search execution correct?

Please run through the code and list any issues found.

Then, suggest a test plan for manual GUI testing.
```

---

## USAGE INSTRUCTIONS

1. Open your project in Claude Code
2. Use prompts 1-9 in sequential order
3. Wait for each prompt to complete before proceeding
4. After prompt 9, run the integration tests:
   ```bash
   python3 integration_tests.py
   ```
5. If tests pass, manually test the GUI
6. Iterate on any issues Claude Code identifies

---

## EXPECTED TIMELINE

- Prompts 1-3: 30 minutes (setup + core class)
- Prompts 4-6: 60 minutes (GUI + search logic)
- Prompts 7-9: 30 minutes (tests + review)
- **Total: ~2 hours**

---

**END OF PROMPTS DOCUMENT**
