KeyHunt Sync - WordPress Plugin
================================

This plugin allows multiple KeyHunt instances to share scan data
and avoid duplicate work when searching for Bitcoin puzzle keys.

INSTALLATION
============

1. Upload the 'keyhunt-sync-plugin' folder to your WordPress site:
   - Via FTP: Upload to /wp-content/plugins/
   - Via ZIP: Create a zip file and upload through WordPress admin
     (Plugins > Add New > Upload Plugin)

2. Activate the plugin in WordPress Admin > Plugins

3. Go to WordPress Admin > KeyHunt Sync to view your API key and stats

4. Copy your API credentials:
   - API Endpoint: https://yoursite.com/wp-json/keyhunt/v1
   - API Key: (shown on the settings page)


CONFIGURING KEYHUNT VISUALIZER
==============================

In the KeyHunt Visualizer web interface, use the API to configure sync:

Method 1 - Via API (curl):
--------------------------
curl -X POST "http://localhost:8080/api/sync/config" \
  -H "Content-Type: application/json" \
  -d '{
    "server_url": "https://yoursite.com/wp-json/keyhunt/v1",
    "api_key": "YOUR_API_KEY_HERE",
    "client_name": "Mining-PC-1",
    "enabled": true
  }'

Method 2 - Create config file manually:
---------------------------------------
Create file: sync_config.json in your KeyHunt directory with:
{
  "enabled": true,
  "server_url": "https://yoursite.com/wp-json/keyhunt/v1",
  "api_key": "YOUR_API_KEY_HERE",
  "client_id": "",
  "client_name": "Mining-PC-1",
  "auto_sync_interval": 300
}


SYNC COMMANDS (via API)
=======================

Test Connection:
  curl "http://localhost:8080/api/sync/test"

Get Sync Status:
  curl "http://localhost:8080/api/sync/config"

Trigger Sync Now:
  curl -X POST "http://localhost:8080/api/sync/now" \
    -H "Content-Type: application/json" \
    -d '{"puzzle": 71}'

Upload Local Blocks:
  curl -X POST "http://localhost:8080/api/sync/upload" \
    -H "Content-Type: application/json" \
    -d '{"puzzle": 71}'

Download Server Blocks:
  curl -X POST "http://localhost:8080/api/sync/download" \
    -H "Content-Type: application/json" \
    -d '{"puzzle": 71}'

Get Server Stats:
  curl "http://localhost:8080/api/sync/stats/71"


WORDPRESS API ENDPOINTS
=======================

All endpoints require X-KeyHunt-API-Key header.

GET  /keyhunt/v1/ping              - Test server connection
POST /keyhunt/v1/auth              - Authenticate client
POST /keyhunt/v1/blocks/upload     - Upload scanned blocks
GET  /keyhunt/v1/blocks/download/71 - Download blocks for puzzle 71
POST /keyhunt/v1/blocks/check      - Check if block was scanned
GET  /keyhunt/v1/blocks/stats/71   - Get stats for puzzle 71
POST /keyhunt/v1/sync/71           - Full bidirectional sync
POST /keyhunt/v1/found/upload      - Upload found key (JACKPOT!)
GET  /keyhunt/v1/found/list        - List all found keys
GET  /keyhunt/v1/clients           - List connected clients


MULTIPLE COMPUTER SETUP
=======================

1. Install WordPress plugin on a central server
2. On each mining computer:
   a. Run KeyHunt Visualizer
   b. Configure sync with the same API key
   c. Give each a unique client_name (e.g., "PC1", "PC2", "GPU-Server")
3. Blocks scanned by one computer will sync to all others
4. Grid view will show combined coverage from all machines


SECURITY NOTES
==============

- Keep your API key secret
- Use HTTPS for your WordPress site
- The plugin stores scanned blocks, not private keys
- Found keys are stored for notification purposes only


TROUBLESHOOTING
===============

"Sync not configured" error:
  - Check server_url and api_key are set correctly
  - Verify enabled is set to true

"HTTP 401" error:
  - API key is incorrect
  - Check the key in WordPress admin matches your config

"Connection timeout":
  - WordPress site may be down
  - Check URL is correct (should end with /wp-json/keyhunt/v1)

No blocks syncing:
  - Run sync manually: POST /api/sync/now
  - Check WordPress admin > KeyHunt Sync for received blocks
