<?php
/**
 * Plugin Name: KeyHunt Sync
 * Plugin URI: https://github.com/keyhunt
 * Description: Central sync server for KeyHunt Bitcoin puzzle mining. Allows multiple KeyHunt instances to share scan data and avoid duplicate work.
 * Version: 1.0.0
 * Author: KeyHunt Team
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('KEYHUNT_SYNC_VERSION', '1.0.0');
define('KEYHUNT_SYNC_TABLE_SCANS', 'keyhunt_scanned_blocks');
define('KEYHUNT_SYNC_TABLE_POOL', 'keyhunt_pool_blocks');
define('KEYHUNT_SYNC_TABLE_FOUND', 'keyhunt_found_keys');
define('KEYHUNT_SYNC_TABLE_CLIENTS', 'keyhunt_clients');

/**
 * Activation hook - create database tables
 */
function keyhunt_sync_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Scanned blocks table - supports variable block sizes from different sources
    // Browser: 1M keys, Pool: 35T keys, Visualizer: variable
    $table_scans = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $sql_scans = "CREATE TABLE $table_scans (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        puzzle INT(11) NOT NULL,
        block_start VARCHAR(64) NOT NULL,
        block_end VARCHAR(64) NOT NULL,
        keys_checked BIGINT(20) UNSIGNED DEFAULT 0,
        keys_in_block BIGINT(20) UNSIGNED DEFAULT 0,
        completion_pct DECIMAL(10,6) DEFAULT 0,
        client_id VARCHAR(64) NOT NULL,
        client_name VARCHAR(128),
        source_type VARCHAR(32) DEFAULT 'visualizer',
        worker_name VARCHAR(128),
        scan_rate BIGINT(20) UNSIGNED DEFAULT 0,
        scanned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        synced_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_block (puzzle, block_start),
        KEY puzzle_idx (puzzle),
        KEY client_idx (client_id),
        KEY scanned_idx (scanned_at),
        KEY source_type_idx (source_type)
    ) $charset_collate;";

    // Pool blocks table (from btcpuzzle.info scraping) - 35T keys per block
    $table_pool = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $sql_pool = "CREATE TABLE $table_pool (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        puzzle INT(11) NOT NULL,
        block_start VARCHAR(64) NOT NULL,
        block_end VARCHAR(64) NOT NULL,
        keys_in_block BIGINT(20) UNSIGNED DEFAULT 35184372088831,
        worker_name VARCHAR(128),
        scan_duration_mins DECIMAL(10,2),
        scan_rate BIGINT(20) UNSIGNED DEFAULT 0,
        scraped_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_pool_block (puzzle, block_start),
        KEY puzzle_idx (puzzle)
    ) $charset_collate;";

    // Found keys table - THE JACKPOT TABLE!
    $table_found = $wpdb->prefix . KEYHUNT_SYNC_TABLE_FOUND;
    $sql_found = "CREATE TABLE $table_found (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        puzzle INT(11) NOT NULL,
        block_start VARCHAR(64),
        block_end VARCHAR(64),
        priv_hex VARCHAR(128),
        priv_wif VARCHAR(128),
        pub_address VARCHAR(64),
        client_id VARCHAR(64),
        found_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        raw_output TEXT,
        PRIMARY KEY (id),
        KEY puzzle_idx (puzzle)
    ) $charset_collate;";

    // Clients table - track connected KeyHunt instances
    $table_clients = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;
    $sql_clients = "CREATE TABLE $table_clients (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        client_id VARCHAR(64) NOT NULL,
        client_name VARCHAR(128),
        ip_address VARCHAR(45),
        last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
        total_keys_checked BIGINT(20) UNSIGNED DEFAULT 0,
        blocks_submitted INT(11) DEFAULT 0,
        is_master TINYINT(1) DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY client_id (client_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_scans);
    dbDelta($sql_pool);
    dbDelta($sql_found);
    dbDelta($sql_clients);

    // Store plugin version
    add_option('keyhunt_sync_version', KEYHUNT_SYNC_VERSION);

    // Generate API key if not exists
    if (!get_option('keyhunt_sync_api_key')) {
        add_option('keyhunt_sync_api_key', wp_generate_password(32, false));
    }
}
register_activation_hook(__FILE__, 'keyhunt_sync_activate');

/**
 * Database upgrade function - adds new columns to existing installations
 * Called on plugin update or admin page load
 */
function keyhunt_sync_upgrade_database() {
    global $wpdb;

    $current_version = get_option('keyhunt_sync_db_version', '1.0.0');
    $new_version = '1.1.0';  // Increment when adding new columns

    if (version_compare($current_version, $new_version, '>=')) {
        return; // Already upgraded
    }

    // Scans table upgrades
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    // Check and add columns to scans table
    $scans_columns = $wpdb->get_results("SHOW COLUMNS FROM $scans_table", ARRAY_A);
    $scans_col_names = array_column($scans_columns, 'Field');

    if (!in_array('keys_in_block', $scans_col_names)) {
        $wpdb->query("ALTER TABLE $scans_table ADD COLUMN keys_in_block BIGINT(20) UNSIGNED DEFAULT 0 AFTER keys_checked");
    }
    if (!in_array('client_name', $scans_col_names)) {
        $wpdb->query("ALTER TABLE $scans_table ADD COLUMN client_name VARCHAR(128) AFTER client_id");
    }
    if (!in_array('source_type', $scans_col_names)) {
        $wpdb->query("ALTER TABLE $scans_table ADD COLUMN source_type VARCHAR(32) DEFAULT 'visualizer' AFTER client_name");
        $wpdb->query("ALTER TABLE $scans_table ADD INDEX source_type_idx (source_type)");
    }
    if (!in_array('worker_name', $scans_col_names)) {
        $wpdb->query("ALTER TABLE $scans_table ADD COLUMN worker_name VARCHAR(128) AFTER source_type");
    }
    if (!in_array('scan_rate', $scans_col_names)) {
        $wpdb->query("ALTER TABLE $scans_table ADD COLUMN scan_rate BIGINT(20) UNSIGNED DEFAULT 0 AFTER worker_name");
    }

    // Check and add columns to pool table
    $pool_columns = $wpdb->get_results("SHOW COLUMNS FROM $pool_table", ARRAY_A);
    $pool_col_names = array_column($pool_columns, 'Field');

    if (!in_array('keys_in_block', $pool_col_names)) {
        $wpdb->query("ALTER TABLE $pool_table ADD COLUMN keys_in_block BIGINT(20) UNSIGNED DEFAULT 35184372088831 AFTER block_end");
    }
    if (!in_array('worker_name', $pool_col_names)) {
        $wpdb->query("ALTER TABLE $pool_table ADD COLUMN worker_name VARCHAR(128) AFTER keys_in_block");
    }
    if (!in_array('scan_duration_mins', $pool_col_names)) {
        $wpdb->query("ALTER TABLE $pool_table ADD COLUMN scan_duration_mins DECIMAL(10,2) AFTER worker_name");
    }
    if (!in_array('scan_rate', $pool_col_names)) {
        $wpdb->query("ALTER TABLE $pool_table ADD COLUMN scan_rate BIGINT(20) UNSIGNED DEFAULT 0 AFTER scan_duration_mins");
    }

    // Check and add columns to clients table
    $clients_columns = $wpdb->get_results("SHOW COLUMNS FROM $clients_table", ARRAY_A);
    $clients_col_names = array_column($clients_columns, 'Field');

    if (!in_array('is_master', $clients_col_names)) {
        $wpdb->query("ALTER TABLE $clients_table ADD COLUMN is_master TINYINT(1) DEFAULT 0 AFTER blocks_submitted");
    }

    // Update version
    update_option('keyhunt_sync_db_version', $new_version);

    error_log("KeyHunt Sync: Database upgraded to version $new_version");
}

// Run upgrade check on admin init
add_action('admin_init', 'keyhunt_sync_upgrade_database');

/**
 * Register REST API routes
 */
function keyhunt_sync_register_routes() {
    register_rest_route('keyhunt/v1', '/ping', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_ping',
        'permission_callback' => '__return_true'
    ));

    register_rest_route('keyhunt/v1', '/auth', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_auth',
        'permission_callback' => '__return_true'
    ));

    // Scanned blocks endpoints
    register_rest_route('keyhunt/v1', '/blocks/upload', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_upload_blocks',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    register_rest_route('keyhunt/v1', '/blocks/download/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_download_blocks',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    register_rest_route('keyhunt/v1', '/blocks/check', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_check_block',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    register_rest_route('keyhunt/v1', '/blocks/stats/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_get_stats',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Pool blocks endpoints
    register_rest_route('keyhunt/v1', '/pool/upload', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_upload_pool',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    register_rest_route('keyhunt/v1', '/pool/download/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_download_pool',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Found keys endpoints
    register_rest_route('keyhunt/v1', '/found/upload', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_upload_found',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    register_rest_route('keyhunt/v1', '/found/list', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_list_found',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Clients endpoint
    register_rest_route('keyhunt/v1', '/clients', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_list_clients',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Full sync endpoint
    register_rest_route('keyhunt/v1', '/sync/(?P<puzzle>\d+)', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_full_sync',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Clear client blocks endpoint (for force resync)
    register_rest_route('keyhunt/v1', '/blocks/clear/(?P<puzzle>\d+)', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_clear_client_blocks',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Browser miner blocks endpoint
    register_rest_route('keyhunt/v1', '/browser/download/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_download_browser_blocks',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Browser miner stats
    register_rest_route('keyhunt/v1', '/browser/stats/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_sync_browser_stats',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // ========================================
    // COMMAND & CONTROL (C&C) ENDPOINTS
    // ========================================

    // Get smart work assignment (avoids all scanned ranges)
    register_rest_route('keyhunt/v1', '/cnc/get-work/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_cnc_get_work',
        'permission_callback' => '__return_true' // Public for browser miners
    ));

    // Get unified exclusion list (all sources)
    register_rest_route('keyhunt/v1', '/cnc/exclusions/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_cnc_get_exclusions',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));

    // Get unified stats across all mining sources
    register_rest_route('keyhunt/v1', '/cnc/stats/(?P<puzzle>\d+)', array(
        'methods' => 'GET',
        'callback' => 'keyhunt_cnc_get_unified_stats',
        'permission_callback' => '__return_true'
    ));

    // Register any miner (browser, desktop, etc.)
    register_rest_route('keyhunt/v1', '/cnc/register', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_cnc_register_miner',
        'permission_callback' => '__return_true'
    ));

    // Check if specific range is already scanned
    register_rest_route('keyhunt/v1', '/cnc/check-range', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_cnc_check_range',
        'permission_callback' => '__return_true'
    ));

    // Submit work from any miner type
    register_rest_route('keyhunt/v1', '/cnc/submit-work', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_cnc_submit_work',
        'permission_callback' => '__return_true'
    ));
}
add_action('rest_api_init', 'keyhunt_sync_register_routes');

/**
 * Verify API key from request header
 */
function keyhunt_sync_verify_api_key($request) {
    $api_key = $request->get_header('X-KeyHunt-API-Key');
    $stored_key = get_option('keyhunt_sync_api_key');

    if (empty($api_key) || $api_key !== $stored_key) {
        return false;
    }
    return true;
}

/**
 * Ping endpoint - check if server is alive
 */
function keyhunt_sync_ping($request) {
    return new WP_REST_Response(array(
        'status' => 'ok',
        'version' => KEYHUNT_SYNC_VERSION,
        'server_time' => current_time('mysql'),
        'message' => 'KeyHunt Sync Server Ready'
    ), 200);
}

/**
 * Auth endpoint - verify API key and register client
 */
function keyhunt_sync_auth($request) {
    $api_key = $request->get_header('X-KeyHunt-API-Key');
    $stored_key = get_option('keyhunt_sync_api_key');

    if (empty($api_key) || $api_key !== $stored_key) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Invalid API key'
        ), 401);
    }

    $params = $request->get_json_params();
    $client_id = sanitize_text_field($params['client_id'] ?? '');
    $client_name = sanitize_text_field($params['client_name'] ?? 'Unknown');

    if (empty($client_id)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'client_id required'
        ), 400);
    }

    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    // Update or insert client
    $wpdb->query($wpdb->prepare(
        "INSERT INTO $table (client_id, client_name, ip_address, last_seen)
         VALUES (%s, %s, %s, NOW())
         ON DUPLICATE KEY UPDATE client_name = %s, ip_address = %s, last_seen = NOW()",
        $client_id, $client_name, $_SERVER['REMOTE_ADDR'],
        $client_name, $_SERVER['REMOTE_ADDR']
    ));

    return new WP_REST_Response(array(
        'status' => 'ok',
        'message' => 'Authenticated successfully',
        'client_id' => $client_id
    ), 200);
}

/**
 * Upload scanned blocks
 */
function keyhunt_sync_upload_blocks($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $params = $request->get_json_params();
    $client_id = sanitize_text_field($params['client_id'] ?? '');
    $puzzle = intval($params['puzzle'] ?? 0);
    $blocks = $params['blocks'] ?? array();

    if (empty($client_id) || empty($puzzle) || empty($blocks)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Missing required fields: client_id, puzzle, blocks'
        ), 400);
    }

    $inserted = 0;
    $updated = 0;
    $total_keys = 0;

    foreach ($blocks as $block) {
        $block_start = sanitize_text_field($block['start'] ?? '');
        $block_end = sanitize_text_field($block['end'] ?? '');
        $keys_checked = intval($block['keys_checked'] ?? 0);
        $completion_pct = floatval($block['completion_pct'] ?? 100);
        $scanned_at = sanitize_text_field($block['scanned_at'] ?? current_time('mysql'));

        if (empty($block_start) || empty($block_end)) continue;

        $result = $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (puzzle, block_start, block_end, keys_checked, completion_pct, client_id, scanned_at)
             VALUES (%d, %s, %s, %d, %f, %s, %s)
             ON DUPLICATE KEY UPDATE
                block_end = IF(keys_checked < VALUES(keys_checked), VALUES(block_end), block_end),
                keys_checked = GREATEST(keys_checked, VALUES(keys_checked)),
                completion_pct = GREATEST(completion_pct, VALUES(completion_pct)),
                synced_at = NOW()",
            $puzzle, $block_start, $block_end, $keys_checked, $completion_pct, $client_id, $scanned_at
        ));

        if ($wpdb->insert_id) {
            $inserted++;
        } else {
            $updated++;
        }
        $total_keys += $keys_checked;
    }

    // Update client stats
    $wpdb->query($wpdb->prepare(
        "UPDATE $clients_table SET
            last_seen = NOW(),
            total_keys_checked = total_keys_checked + %d,
            blocks_submitted = blocks_submitted + %d
         WHERE client_id = %s",
        $total_keys, $inserted, $client_id
    ));

    return new WP_REST_Response(array(
        'status' => 'ok',
        'inserted' => $inserted,
        'updated' => $updated,
        'total_blocks' => count($blocks)
    ), 200);
}

/**
 * Download scanned blocks for a puzzle
 */
function keyhunt_sync_download_blocks($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;

    $puzzle = intval($request['puzzle']);
    $since = $request->get_param('since'); // Optional: only get blocks since timestamp
    $limit = intval($request->get_param('limit') ?? 10000);

    $where = $wpdb->prepare("puzzle = %d", $puzzle);
    if ($since) {
        $where .= $wpdb->prepare(" AND synced_at > %s", $since);
    }

    $blocks = $wpdb->get_results(
        "SELECT block_start, block_end, keys_checked, completion_pct, client_id, scanned_at
         FROM $table WHERE $where ORDER BY scanned_at DESC LIMIT $limit",
        ARRAY_A
    );

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'count' => count($blocks),
        'blocks' => $blocks
    ), 200);
}

/**
 * Check if a block has been scanned
 */
function keyhunt_sync_check_block($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;

    $params = $request->get_json_params();
    $puzzle = intval($params['puzzle'] ?? 0);
    $block_start = sanitize_text_field($params['start'] ?? '');

    if (empty($puzzle) || empty($block_start)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Missing puzzle or start'
        ), 400);
    }

    $block = $wpdb->get_row($wpdb->prepare(
        "SELECT block_start, block_end, keys_checked, completion_pct, client_id, scanned_at
         FROM $table WHERE puzzle = %d AND block_start = %s",
        $puzzle, $block_start
    ), ARRAY_A);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'scanned' => !empty($block),
        'block' => $block
    ), 200);
}

/**
 * Get stats for a puzzle
 */
function keyhunt_sync_get_stats($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $puzzle = intval($request['puzzle']);

    // Get scanned blocks stats
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT
            COUNT(*) as total_blocks,
            SUM(keys_checked) as total_keys,
            COUNT(DISTINCT client_id) as unique_clients,
            MAX(scanned_at) as last_scan
         FROM $table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    // Get pool blocks count
    $pool_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d",
        $puzzle
    ));

    // Get total clients (active in last 24 hours)
    $total_clients = $wpdb->get_var(
        "SELECT COUNT(*) FROM $clients_table WHERE last_seen > DATE_SUB(NOW(), INTERVAL 24 HOUR)"
    );

    // Get per-client stats for this puzzle
    $client_stats = $wpdb->get_results($wpdb->prepare(
        "SELECT client_id, SUM(keys_checked) as keys_checked, COUNT(*) as blocks
         FROM $table WHERE puzzle = %d GROUP BY client_id",
        $puzzle
    ), ARRAY_A);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        // Fields expected by visualizer
        'total_clients' => intval($total_clients),
        'total_blocks' => intval($stats['total_blocks']),
        'total_keys' => intval($stats['total_keys']),
        'last_activity' => $stats['last_scan'],
        // Additional fields
        'my_blocks' => intval($stats['total_blocks']),
        'pool_blocks' => intval($pool_count),
        'unique_clients' => intval($stats['unique_clients']),
        'client_breakdown' => $client_stats
    ), 200);
}

/**
 * Upload pool blocks (from btcpuzzle.info scraping)
 */
function keyhunt_sync_upload_pool($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    $params = $request->get_json_params();
    $puzzle = intval($params['puzzle'] ?? 0);
    $blocks = $params['blocks'] ?? array();

    if (empty($puzzle) || empty($blocks)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Missing puzzle or blocks'
        ), 400);
    }

    $inserted = 0;
    foreach ($blocks as $block) {
        $block_start = sanitize_text_field($block['start'] ?? '');
        $block_end = sanitize_text_field($block['end'] ?? '');

        if (empty($block_start) || empty($block_end)) continue;

        $result = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO $table (puzzle, block_start, block_end) VALUES (%d, %s, %s)",
            $puzzle, $block_start, $block_end
        ));

        if ($result) $inserted++;
    }

    return new WP_REST_Response(array(
        'status' => 'ok',
        'inserted' => $inserted
    ), 200);
}

/**
 * Download pool blocks
 */
function keyhunt_sync_download_pool($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    $puzzle = intval($request['puzzle']);

    $blocks = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start as start, block_end as end, scraped_at FROM $table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'count' => count($blocks),
        'blocks' => $blocks
    ), 200);
}

/**
 * Upload found key - JACKPOT!
 */
function keyhunt_sync_upload_found($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_FOUND;

    $params = $request->get_json_params();

    $puzzle = intval($params['puzzle'] ?? 0);
    $client_id = sanitize_text_field($params['client_id'] ?? '');
    $priv_hex = sanitize_text_field($params['priv_hex'] ?? '');
    $priv_wif = sanitize_text_field($params['priv_wif'] ?? '');
    $pub_address = sanitize_text_field($params['pub_address'] ?? '');
    $block_start = sanitize_text_field($params['block_start'] ?? '');
    $block_end = sanitize_text_field($params['block_end'] ?? '');
    $raw_output = sanitize_textarea_field($params['raw_output'] ?? '');

    $wpdb->insert($table, array(
        'puzzle' => $puzzle,
        'block_start' => $block_start,
        'block_end' => $block_end,
        'priv_hex' => $priv_hex,
        'priv_wif' => $priv_wif,
        'pub_address' => $pub_address,
        'client_id' => $client_id,
        'raw_output' => $raw_output
    ));

    // Send email notification
    $admin_email = get_option('admin_email');
    $subject = "KEY FOUND! Puzzle #$puzzle - KeyHunt Sync";
    $message = "A private key has been found!\n\n";
    $message .= "Puzzle: #$puzzle\n";
    $message .= "Address: $pub_address\n";
    $message .= "Private Key (HEX): $priv_hex\n";
    $message .= "Private Key (WIF): $priv_wif\n";
    $message .= "Client: $client_id\n";
    $message .= "Time: " . current_time('mysql') . "\n";

    wp_mail($admin_email, $subject, $message);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'message' => 'JACKPOT recorded!',
        'id' => $wpdb->insert_id
    ), 200);
}

/**
 * List found keys
 */
function keyhunt_sync_list_found($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_FOUND;

    $found = $wpdb->get_results("SELECT * FROM $table ORDER BY found_at DESC", ARRAY_A);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'count' => count($found),
        'found' => $found
    ), 200);
}

/**
 * List connected clients
 */
function keyhunt_sync_list_clients($request) {
    global $wpdb;
    $table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $clients = $wpdb->get_results(
        "SELECT client_id, client_name, ip_address, last_seen, total_keys_checked, blocks_submitted,
                TIMESTAMPDIFF(MINUTE, last_seen, NOW()) as minutes_ago
         FROM $table ORDER BY last_seen DESC",
        ARRAY_A
    );

    return new WP_REST_Response(array(
        'status' => 'ok',
        'count' => count($clients),
        'clients' => $clients
    ), 200);
}

/**
 * Full sync - upload local data and download all server data
 * Supports variable block sizes: Browser=1M keys, Pool=35T keys, Visualizer=variable
 */
function keyhunt_sync_full_sync($request) {
    global $wpdb;
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    $puzzle = intval($request['puzzle']);
    $params = $request->get_json_params();
    $client_id = sanitize_text_field($params['client_id'] ?? '');
    $client_name = sanitize_text_field($params['client_name'] ?? '');
    $is_master = $params['is_master'] ?? false;
    $local_blocks = $params['my_blocks'] ?? array();
    $local_pool = $params['pool_blocks'] ?? array();
    $local_browser = $params['browser_blocks'] ?? array();
    $last_sync = $params['last_sync'] ?? null;

    // Upload local blocks with enhanced metadata
    $uploaded = 0;
    $total_keys_uploaded = 0;
    foreach ($local_blocks as $block) {
        $keys_in_block = intval($block['keys_in_block'] ?? 0);
        $result = $wpdb->query($wpdb->prepare(
            "INSERT INTO $scans_table
             (puzzle, block_start, block_end, keys_checked, keys_in_block, completion_pct, client_id, client_name, source_type, worker_name, scan_rate, scanned_at)
             VALUES (%d, %s, %s, %d, %d, %f, %s, %s, %s, %s, %d, %s)
             ON DUPLICATE KEY UPDATE
                keys_checked = GREATEST(keys_checked, VALUES(keys_checked)),
                keys_in_block = GREATEST(keys_in_block, VALUES(keys_in_block)),
                completion_pct = GREATEST(completion_pct, VALUES(completion_pct)),
                source_type = VALUES(source_type),
                worker_name = COALESCE(VALUES(worker_name), worker_name),
                scan_rate = GREATEST(scan_rate, VALUES(scan_rate)),
                synced_at = NOW()",
            $puzzle,
            sanitize_text_field($block['start'] ?? ''),
            sanitize_text_field($block['end'] ?? ''),
            intval($block['keys_checked'] ?? 0),
            $keys_in_block,
            floatval($block['completion_pct'] ?? 100),
            $client_id,
            $client_name,
            sanitize_text_field($block['source_type'] ?? 'visualizer'),
            sanitize_text_field($block['worker_name'] ?? $client_name),
            intval($block['scan_rate'] ?? 0),
            sanitize_text_field($block['scanned_at'] ?? current_time('mysql'))
        ));
        if ($result) {
            $uploaded++;
            $total_keys_uploaded += $keys_in_block;
        }
    }

    // Upload local pool blocks with metadata (35T keys per block)
    foreach ($local_pool as $block) {
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $pool_table
             (puzzle, block_start, block_end, keys_in_block, worker_name, scan_duration_mins, scan_rate)
             VALUES (%d, %s, %s, %d, %s, %f, %d)
             ON DUPLICATE KEY UPDATE
                keys_in_block = COALESCE(VALUES(keys_in_block), keys_in_block),
                worker_name = COALESCE(VALUES(worker_name), worker_name),
                scan_duration_mins = COALESCE(VALUES(scan_duration_mins), scan_duration_mins),
                scan_rate = GREATEST(scan_rate, VALUES(scan_rate))",
            $puzzle,
            sanitize_text_field($block['start'] ?? ''),
            sanitize_text_field($block['end'] ?? ''),
            intval($block['keys_in_block'] ?? 35184372088831),
            sanitize_text_field($block['worker_name'] ?? ''),
            floatval($block['duration_mins'] ?? 0),
            intval($block['scan_rate'] ?? 0)
        ));
    }

    // Download all server blocks with enhanced metadata
    $where = $wpdb->prepare("puzzle = %d", $puzzle);
    if ($last_sync) {
        $where .= $wpdb->prepare(" AND synced_at > %s", $last_sync);
    }

    $server_blocks = $wpdb->get_results(
        "SELECT block_start as start, block_end as end, keys_checked, keys_in_block,
                completion_pct, client_id, client_name, source_type, worker_name, scan_rate, scanned_at
         FROM $scans_table WHERE $where",
        ARRAY_A
    );

    // Download pool blocks with metadata
    $server_pool = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start as start, block_end as end, keys_in_block, worker_name, scan_duration_mins as duration_mins, scan_rate
         FROM $pool_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    // Update client last seen and is_master status
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;
    $wpdb->query($wpdb->prepare(
        "UPDATE $clients_table SET last_seen = NOW(), is_master = %d WHERE client_id = %s",
        $is_master ? 1 : 0,
        $client_id
    ));

    // Get browser miner blocks (1M keys per block)
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
    $browser_blocks = array();
    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table) {
        $browser_blocks = $wpdb->get_results($wpdb->prepare(
            "SELECT block_start as start, block_end as end, keys_checked, session_id, scanned_at,
                    1000000 as keys_in_block, 'browser' as source_type
             FROM $browser_table WHERE puzzle = %d",
            $puzzle
        ), ARRAY_A);
    }

    // Calculate totals for response
    $total_keys_all = 0;
    foreach ($server_blocks as $block) {
        $total_keys_all += intval($block['keys_in_block'] ?? 0);
    }

    return new WP_REST_Response(array(
        'status' => 'ok',
        'uploaded' => $uploaded,
        'total_keys_uploaded' => $total_keys_uploaded,
        'server_blocks' => $server_blocks,
        'server_pool' => $server_pool,
        'browser_blocks' => $browser_blocks,
        'total_keys_all_clients' => $total_keys_all,
        'sync_time' => current_time('mysql')
    ), 200);
}

/**
 * Clear client blocks for force resync
 * Allows a client to delete their old blocks before re-uploading with corrected data
 */
function keyhunt_sync_clear_client_blocks($request) {
    global $wpdb;
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;

    $puzzle = intval($request['puzzle']);
    $params = $request->get_json_params();
    $client_id = sanitize_text_field($params['client_id'] ?? '');

    if (empty($client_id)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Missing client_id'
        ), 400);
    }

    // Delete all blocks for this client and puzzle
    $deleted = $wpdb->query($wpdb->prepare(
        "DELETE FROM $scans_table WHERE client_id = %s AND puzzle = %d",
        $client_id,
        $puzzle
    ));

    return new WP_REST_Response(array(
        'status' => 'ok',
        'deleted' => intval($deleted),
        'message' => "Cleared $deleted blocks for client $client_id puzzle $puzzle"
    ), 200);
}

/**
 * Download browser miner blocks
 */
function keyhunt_sync_download_browser_blocks($request) {
    global $wpdb;

    $puzzle = intval($request['puzzle']);
    $since = $request->get_param('since');
    $limit = intval($request->get_param('limit') ?? 10000);

    // Browser miner table from the browser miner plugin
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';

    // Check if table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") != $browser_table) {
        return new WP_REST_Response(array(
            'status' => 'ok',
            'puzzle' => $puzzle,
            'count' => 0,
            'blocks' => array(),
            'message' => 'Browser miner plugin not installed'
        ), 200);
    }

    $where = $wpdb->prepare("puzzle = %d", $puzzle);
    if ($since) {
        $where .= $wpdb->prepare(" AND scanned_at > %s", $since);
    }

    $blocks = $wpdb->get_results(
        "SELECT block_start as start, block_end as end, keys_checked, session_id, scanned_at
         FROM $browser_table WHERE $where ORDER BY scanned_at DESC LIMIT $limit",
        ARRAY_A
    );

    // Get total stats
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT COUNT(*) as total_blocks, SUM(keys_checked) as total_keys,
                COUNT(DISTINCT session_id) as unique_sessions
         FROM $browser_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'count' => count($blocks),
        'blocks' => $blocks,
        'total_blocks' => intval($stats['total_blocks']),
        'total_keys' => intval($stats['total_keys']),
        'unique_sessions' => intval($stats['unique_sessions'])
    ), 200);
}

/**
 * Get browser miner stats
 */
function keyhunt_sync_browser_stats($request) {
    global $wpdb;

    $puzzle = intval($request['puzzle']);
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
    $found_table = $wpdb->prefix . 'khbm_found_keys';

    // Check if table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") != $browser_table) {
        return new WP_REST_Response(array(
            'status' => 'ok',
            'puzzle' => $puzzle,
            'installed' => false,
            'total_blocks' => 0,
            'total_keys' => 0
        ), 200);
    }

    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT COUNT(*) as total_blocks, SUM(keys_checked) as total_keys,
                COUNT(DISTINCT session_id) as unique_sessions,
                MAX(scanned_at) as last_scan
         FROM $browser_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    // Check for found keys
    $found_count = 0;
    if ($wpdb->get_var("SHOW TABLES LIKE '$found_table'") == $found_table) {
        $found_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $found_table WHERE puzzle = %d",
            $puzzle
        ));
    }

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'installed' => true,
        'total_blocks' => intval($stats['total_blocks']),
        'total_keys' => intval($stats['total_keys']),
        'unique_sessions' => intval($stats['unique_sessions']),
        'last_scan' => $stats['last_scan'],
        'found_keys' => intval($found_count)
    ), 200);
}

// ========================================
// COMMAND & CONTROL (C&C) FUNCTIONS
// ========================================

/**
 * Define puzzle ranges
 */
function keyhunt_get_puzzle_ranges() {
    return array(
        66 => array('start' => '20000000000000000', 'end' => '3FFFFFFFFFFFFFFFF'),
        67 => array('start' => '40000000000000000', 'end' => '7FFFFFFFFFFFFFFFF'),
        68 => array('start' => '80000000000000000', 'end' => 'FFFFFFFFFFFFFFFFF'),
        69 => array('start' => '100000000000000000', 'end' => '1FFFFFFFFFFFFFFFFF'),
        70 => array('start' => '200000000000000000', 'end' => '3FFFFFFFFFFFFFFFFF'),
        71 => array('start' => '400000000000000000', 'end' => '7FFFFFFFFFFFFFFFFF'),
        72 => array('start' => '800000000000000000', 'end' => 'FFFFFFFFFFFFFFFFFF'),
        73 => array('start' => '1000000000000000000', 'end' => '1FFFFFFFFFFFFFFFFFF'),
        74 => array('start' => '2000000000000000000', 'end' => '3FFFFFFFFFFFFFFFFFF'),
        75 => array('start' => '4000000000000000000', 'end' => '7FFFFFFFFFFFFFFFFFF'),
    );
}

/**
 * Get all scanned ranges from ALL sources (unified exclusion list)
 */
function keyhunt_get_all_scanned_ranges($puzzle) {
    global $wpdb;

    $ranges = array();

    // 1. Desktop KeyHunt scans
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $desktop_ranges = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start, block_end FROM $scans_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);
    foreach ($desktop_ranges as $r) {
        $ranges[] = array('start' => $r['block_start'], 'end' => $r['block_end'], 'source' => 'desktop');
    }

    // 2. Pool blocks (btcpuzzle.info)
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $pool_ranges = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start, block_end FROM $pool_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);
    foreach ($pool_ranges as $r) {
        $ranges[] = array('start' => $r['block_start'], 'end' => $r['block_end'], 'source' => 'pool');
    }

    // 3. Browser miner scans
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table) {
        $browser_ranges = $wpdb->get_results($wpdb->prepare(
            "SELECT block_start, block_end FROM $browser_table WHERE puzzle = %d",
            $puzzle
        ), ARRAY_A);
        foreach ($browser_ranges as $r) {
            $ranges[] = array('start' => $r['block_start'], 'end' => $r['block_end'], 'source' => 'browser');
        }
    }

    return $ranges;
}

/**
 * Check if a range overlaps with any scanned range
 */
function keyhunt_range_is_scanned($puzzle, $start_hex, $end_hex) {
    global $wpdb;

    $start_dec = gmp_strval(gmp_init($start_hex, 16), 10);
    $end_dec = gmp_strval(gmp_init($end_hex, 16), 10);

    // Check desktop scans
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $overlap = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $scans_table WHERE puzzle = %d
         AND CONV(block_start, 16, 10) <= %s AND CONV(block_end, 16, 10) >= %s",
        $puzzle, $end_dec, $start_dec
    ));
    if ($overlap > 0) return 'desktop';

    // Check pool blocks
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $overlap = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d
         AND CONV(block_start, 16, 10) <= %s AND CONV(block_end, 16, 10) >= %s",
        $puzzle, $end_dec, $start_dec
    ));
    if ($overlap > 0) return 'pool';

    // Check browser scans
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table) {
        $overlap = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $browser_table WHERE puzzle = %d
             AND CONV(block_start, 16, 10) <= %s AND CONV(block_end, 16, 10) >= %s",
            $puzzle, $end_dec, $start_dec
        ));
        if ($overlap > 0) return 'browser';
    }

    return false;
}

/**
 * C&C: Get smart work assignment
 * Assigns ranges that haven't been scanned by ANY source
 */
function keyhunt_cnc_get_work($request) {
    global $wpdb;

    $puzzle = intval($request['puzzle']);
    $batch_size = intval($request->get_param('batch_size') ?? 10000);
    $miner_id = sanitize_text_field($request->get_param('miner_id') ?? '');
    $max_attempts = 50; // Max attempts to find unscanned range

    $puzzle_ranges = keyhunt_get_puzzle_ranges();
    if (!isset($puzzle_ranges[$puzzle])) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Invalid puzzle number'
        ), 400);
    }

    $range = $puzzle_ranges[$puzzle];
    $start_int = gmp_init($range['start'], 16);
    $end_int = gmp_init($range['end'], 16);
    $range_size = gmp_sub($end_int, $start_int);

    // Try to find an unscanned range
    for ($attempt = 0; $attempt < $max_attempts; $attempt++) {
        // Generate random starting point
        $random_offset = gmp_random_range(gmp_init(0), $range_size);
        $task_start = gmp_add($start_int, $random_offset);
        $task_end = gmp_add($task_start, gmp_init($batch_size));

        if (gmp_cmp($task_end, $end_int) > 0) {
            $task_end = $end_int;
        }

        $start_hex = strtoupper(gmp_strval($task_start, 16));
        $end_hex = strtoupper(gmp_strval($task_end, 16));

        // Check if this range is already scanned
        $scanned_by = keyhunt_range_is_scanned($puzzle, $start_hex, $end_hex);

        if (!$scanned_by) {
            // Found an unscanned range!
            return new WP_REST_Response(array(
                'status' => 'ok',
                'puzzle' => $puzzle,
                'start' => $start_hex,
                'end' => $end_hex,
                'batch_size' => $batch_size,
                'attempts' => $attempt + 1,
                'miner_id' => $miner_id
            ), 200);
        }
    }

    // Couldn't find unscanned range after max attempts
    // Return a random range anyway (better than nothing)
    $random_offset = gmp_random_range(gmp_init(0), $range_size);
    $task_start = gmp_add($start_int, $random_offset);
    $task_end = gmp_add($task_start, gmp_init($batch_size));

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'start' => strtoupper(gmp_strval($task_start, 16)),
        'end' => strtoupper(gmp_strval($task_end, 16)),
        'batch_size' => $batch_size,
        'attempts' => $max_attempts,
        'warning' => 'Could not find guaranteed unscanned range after ' . $max_attempts . ' attempts',
        'miner_id' => $miner_id
    ), 200);
}

/**
 * C&C: Get unified exclusion list
 */
function keyhunt_cnc_get_exclusions($request) {
    $puzzle = intval($request['puzzle']);
    $since = $request->get_param('since');
    $format = $request->get_param('format') ?? 'full'; // full, compact, count

    $ranges = keyhunt_get_all_scanned_ranges($puzzle);

    if ($format === 'count') {
        $by_source = array('desktop' => 0, 'pool' => 0, 'browser' => 0);
        foreach ($ranges as $r) {
            $by_source[$r['source']]++;
        }
        return new WP_REST_Response(array(
            'status' => 'ok',
            'puzzle' => $puzzle,
            'total' => count($ranges),
            'by_source' => $by_source
        ), 200);
    }

    if ($format === 'compact') {
        // Just start addresses for quick checking
        $starts = array_map(function($r) { return $r['start']; }, $ranges);
        return new WP_REST_Response(array(
            'status' => 'ok',
            'puzzle' => $puzzle,
            'count' => count($starts),
            'starts' => $starts
        ), 200);
    }

    return new WP_REST_Response(array(
        'status' => 'ok',
        'puzzle' => $puzzle,
        'count' => count($ranges),
        'ranges' => $ranges
    ), 200);
}

/**
 * C&C: Get unified stats across all mining sources
 */
function keyhunt_cnc_get_unified_stats($request) {
    global $wpdb;

    $puzzle = intval($request['puzzle']);

    $stats = array(
        'puzzle' => $puzzle,
        'desktop' => array('blocks' => 0, 'keys' => 0),
        'pool' => array('blocks' => 0),
        'browser' => array('blocks' => 0, 'keys' => 0, 'sessions' => 0),
        'total_blocks' => 0,
        'total_keys' => 0
    );

    // Desktop stats
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $desktop = $wpdb->get_row($wpdb->prepare(
        "SELECT COUNT(*) as blocks, COALESCE(SUM(keys_checked), 0) as keys
         FROM $scans_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);
    $stats['desktop'] = array(
        'blocks' => intval($desktop['blocks']),
        'keys' => intval($desktop['keys'])
    );

    // Pool stats
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $pool_blocks = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d",
        $puzzle
    ));
    $stats['pool'] = array('blocks' => intval($pool_blocks));

    // Browser stats
    $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table) {
        $browser = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) as blocks, COALESCE(SUM(keys_checked), 0) as keys,
                    COUNT(DISTINCT session_id) as sessions
             FROM $browser_table WHERE puzzle = %d",
            $puzzle
        ), ARRAY_A);
        $stats['browser'] = array(
            'blocks' => intval($browser['blocks']),
            'keys' => intval($browser['keys']),
            'sessions' => intval($browser['sessions'])
        );
    }

    // Totals
    $stats['total_blocks'] = $stats['desktop']['blocks'] + $stats['pool']['blocks'] + $stats['browser']['blocks'];
    $stats['total_keys'] = $stats['desktop']['keys'] + $stats['browser']['keys'];

    // Active miners
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;
    $stats['active_desktop_miners'] = intval($wpdb->get_var(
        "SELECT COUNT(*) FROM $clients_table WHERE last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE)"
    ));

    if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table) {
        $stats['active_browser_miners'] = intval($wpdb->get_var(
            "SELECT COUNT(DISTINCT session_id) FROM $browser_table
             WHERE scanned_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
        ));
    } else {
        $stats['active_browser_miners'] = 0;
    }

    // Last pool scrape time
    $stats['last_pool_scrape'] = get_option('keyhunt_last_pool_scrape_' . $puzzle, 'never');

    return new WP_REST_Response(array(
        'status' => 'ok',
        'stats' => $stats
    ), 200);
}

/**
 * C&C: Register a miner
 */
function keyhunt_cnc_register_miner($request) {
    global $wpdb;

    $params = $request->get_json_params();
    $miner_type = sanitize_text_field($params['type'] ?? 'unknown'); // desktop, browser, mobile
    $miner_id = sanitize_text_field($params['miner_id'] ?? '');
    $miner_name = sanitize_text_field($params['name'] ?? '');

    if (empty($miner_id)) {
        $miner_id = bin2hex(random_bytes(8));
    }

    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $wpdb->query($wpdb->prepare(
        "INSERT INTO $clients_table (client_id, client_name, ip_address, last_seen)
         VALUES (%s, %s, %s, NOW())
         ON DUPLICATE KEY UPDATE client_name = %s, ip_address = %s, last_seen = NOW()",
        $miner_id,
        $miner_name ?: $miner_type . '_' . substr($miner_id, 0, 8),
        $_SERVER['REMOTE_ADDR'],
        $miner_name ?: $miner_type . '_' . substr($miner_id, 0, 8),
        $_SERVER['REMOTE_ADDR']
    ));

    return new WP_REST_Response(array(
        'status' => 'ok',
        'miner_id' => $miner_id,
        'type' => $miner_type,
        'registered' => true
    ), 200);
}

/**
 * C&C: Check if range is scanned
 */
function keyhunt_cnc_check_range($request) {
    $params = $request->get_json_params();
    $puzzle = intval($params['puzzle'] ?? 0);
    $start = sanitize_text_field($params['start'] ?? '');
    $end = sanitize_text_field($params['end'] ?? $start);

    if (empty($puzzle) || empty($start)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Missing puzzle or start'
        ), 400);
    }

    $scanned_by = keyhunt_range_is_scanned($puzzle, $start, $end);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'scanned' => $scanned_by !== false,
        'scanned_by' => $scanned_by ?: null
    ), 200);
}

/**
 * C&C: Submit work from any miner
 */
function keyhunt_cnc_submit_work($request) {
    global $wpdb;

    $params = $request->get_json_params();
    $puzzle = intval($params['puzzle'] ?? 0);
    $start = strtoupper(sanitize_text_field($params['start'] ?? ''));
    $end = strtoupper(sanitize_text_field($params['end'] ?? ''));
    $keys_checked = intval($params['keys_checked'] ?? 0);
    $miner_id = sanitize_text_field($params['miner_id'] ?? '');
    $miner_type = sanitize_text_field($params['type'] ?? 'browser');
    $found_key = sanitize_text_field($params['found_key'] ?? '');
    $found_address = sanitize_text_field($params['found_address'] ?? '');

    if (empty($start) || empty($end) || empty($puzzle)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'Missing required fields'
        ), 400);
    }

    // Store based on miner type
    if ($miner_type === 'browser') {
        $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
        if ($wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table) {
            $ip_hash = hash('sha256', $_SERVER['REMOTE_ADDR'] . 'khbm_salt_2024');
            $wpdb->insert($browser_table, array(
                'puzzle' => $puzzle,
                'block_start' => $start,
                'block_end' => $end,
                'keys_checked' => $keys_checked,
                'session_id' => $miner_id,
                'ip_hash' => substr($ip_hash, 0, 16)
            ));
        }
    } else {
        // Desktop or other - store in main scans table
        $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $scans_table (puzzle, block_start, block_end, keys_checked, client_id, scanned_at)
             VALUES (%d, %s, %s, %d, %s, NOW())
             ON DUPLICATE KEY UPDATE
                keys_checked = GREATEST(keys_checked, VALUES(keys_checked)),
                synced_at = NOW()",
            $puzzle, $start, $end, $keys_checked, $miner_id
        ));
    }

    // Handle found key
    if (!empty($found_key)) {
        $found_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_FOUND;
        $wpdb->insert($found_table, array(
            'puzzle' => $puzzle,
            'block_start' => $start,
            'block_end' => $end,
            'priv_hex' => $found_key,
            'pub_address' => $found_address,
            'client_id' => $miner_id
        ));

        // Send email
        $admin_email = get_option('admin_email');
        $subject = "KEY FOUND! Puzzle #$puzzle - $miner_type miner";
        $message = "A private key has been found!\n\n";
        $message .= "Puzzle: #$puzzle\n";
        $message .= "Address: $found_address\n";
        $message .= "Private Key (HEX): $found_key\n";
        $message .= "Miner Type: $miner_type\n";
        $message .= "Miner ID: $miner_id\n";
        $message .= "Time: " . current_time('mysql') . "\n";
        wp_mail($admin_email, $subject, $message);
    }

    return new WP_REST_Response(array(
        'status' => 'ok',
        'recorded' => true,
        'found' => !empty($found_key)
    ), 200);
}

// ========================================
// WORDPRESS POOL SCRAPER (btcpuzzle.info)
// ========================================

/**
 * Scrape btcpuzzle.info for pool ranges
 */
function keyhunt_scrape_pool($puzzle = 71) {
    global $wpdb;

    $url = 'https://btcpuzzle.info/status';

    $response = wp_remote_get($url, array(
        'timeout' => 30,
        'headers' => array(
            'User-Agent' => 'KeyHunt-Sync/1.0'
        )
    ));

    if (is_wp_error($response)) {
        error_log('KeyHunt Pool Scrape Error: ' . $response->get_error_message());
        return array('status' => 'error', 'message' => $response->get_error_message());
    }

    $body = wp_remote_retrieve_body($response);

    // Extract range IDs using regex
    // Format: [0-9A-F]{2}X[0-9A-F]{4,5} (e.g., 50XA1EC, 47XA26C0)
    $range_pattern = '/([0-9A-Fa-f]{2})X([0-9A-Fa-f]{4,5})/';
    preg_match_all($range_pattern, $body, $matches, PREG_SET_ORDER);

    // Also extract completed challenges: ✅PPXXXXX
    $challenge_pattern = '/✅([0-9A-Fa-f]{2})XXXXX/u';
    preg_match_all($challenge_pattern, $body, $challenge_matches, PREG_SET_ORDER);

    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $inserted = 0;
    $decoded_ranges = array();

    // Decode range IDs to actual hex ranges
    foreach ($matches as $match) {
        $prefix = strtoupper($match[1]);
        $range_id = strtoupper($match[2]);

        // Check if this belongs to our puzzle (based on prefix)
        $puzzle_prefix = dechex($puzzle);
        if (strlen($puzzle_prefix) == 1) $puzzle_prefix = '0' . $puzzle_prefix;

        // Each range ID expands to 16 blocks (0-F)
        for ($i = 0; $i < 16; $i++) {
            $nibble = strtoupper(dechex($i));

            // Build block start/end based on puzzle bit length
            // For puzzle 71: range is 400000000000000000 - 7FFFFFFFFFFFFFFFFF
            $block_start = $prefix . $nibble . $range_id . str_repeat('0', 18 - strlen($prefix) - 1 - strlen($range_id));
            $block_end = $prefix . $nibble . $range_id . str_repeat('F', 18 - strlen($prefix) - 1 - strlen($range_id));

            $block_start = strtoupper($block_start);
            $block_end = strtoupper($block_end);

            $result = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO $pool_table (puzzle, block_start, block_end) VALUES (%d, %s, %s)",
                $puzzle, $block_start, $block_end
            ));

            if ($result) {
                $inserted++;
                $decoded_ranges[] = array('start' => $block_start, 'end' => $block_end);
            }
        }
    }

    // Handle completed challenges (256 blocks each)
    foreach ($challenge_matches as $match) {
        $prefix = strtoupper($match[1]);

        for ($i = 0; $i < 256; $i++) {
            $byte = strtoupper(str_pad(dechex($i), 2, '0', STR_PAD_LEFT));

            $block_start = $prefix . $byte . str_repeat('0', 18 - strlen($prefix) - 2);
            $block_end = $prefix . $byte . str_repeat('F', 18 - strlen($prefix) - 2);

            $result = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO $pool_table (puzzle, block_start, block_end) VALUES (%d, %s, %s)",
                $puzzle, $block_start, $block_end
            ));

            if ($result) $inserted++;
        }
    }

    // Update last scrape time
    update_option('keyhunt_last_pool_scrape_' . $puzzle, current_time('mysql'));

    return array(
        'status' => 'ok',
        'range_ids_found' => count($matches),
        'challenges_found' => count($challenge_matches),
        'blocks_inserted' => $inserted,
        'timestamp' => current_time('mysql')
    );
}

/**
 * Schedule pool scraping cron job
 */
function keyhunt_schedule_pool_scraper() {
    if (!wp_next_scheduled('keyhunt_pool_scrape_event')) {
        wp_schedule_event(time(), 'keyhunt_five_minutes', 'keyhunt_pool_scrape_event');
    }
}
add_action('wp', 'keyhunt_schedule_pool_scraper');

/**
 * Add custom cron interval
 */
function keyhunt_add_cron_interval($schedules) {
    $schedules['keyhunt_five_minutes'] = array(
        'interval' => 300,
        'display' => 'Every 5 Minutes'
    );
    return $schedules;
}
add_filter('cron_schedules', 'keyhunt_add_cron_interval');

/**
 * Pool scrape cron handler
 */
function keyhunt_pool_scrape_cron() {
    // Scrape for active puzzles
    $active_puzzles = array(71, 72, 73, 74, 75);
    foreach ($active_puzzles as $puzzle) {
        keyhunt_scrape_pool($puzzle);
    }
}
add_action('keyhunt_pool_scrape_event', 'keyhunt_pool_scrape_cron');

/**
 * Manual pool scrape endpoint
 */
function keyhunt_sync_manual_pool_scrape($request) {
    $puzzle = intval($request['puzzle'] ?? 71);
    $result = keyhunt_scrape_pool($puzzle);
    return new WP_REST_Response($result, 200);
}

// Add manual scrape endpoint
add_action('rest_api_init', function() {
    register_rest_route('keyhunt/v1', '/pool/scrape/(?P<puzzle>\d+)', array(
        'methods' => 'POST',
        'callback' => 'keyhunt_sync_manual_pool_scrape',
        'permission_callback' => 'keyhunt_sync_verify_api_key'
    ));
});

/**
 * Admin menu
 */
function keyhunt_sync_admin_menu() {
    $hook = add_menu_page(
        'KeyHunt Sync',
        'KeyHunt Sync',
        'manage_options',
        'keyhunt-sync',
        'keyhunt_sync_admin_page',
        'dashicons-database',
        30
    );

    // Store the hook for reference
    if ($hook) {
        update_option('keyhunt_sync_menu_exists', true);
    }
}
add_action('admin_menu', 'keyhunt_sync_admin_menu', 9);

/**
 * Format large numbers for display
 */
function keyhunt_format_keys($num) {
    if (!$num) return '0';
    $num = floatval($num);
    if ($num >= 1e15) return number_format($num / 1e15, 2) . 'P';
    if ($num >= 1e12) return number_format($num / 1e12, 2) . 'T';
    if ($num >= 1e9) return number_format($num / 1e9, 2) . 'B';
    if ($num >= 1e6) return number_format($num / 1e6, 2) . 'M';
    if ($num >= 1e3) return number_format($num / 1e3, 2) . 'K';
    return number_format($num);
}

/**
 * Calculate total keys from ranges in a table for a puzzle
 */
function keyhunt_calc_keys_for_puzzle($table, $puzzle) {
    global $wpdb;

    $ranges = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start, block_end FROM $table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    if (empty($ranges)) return '0';

    $total = gmp_init(0);
    foreach ($ranges as $r) {
        $start = ltrim($r['block_start'] ?? '0', '0x');
        $end = ltrim($r['block_end'] ?? '0', '0x');
        if (empty($start) || empty($end)) continue;

        $keys = gmp_add(gmp_sub(gmp_init($end, 16), gmp_init($start, 16)), 1);
        $total = gmp_add($total, $keys);
    }

    return gmp_strval($total);
}

/**
 * Admin page
 */
function keyhunt_sync_admin_page() {
    global $wpdb;

    // Handle API key regeneration
    if (isset($_POST['regenerate_api_key']) && wp_verify_nonce($_POST['_wpnonce'], 'keyhunt_regenerate_key')) {
        update_option('keyhunt_sync_api_key', wp_generate_password(32, false));
        echo '<div class="notice notice-success"><p>API Key regenerated!</p></div>';
    }

    // Handle manual pool scrape
    if (isset($_POST['manual_pool_scrape']) && wp_verify_nonce($_POST['_wpnonce'], 'keyhunt_pool_scrape')) {
        $scrape_puzzle = intval($_POST['scrape_puzzle'] ?? 71);
        $result = keyhunt_scrape_pool($scrape_puzzle);
        if ($result['status'] === 'ok') {
            echo '<div class="notice notice-success"><p>Pool scrape completed! Found ' . $result['range_ids_found'] . ' range IDs, inserted ' . $result['blocks_inserted'] . ' new blocks.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Pool scrape failed: ' . esc_html($result['message'] ?? 'Unknown error') . '</p></div>';
        }
    }

    // Handle clear all clients
    if (isset($_POST['clear_all_clients']) && wp_verify_nonce($_POST['_wpnonce'], 'keyhunt_clear_clients')) {
        $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;
        $deleted = $wpdb->query("DELETE FROM $clients_table");
        echo '<div class="notice notice-success"><p>Cleared all clients! ' . intval($deleted) . ' client(s) removed. Clients will re-register on their next sync.</p></div>';
    }

    // Handle clear all blocks for a puzzle
    if (isset($_POST['clear_puzzle_blocks']) && wp_verify_nonce($_POST['_wpnonce'], 'keyhunt_clear_puzzle')) {
        $puzzle = intval($_POST['clear_puzzle']);
        if ($puzzle > 0) {
            $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
            $deleted = $wpdb->query($wpdb->prepare("DELETE FROM $scans_table WHERE puzzle = %d", $puzzle));
            echo '<div class="notice notice-success"><p>Cleared all blocks for puzzle ' . $puzzle . '! ' . intval($deleted) . ' block(s) removed. Clients will re-upload on their next sync.</p></div>';
        }
    }

    // Handle clear blocks for a specific client
    if (isset($_POST['clear_client_blocks']) && wp_verify_nonce($_POST['_wpnonce'], 'keyhunt_clear_client')) {
        $client_id = sanitize_text_field($_POST['clear_client_id']);
        $puzzle = intval($_POST['clear_client_puzzle'] ?? 0);
        if (!empty($client_id)) {
            $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
            if ($puzzle > 0) {
                $deleted = $wpdb->query($wpdb->prepare("DELETE FROM $scans_table WHERE client_id = %s AND puzzle = %d", $client_id, $puzzle));
                echo '<div class="notice notice-success"><p>Cleared blocks for client ' . esc_html($client_id) . ' puzzle ' . $puzzle . '! ' . intval($deleted) . ' block(s) removed.</p></div>';
            } else {
                $deleted = $wpdb->query($wpdb->prepare("DELETE FROM $scans_table WHERE client_id = %s", $client_id));
                echo '<div class="notice notice-success"><p>Cleared all blocks for client ' . esc_html($client_id) . '! ' . intval($deleted) . ' block(s) removed.</p></div>';
            }
        }
    }

    $api_key = get_option('keyhunt_sync_api_key');
    $site_url = get_rest_url(null, 'keyhunt/v1');

    // Get stats
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $found_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_FOUND;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $total_scans = $wpdb->get_var("SELECT COUNT(*) FROM $scans_table");
    $total_keys = $wpdb->get_var("SELECT SUM(keys_checked) FROM $scans_table");
    $total_pool = $wpdb->get_var("SELECT COUNT(*) FROM $pool_table");
    $total_found = $wpdb->get_var("SELECT COUNT(*) FROM $found_table");
    $total_clients = $wpdb->get_var("SELECT COUNT(*) FROM $clients_table");
    $active_clients = $wpdb->get_var("SELECT COUNT(*) FROM $clients_table WHERE last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE)");

    // Get per-puzzle stats
    $puzzle_stats = $wpdb->get_results(
        "SELECT puzzle,
                COUNT(*) as blocks,
                SUM(keys_checked) as keys_checked,
                COUNT(DISTINCT client_id) as clients,
                MAX(scanned_at) as last_scan
         FROM $scans_table GROUP BY puzzle ORDER BY puzzle",
        ARRAY_A
    );

    // Get pool stats per puzzle
    $pool_stats = $wpdb->get_results(
        "SELECT puzzle, COUNT(*) as blocks FROM $pool_table GROUP BY puzzle",
        ARRAY_A
    );
    $pool_by_puzzle = array();
    foreach ($pool_stats as $p) {
        $pool_by_puzzle[$p['puzzle']] = $p['blocks'];
    }

    // Get recent clients with per-puzzle breakdown
    $clients = $wpdb->get_results(
        "SELECT c.*,
                TIMESTAMPDIFF(MINUTE, c.last_seen, NOW()) as minutes_ago,
                (SELECT SUM(keys_checked) FROM $scans_table WHERE client_id = c.client_id) as actual_keys
         FROM $clients_table c ORDER BY c.last_seen DESC LIMIT 20",
        ARRAY_A
    );

    // Get per-client per-puzzle breakdown
    $client_puzzle_stats = $wpdb->get_results(
        "SELECT client_id, puzzle, SUM(keys_checked) as keys_checked, COUNT(*) as blocks
         FROM $scans_table GROUP BY client_id, puzzle ORDER BY client_id, puzzle",
        ARRAY_A
    );
    $client_puzzles = array();
    foreach ($client_puzzle_stats as $stat) {
        if (!isset($client_puzzles[$stat['client_id']])) {
            $client_puzzles[$stat['client_id']] = array();
        }
        $client_puzzles[$stat['client_id']][$stat['puzzle']] = $stat;
    }

    // Get found keys
    $found_keys = $wpdb->get_results("SELECT * FROM $found_table ORDER BY found_at DESC LIMIT 10", ARRAY_A);

    ?>
    <div class="wrap">
        <h1>KeyHunt Sync Server</h1>

        <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px;">
            <h2>API Configuration</h2>
            <p><strong>API Endpoint:</strong> <code><?php echo esc_html($site_url); ?></code></p>
            <p><strong>API Key:</strong> <code style="background: #f0f0f0; padding: 5px 10px;"><?php echo esc_html($api_key); ?></code></p>
            <form method="post" style="margin-top: 10px;">
                <?php wp_nonce_field('keyhunt_regenerate_key'); ?>
                <button type="submit" name="regenerate_api_key" class="button">Regenerate API Key</button>
            </form>
        </div>

        <div class="card" style="max-width: 900px; padding: 20px; margin-bottom: 20px; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #fff;">
            <h2 style="color: #00ff88; margin-top: 0;">🎛️ Command & Control Center</h2>
            <p style="color: #aaa;">Unified coordination across all mining sources - Desktop, Pool, and Browser miners.</p>

            <?php
            // Get C&C stats for active puzzles
            $active_puzzles = array(71, 72, 73, 74, 75);
            $browser_table = $wpdb->prefix . 'khbm_scanned_blocks';
            $browser_installed = $wpdb->get_var("SHOW TABLES LIKE '$browser_table'") == $browser_table;
            ?>

            <table class="widefat" style="background: transparent; color: #fff; border: 1px solid #333;">
                <thead>
                    <tr style="background: #333;">
                        <th style="color: #fff;">Puzzle</th>
                        <th style="color: #00d4ff;">Desktop Keys (blocks)</th>
                        <th style="color: #ff9900;">Pool Keys (blocks)</th>
                        <th style="color: #00ff88;">Browser Keys (blocks)</th>
                        <th style="color: #fff;">Total Keys</th>
                        <th style="color: #fff;">Last Pool Scrape</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($active_puzzles as $puz):
                        // Desktop stats
                        $desktop_count = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM $scans_table WHERE puzzle = %d", $puz
                        ));
                        $desktop_keys = keyhunt_calc_keys_for_puzzle($scans_table, $puz);

                        // Pool stats
                        $pool_count = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d", $puz
                        ));
                        $pool_keys = keyhunt_calc_keys_for_puzzle($pool_table, $puz);

                        // Browser stats
                        $browser_count = 0;
                        $browser_keys = '0';
                        if ($browser_installed) {
                            $browser_count = $wpdb->get_var($wpdb->prepare(
                                "SELECT COUNT(*) FROM $browser_table WHERE puzzle = %d", $puz
                            ));
                            $browser_keys = keyhunt_calc_keys_for_puzzle($browser_table, $puz);
                        }

                        // Total keys (using GMP for large numbers)
                        $total_keys_gmp = gmp_add(gmp_add(gmp_init($desktop_keys), gmp_init($pool_keys)), gmp_init($browser_keys));
                        $total_keys = gmp_strval($total_keys_gmp);

                        $last_scrape = get_option('keyhunt_last_pool_scrape_' . $puz, 'Never');
                    ?>
                    <tr style="background: <?php echo $total_keys !== '0' ? '#1e3a5f' : '#1a1a2e'; ?>;">
                        <td style="color: #fff;"><strong>#<?php echo $puz; ?></strong></td>
                        <td style="color: #00d4ff;"><?php echo keyhunt_format_keys($desktop_keys); ?> <span style="color:#666;">(<?php echo number_format($desktop_count); ?>)</span></td>
                        <td style="color: #ff9900;"><?php echo keyhunt_format_keys($pool_keys); ?> <span style="color:#666;">(<?php echo number_format($pool_count); ?>)</span></td>
                        <td style="color: #00ff88;"><?php echo keyhunt_format_keys($browser_keys); ?> <span style="color:#666;">(<?php echo number_format($browser_count); ?>)</span></td>
                        <td style="color: #fff;"><strong><?php echo keyhunt_format_keys($total_keys); ?></strong></td>
                        <td style="color: #888; font-size: 11px;"><?php echo esc_html($last_scrape); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <form method="post" style="display: inline;">
                    <?php wp_nonce_field('keyhunt_pool_scrape'); ?>
                    <select name="scrape_puzzle" style="padding: 5px;">
                        <?php foreach ($active_puzzles as $puz): ?>
                        <option value="<?php echo $puz; ?>">#<?php echo $puz; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="manual_pool_scrape" class="button" style="background: #ff9900; border-color: #ff9900; color: #000;">
                        🔄 Scrape Pool Now
                    </button>
                </form>

                <div style="color: #888; font-size: 12px; padding-top: 8px;">
                    Pool auto-scrapes every 5 minutes via WordPress cron.
                    <?php if (!$browser_installed): ?>
                    <br><span style="color: #ff6666;">⚠️ Browser Miner plugin not installed</span>
                    <?php endif; ?>
                </div>
            </div>

            <div style="margin-top: 20px; padding: 15px; background: #0d1b2a; border-radius: 5px;">
                <h4 style="color: #00d4ff; margin-top: 0;">C&C API Endpoints</h4>
                <code style="color: #00ff88; font-size: 11px; display: block; margin: 5px 0;">GET <?php echo esc_html($site_url); ?>/cnc/get-work/{puzzle}</code>
                <small style="color: #888;">Smart work allocation that avoids all scanned ranges</small>
                <code style="color: #00ff88; font-size: 11px; display: block; margin: 5px 0;">GET <?php echo esc_html($site_url); ?>/cnc/stats/{puzzle}</code>
                <small style="color: #888;">Unified statistics across all mining sources</small>
                <code style="color: #00ff88; font-size: 11px; display: block; margin: 5px 0;">GET <?php echo esc_html($site_url); ?>/cnc/exclusions/{puzzle}</code>
                <small style="color: #888;">Full exclusion list from all sources (requires API key)</small>
            </div>
        </div>

        <?php
        // === ADVANCED ANALYTICS DASHBOARD ===
        // All data loaded on-demand via AJAX to prevent slow page loads
        $analytics_puzzle = isset($_GET['analytics_puzzle']) ? intval($_GET['analytics_puzzle']) : 71;
        ?>

        <!-- Advanced Analytics Dashboard - All data loaded on-demand via AJAX -->
        <div class="card" style="max-width: 1200px; padding: 20px; margin-bottom: 20px; background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 100%); color: #fff;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="color: #00ff88; margin: 0;">📊 Advanced Analytics Dashboard</h2>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <select id="analyticsPuzzleSelect" style="padding: 8px; background: #1a1a2e; color: #fff; border: 1px solid #00d4ff;">
                        <?php foreach (array(71, 72, 73, 74, 75) as $p): ?>
                        <option value="<?php echo $p; ?>" <?php selected($analytics_puzzle, $p); ?>>Puzzle #<?php echo $p; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="button" id="loadAnalyticsBtn" onclick="loadAnalyticsOverview()" class="button" style="background: #00ff88; border-color: #00ff88; color: #000; font-weight: bold;">
                        📊 Load Analytics
                    </button>
                </div>
            </div>

            <!-- Analytics Content Container - populated via AJAX -->
            <div id="analyticsContentContainer">
                <div style="text-align: center; padding: 60px 20px; color: #888;">
                    <div style="font-size: 48px; margin-bottom: 15px;">📊</div>
                    <div style="font-size: 16px; margin-bottom: 10px;">Click "Load Analytics" to view detailed statistics</div>
                    <div style="font-size: 12px; color: #666;">Data is loaded on-demand to keep the page fast</div>
                </div>
            </div>
        </div>

        <!-- Chart.js Library -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
        let analyticsChart = null;
        let prefixChart = null;

        function formatKeyhuntNumber(num) {
            if (!num) return '0';
            if (num >= 1e15) return (num / 1e15).toFixed(2) + 'P';
            if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
            if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
            if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
            if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
            return num.toLocaleString();
        }

        function loadAnalyticsOverview() {
            const puzzle = document.getElementById('analyticsPuzzleSelect').value;
            const container = document.getElementById('analyticsContentContainer');
            const btn = document.getElementById('loadAnalyticsBtn');

            btn.disabled = true;
            btn.innerHTML = '⏳ Loading...';
            container.innerHTML = '<div style="text-align: center; padding: 40px; color: #ffaa00;">⏳ Loading analytics data...</div>';

            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=keyhunt_analytics_overview&puzzle=' + puzzle)
                .then(response => response.json())
                .then(data => {
                    btn.disabled = false;
                    btn.innerHTML = '🔄 Refresh Analytics';

                    if (data.success && data.data) {
                        renderAnalyticsDashboard(data.data, puzzle);
                    } else {
                        container.innerHTML = '<div style="text-align: center; padding: 40px; color: #ff4444;">Error loading analytics: ' + (data.data || 'Unknown error') + '</div>';
                    }
                })
                .catch(err => {
                    btn.disabled = false;
                    btn.innerHTML = '📊 Load Analytics';
                    container.innerHTML = '<div style="text-align: center; padding: 40px; color: #ff4444;">Error: ' + err.message + '</div>';
                });
        }

        function renderAnalyticsDashboard(d, puzzle) {
            const container = document.getElementById('analyticsContentContainer');

            let html = `
            <!-- Coverage Overview -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
                <div style="background: #1a1a2e; padding: 15px; border-radius: 8px; border-left: 4px solid #00ff88;">
                    <div style="color: #888; font-size: 12px;">Master Keys</div>
                    <div style="color: #00ff88; font-size: 20px; font-weight: bold;">${d.master_keys}</div>
                    <div style="color: #666; font-size: 11px;">${d.master_pct}%</div>
                </div>
                <div style="background: #1a1a2e; padding: 15px; border-radius: 8px; border-left: 4px solid #00d4ff;">
                    <div style="color: #888; font-size: 12px;">Team Keys</div>
                    <div style="color: #00d4ff; font-size: 20px; font-weight: bold;">${d.team_keys}</div>
                    <div style="color: #666; font-size: 11px;">${d.team_pct}%</div>
                </div>
                <div style="background: #1a1a2e; padding: 15px; border-radius: 8px; border-left: 4px solid #aa44ff;">
                    <div style="color: #888; font-size: 12px;">Browser Keys</div>
                    <div style="color: #aa44ff; font-size: 20px; font-weight: bold;">${d.browser_keys}</div>
                    <div style="color: #666; font-size: 11px;">${d.browser_pct}%</div>
                </div>
                <div style="background: #1a1a2e; padding: 15px; border-radius: 8px; border-left: 4px solid #ff9900;">
                    <div style="color: #888; font-size: 12px;">Pool Keys</div>
                    <div style="color: #ff9900; font-size: 20px; font-weight: bold;">${d.pool_keys}</div>
                    <div style="color: #666; font-size: 11px;">${d.pool_pct}%</div>
                </div>
            </div>

            <!-- Charts Row -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                <div style="background: #1a1a2e; padding: 20px; border-radius: 8px;">
                    <h3 style="color: #fff; margin-top: 0; font-size: 14px;">Source Distribution</h3>
                    <canvas id="sourceDistributionChart" width="300" height="300"></canvas>
                </div>
                <div style="background: #1a1a2e; padding: 20px; border-radius: 8px;">
                    <h3 style="color: #fff; margin-top: 0; font-size: 14px;">Key Prefix Coverage</h3>
                    <div id="prefixBreakdownContainer" style="min-height: 200px; display: flex; align-items: center; justify-content: center;">
                        <button type="button" onclick="loadPrefixBreakdown(${puzzle})" class="button" style="background: #00d4ff; border-color: #00d4ff; color: #000;">
                            📊 Load Prefix Breakdown
                        </button>
                    </div>
                </div>
            </div>

            <!-- Progress Summary -->
            <div style="background: #1a1a2e; padding: 20px; border-radius: 8px; margin-bottom: 25px;">
                <h3 style="color: #fff; margin-top: 0; font-size: 14px;">Puzzle #${puzzle} Progress</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                    <div>
                        <div style="color: #888; font-size: 11px;">Total Keyspace</div>
                        <div style="color: #fff; font-size: 18px; font-weight: bold;">${d.total_keyspace}</div>
                    </div>
                    <div>
                        <div style="color: #888; font-size: 11px;">Total Scanned (All Sources)</div>
                        <div style="color: #00ff88; font-size: 18px; font-weight: bold;">${d.all_keys_scanned}</div>
                        <div style="color: #666; font-size: 11px;">${d.total_pct}% complete</div>
                    </div>
                    <div>
                        <div style="color: #888; font-size: 11px;">Keys Remaining</div>
                        <div style="color: #ff6b6b; font-size: 18px; font-weight: bold;">${d.keys_remaining}</div>
                    </div>
                </div>

                <!-- Progress Bar -->
                <div style="margin-top: 15px; background: #0d1b2a; border-radius: 10px; height: 20px; overflow: hidden;">
                    <div style="display: flex; height: 100%;">
                        <div style="width: ${d.progress_bars.master}%; background: #00ff88;" title="Master: ${d.master_pct}%"></div>
                        <div style="width: ${d.progress_bars.team}%; background: #00d4ff;" title="Team: ${d.team_pct}%"></div>
                        <div style="width: ${d.progress_bars.browser}%; background: #aa44ff;" title="Browser: ${d.browser_pct}%"></div>
                        <div style="width: ${d.progress_bars.pool}%; background: #ff9900;" title="Pool: ${d.pool_pct}%"></div>
                    </div>
                </div>
                <div style="display: flex; gap: 15px; margin-top: 8px; font-size: 10px;">
                    <span><span style="display: inline-block; width: 10px; height: 10px; background: #00ff88; border-radius: 2px;"></span> Master</span>
                    <span><span style="display: inline-block; width: 10px; height: 10px; background: #00d4ff; border-radius: 2px;"></span> Team</span>
                    <span><span style="display: inline-block; width: 10px; height: 10px; background: #aa44ff; border-radius: 2px;"></span> Browser</span>
                    <span><span style="display: inline-block; width: 10px; height: 10px; background: #ff9900; border-radius: 2px;"></span> Pool</span>
                </div>
            </div>

            <!-- Key Prefix Breakdown Table -->
            <div id="prefixTableContainer" style="display: none; background: #1a1a2e; padding: 20px; border-radius: 8px; margin-bottom: 25px;"></div>

            <!-- Last 100 Scanned Ranges -->
            <div style="background: #1a1a2e; padding: 20px; border-radius: 8px;">
                <h3 style="color: #fff; margin-top: 0; font-size: 14px;">Last 100 Scanned Ranges</h3>
                <div style="max-height: 400px; overflow-y: auto;">
                    <table style="width: 100%; border-collapse: collapse; color: #fff; font-size: 11px;">
                        <thead style="position: sticky; top: 0; background: #0d1b2a;">
                            <tr>
                                <th style="padding: 8px; text-align: left; border-bottom: 1px solid #333;">Time</th>
                                <th style="padding: 8px; text-align: left; border-bottom: 1px solid #333;">Client</th>
                                <th style="padding: 8px; text-align: left; border-bottom: 1px solid #333;">Type</th>
                                <th style="padding: 8px; text-align: left; border-bottom: 1px solid #333;">Start</th>
                                <th style="padding: 8px; text-align: left; border-bottom: 1px solid #333;">End</th>
                                <th style="padding: 8px; text-align: right; border-bottom: 1px solid #333;">Keys</th>
                                <th style="padding: 8px; text-align: right; border-bottom: 1px solid #333;">Completion</th>
                            </tr>
                        </thead>
                        <tbody>`;

            if (!d.recent_scans || d.recent_scans.length === 0) {
                html += '<tr><td colspan="7" style="padding: 20px; text-align: center; color: #666;">No scans recorded yet</td></tr>';
            } else {
                d.recent_scans.forEach(scan => {
                    const typeColor = scan.is_master ? '#00ff88' : '#00d4ff';
                    const icon = scan.is_master ? '👑' : '👤';
                    const type = scan.is_master ? 'Master' : 'Team';
                    const completionHtml = scan.completion_pct >= 100
                        ? '<span style="color: #00ff88;">✓ 100%</span>'
                        : '<span style="color: #ffaa00;">' + scan.completion_pct.toFixed(1) + '%</span>';

                    html += `<tr style="border-bottom: 1px solid #222;">
                        <td style="padding: 8px; color: #888;">${scan.time}</td>
                        <td style="padding: 8px;"><span style="color: ${typeColor};">${icon} ${scan.client_name}</span></td>
                        <td style="padding: 8px; color: ${typeColor};">${type}</td>
                        <td style="padding: 8px; font-family: monospace; color: #00d4ff;">0x${scan.block_start}...</td>
                        <td style="padding: 8px; font-family: monospace; color: #00d4ff;">0x${scan.block_end}...</td>
                        <td style="padding: 8px; text-align: right; color: #00ff88;">${scan.keys_checked}</td>
                        <td style="padding: 8px; text-align: right;">${completionHtml}</td>
                    </tr>`;
                });
            }

            html += `</tbody></table></div></div>`;

            container.innerHTML = html;

            // Create source distribution chart
            setTimeout(() => {
                const ctx = document.getElementById('sourceDistributionChart');
                if (ctx) {
                    if (analyticsChart) analyticsChart.destroy();
                    analyticsChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: ['Master', 'Team', 'Browser', 'Pool'],
                            datasets: [{
                                data: [d.chart_data.master, d.chart_data.team, d.chart_data.browser, d.chart_data.pool],
                                backgroundColor: ['#00ff88', '#00d4ff', '#aa44ff', '#ff9900'],
                                borderColor: '#1a1a2e',
                                borderWidth: 2
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { position: 'bottom', labels: { color: '#fff', font: { size: 11 } } },
                                tooltip: { callbacks: { label: ctx => ctx.label + ': ' + formatKeyhuntNumber(ctx.raw) } }
                            }
                        }
                    });
                }
            }, 100);
        }

        function loadPrefixBreakdown(puzzle) {
            const container = document.getElementById('prefixBreakdownContainer');
            const tableContainer = document.getElementById('prefixTableContainer');

            container.innerHTML = '<div style="color: #ffaa00;">⏳ Loading...</div>';

            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=keyhunt_prefix_breakdown&puzzle=' + puzzle)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.data) {
                        const stats = data.data;
                        const labels = stats.map(s => s.label);
                        const values = stats.map(s => s.percentage);

                        container.innerHTML = '<canvas id="prefixChart" width="300" height="250"></canvas>';

                        if (prefixChart) prefixChart.destroy();
                        prefixChart = new Chart(document.getElementById('prefixChart'), {
                            type: 'bar',
                            data: {
                                labels: labels,
                                datasets: [{ label: 'Coverage %', data: values, backgroundColor: '#00d4ff', borderColor: '#00d4ff', borderWidth: 1 }]
                            },
                            options: {
                                responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                                scales: {
                                    x: { beginAtZero: true, grid: { color: '#333' }, ticks: { color: '#888', callback: v => v.toFixed(6) + '%' } },
                                    y: { grid: { display: false }, ticks: { color: '#00d4ff', font: { family: 'monospace' } } }
                                },
                                plugins: { legend: { display: false } }
                            }
                        });

                        let tableHtml = '<h3 style="color: #fff; margin-top: 0; font-size: 14px;">Key Prefix Breakdown</h3>';
                        tableHtml += '<table style="width: 100%; border-collapse: collapse; color: #fff;"><thead><tr style="background: #0d1b2a;">';
                        tableHtml += '<th style="padding: 10px; text-align: left; border-bottom: 1px solid #333;">Prefix</th>';
                        tableHtml += '<th style="padding: 10px; text-align: right; border-bottom: 1px solid #333;">Range Size</th>';
                        tableHtml += '<th style="padding: 10px; text-align: right; border-bottom: 1px solid #333;">Keys Scanned</th>';
                        tableHtml += '<th style="padding: 10px; text-align: right; border-bottom: 1px solid #333;">Progress</th></tr></thead><tbody>';

                        stats.forEach(s => {
                            tableHtml += `<tr style="background: ${s.percentage > 0 ? '#1e3a5f' : 'transparent'};">`;
                            tableHtml += `<td style="padding: 10px; font-family: monospace; color: #00d4ff;">${s.label}</td>`;
                            tableHtml += `<td style="padding: 10px; text-align: right;">${s.range_size_fmt}</td>`;
                            tableHtml += `<td style="padding: 10px; text-align: right; color: #00ff88;">${s.keys_scanned_fmt}</td>`;
                            tableHtml += `<td style="padding: 10px; text-align: right;"><div style="display: flex; align-items: center; justify-content: flex-end; gap: 10px;">`;
                            tableHtml += `<div style="width: 100px; background: #0d1b2a; border-radius: 4px; height: 8px; overflow: hidden;">`;
                            tableHtml += `<div style="width: ${Math.min(s.percentage, 100)}%; background: #00ff88; height: 100%;"></div></div>`;
                            tableHtml += `<span style="font-size: 11px; min-width: 60px;">${s.percentage.toFixed(6)}%</span></div></td></tr>`;
                        });

                        tableHtml += '</tbody></table>';
                        tableContainer.innerHTML = tableHtml;
                        tableContainer.style.display = 'block';
                    } else {
                        container.innerHTML = '<div style="color: #ff4444;">Error loading data</div>';
                    }
                })
                .catch(err => {
                    container.innerHTML = '<div style="color: #ff4444;">Error: ' + err.message + '</div>';
                });
        }
        </script>

        <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px;">
            <h2>Overall Statistics</h2>
            <table class="widefat" style="max-width: 500px;">
                <tr><td>Total Scanned Blocks (My Scans)</td><td><strong style="color: #00d4ff;"><?php echo number_format($total_scans); ?></strong></td></tr>
                <tr><td>Total Keys Checked (My Scans)</td><td><strong style="color: #00ff88;"><?php echo keyhunt_format_keys($total_keys); ?></strong></td></tr>
                <tr><td>Pool Blocks Tracked</td><td><strong style="color: #ff9900;"><?php echo number_format($total_pool); ?></strong></td></tr>
                <tr><td>Keys Found</td><td><strong style="color: <?php echo $total_found > 0 ? 'green' : 'inherit'; ?>"><?php echo number_format($total_found); ?></strong></td></tr>
                <tr><td>Total Clients</td><td><strong><?php echo number_format($total_clients); ?></strong></td></tr>
                <tr><td>Active Clients (10 min)</td><td><strong style="color: green;"><?php echo number_format($active_clients); ?></strong></td></tr>
            </table>
        </div>

        <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px;">
            <h2>Statistics by Puzzle</h2>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Puzzle</th>
                        <th>My Blocks</th>
                        <th>My Keys Checked</th>
                        <th>Pool Blocks</th>
                        <th>Clients</th>
                        <th>Last Activity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($puzzle_stats)): ?>
                    <tr><td colspan="7" style="text-align: center; color: #888;">No data yet</td></tr>
                    <?php else: ?>
                    <?php foreach ($puzzle_stats as $stat): ?>
                    <tr>
                        <td><strong>#<?php echo esc_html($stat['puzzle']); ?></strong></td>
                        <td style="color: #00d4ff;"><?php echo number_format($stat['blocks']); ?></td>
                        <td style="color: #00ff88;"><?php echo keyhunt_format_keys($stat['keys_checked']); ?></td>
                        <td style="color: #ff9900;"><?php echo number_format($pool_by_puzzle[$stat['puzzle']] ?? 0); ?></td>
                        <td><?php echo $stat['clients']; ?></td>
                        <td><?php echo esc_html($stat['last_scan']); ?></td>
                        <td>
                            <form method="post" style="margin: 0; display: inline;" onsubmit="return confirm('Clear ALL blocks for puzzle <?php echo esc_attr($stat['puzzle']); ?>? Clients will re-upload on next sync.');">
                                <?php wp_nonce_field('keyhunt_clear_puzzle'); ?>
                                <input type="hidden" name="clear_puzzle" value="<?php echo esc_attr($stat['puzzle']); ?>" />
                                <button type="submit" name="clear_puzzle_blocks" class="button button-small" style="color: #a00;">Clear</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_found > 0): ?>
        <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px; border-left: 4px solid green;">
            <h2 style="color: green;">Found Keys</h2>
            <table class="widefat">
                <thead>
                    <tr><th>Puzzle</th><th>Address</th><th>Private Key (HEX)</th><th>Client</th><th>Found At</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($found_keys as $key): ?>
                    <tr>
                        <td>#<?php echo esc_html($key['puzzle']); ?></td>
                        <td><code><?php echo esc_html($key['pub_address']); ?></code></td>
                        <td><code style="font-size: 10px;"><?php echo esc_html(substr($key['priv_hex'], 0, 20)); ?>...</code></td>
                        <td><?php echo esc_html($key['client_id']); ?></td>
                        <td><?php echo esc_html($key['found_at']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <div class="card" style="max-width: 900px; padding: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h2 style="margin: 0;">Connected Clients</h2>
                <form method="post" style="margin: 0;" onsubmit="return confirm('Are you sure you want to clear ALL clients? They will re-register on their next sync.');">
                    <?php wp_nonce_field('keyhunt_clear_clients'); ?>
                    <button type="submit" name="clear_all_clients" class="button" style="color: #a00;">
                        Clear All Clients
                    </button>
                </form>
            </div>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Client</th>
                        <th>IP</th>
                        <th>Last Seen</th>
                        <th>Total Keys</th>
                        <th>Total Blocks</th>
                        <th>Puzzle Breakdown</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($clients)): ?>
                    <tr><td colspan="8" style="text-align: center; color: #888;">No clients connected yet</td></tr>
                    <?php else: ?>
                    <?php foreach ($clients as $client): ?>
                    <tr>
                        <td><strong><?php echo esc_html($client['client_name'] ?: $client['client_id']); ?></strong></td>
                        <td><code style="font-size: 11px;"><?php echo esc_html($client['ip_address']); ?></code></td>
                        <td><?php echo esc_html($client['minutes_ago']); ?> min ago</td>
                        <td style="color: #00ff88;"><strong><?php echo keyhunt_format_keys($client['actual_keys'] ?: $client['total_keys_checked']); ?></strong></td>
                        <td><?php echo number_format($client['blocks_submitted']); ?></td>
                        <td style="font-size: 11px;">
                            <?php
                            if (isset($client_puzzles[$client['client_id']])) {
                                $parts = array();
                                foreach ($client_puzzles[$client['client_id']] as $puzzle => $pstat) {
                                    $parts[] = "#$puzzle: " . keyhunt_format_keys($pstat['keys_checked']) . " (" . $pstat['blocks'] . " blocks)";
                                }
                                echo esc_html(implode(', ', $parts));
                            } else {
                                echo '<span style="color: #888;">-</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <?php if ($client['minutes_ago'] < 10): ?>
                                <span style="color: green;">● Online</span>
                            <?php elseif ($client['minutes_ago'] < 60): ?>
                                <span style="color: orange;">● Away</span>
                            <?php else: ?>
                                <span style="color: gray;">○ Offline</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" style="margin: 0; display: inline;" onsubmit="return confirm('Clear ALL blocks for client <?php echo esc_attr($client['client_id']); ?>?');">
                                <?php wp_nonce_field('keyhunt_clear_client'); ?>
                                <input type="hidden" name="clear_client_id" value="<?php echo esc_attr($client['client_id']); ?>" />
                                <button type="submit" name="clear_client_blocks" class="button button-small" style="color: #a00;">Clear</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Grid Visualization Section -->
        <div class="card" style="max-width: 1200px; padding: 20px; margin-top: 20px;">
            <h2>Keyspace Visualization</h2>
            <p style="color: #666;">Visual representation of scanned keyspace for each puzzle.</p>

            <div style="margin-bottom: 15px;">
                <label for="viz-puzzle-select">Select Puzzle: </label>
                <select id="viz-puzzle-select" onchange="loadKeyhuntGrid(this.value)">
                    <option value="71">Puzzle #71</option>
                    <option value="72">Puzzle #72</option>
                    <option value="73">Puzzle #73</option>
                    <option value="74">Puzzle #74</option>
                    <option value="75">Puzzle #75</option>
                </select>
                <button type="button" class="button" onclick="loadKeyhuntGrid(document.getElementById('viz-puzzle-select').value)" style="margin-left: 10px;">Refresh</button>
            </div>

            <div id="keyhunt-grid-container">
                <p style="color: #888; text-align: center;">Select a puzzle to view the grid visualization.</p>
            </div>

            <div style="margin-top: 15px; display: flex; gap: 20px; flex-wrap: wrap;">
                <div><span style="display: inline-block; width: 16px; height: 16px; background: linear-gradient(135deg, #1e5f3a, #00ff88); border-radius: 3px; vertical-align: middle;"></span> Local Scans</div>
                <div><span style="display: inline-block; width: 16px; height: 16px; background: linear-gradient(135deg, #2a4a5f, #00d4ff); border-radius: 3px; vertical-align: middle;"></span> Team Synced</div>
                <div><span style="display: inline-block; width: 16px; height: 16px; background: linear-gradient(135deg, #1e3a5f, #4a9eff); border-radius: 3px; vertical-align: middle;"></span> Pool Data</div>
                <div><span style="display: inline-block; width: 16px; height: 16px; background: linear-gradient(135deg, #4a1e5f, #aa44ff); border-radius: 3px; vertical-align: middle;"></span> Browser Miners</div>
                <div><span style="display: inline-block; width: 16px; height: 16px; background: linear-gradient(135deg, #5f4a1e, #ffaa00); border-radius: 3px; vertical-align: middle;"></span> Multiple Sources</div>
                <div><span style="display: inline-block; width: 16px; height: 16px; background: #1a1a2e; border: 1px solid #444; border-radius: 3px; vertical-align: middle;"></span> Unscanned</div>
            </div>

            <h3 style="margin-top: 25px;">Shortcodes</h3>
            <p style="color: #666;">Use these shortcodes to display KeyHunt data on your site:</p>
            <table class="widefat" style="max-width: 800px;">
                <thead><tr><th>Shortcode</th><th>Description</th><th>Example</th></tr></thead>
                <tbody>
                    <tr>
                        <td><code>[keyhunt_grid]</code></td>
                        <td>Display the visual grid for a puzzle</td>
                        <td><code>[keyhunt_grid puzzle="71" divisions="16"]</code></td>
                    </tr>
                    <tr>
                        <td><code>[keyhunt_stats]</code></td>
                        <td>Display overall statistics</td>
                        <td><code>[keyhunt_stats]</code></td>
                    </tr>
                    <tr>
                        <td><code>[keyhunt_progress]</code></td>
                        <td>Display a progress bar for a puzzle</td>
                        <td><code>[keyhunt_progress puzzle="71"]</code></td>
                    </tr>
                    <tr>
                        <td><code>[keyhunt_clients]</code></td>
                        <td>Display connected clients</td>
                        <td><code>[keyhunt_clients]</code></td>
                    </tr>
                    <tr>
                        <td><code>[keyhunt_leaderboard]</code></td>
                        <td>Display top contributors</td>
                        <td><code>[keyhunt_leaderboard limit="10"]</code></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <style>
        .keyhunt-grid {
            display: grid;
            grid-template-columns: repeat(16, 1fr);
            gap: 2px;
            background: #1a1a2e;
            padding: 10px;
            border-radius: 8px;
            max-width: 100%;
        }
        .keyhunt-grid .cell {
            aspect-ratio: 1;
            border-radius: 3px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 9px;
            color: #fff;
            text-shadow: 0 0 2px #000;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            min-height: 30px;
        }
        .keyhunt-grid .cell:hover {
            transform: scale(1.1);
            box-shadow: 0 0 10px rgba(0, 212, 255, 0.5);
            z-index: 10;
        }
        .keyhunt-grid .cell.empty { background: #1a1a2e; border: 1px solid #333; }
        .keyhunt-grid .cell.local { background: linear-gradient(135deg, #1e5f3a, #00ff88); }
        .keyhunt-grid .cell.synced { background: linear-gradient(135deg, #2a4a5f, #00d4ff); }
        .keyhunt-grid .cell.pool { background: linear-gradient(135deg, #1e3a5f, #4a9eff); }
        .keyhunt-grid .cell.browser { background: linear-gradient(135deg, #4a1e5f, #aa44ff); }
        .keyhunt-grid .cell.multi { background: linear-gradient(135deg, #5f4a1e, #ffaa00); }
        .keyhunt-grid .cell.partial { background: linear-gradient(135deg, #2a2a4a, #3a3a5a); }

        .keyhunt-tooltip {
            position: fixed;
            background: rgba(20, 20, 40, 0.95);
            border: 1px solid #00d4ff;
            border-radius: 8px;
            padding: 10px;
            color: #fff;
            font-size: 11px;
            max-width: 300px;
            z-index: 10000;
            display: none;
            pointer-events: none;
        }
        .keyhunt-tooltip .row {
            display: flex;
            justify-content: space-between;
            margin: 3px 0;
        }
        .keyhunt-tooltip .label { color: #888; }
        .keyhunt-tooltip .value { font-family: monospace; }
    </style>

    <script>
    function loadKeyhuntGrid(puzzle) {
        const container = document.getElementById('keyhunt-grid-container');
        container.innerHTML = '<p style="color: #00d4ff; text-align: center;">Loading grid for Puzzle #' + puzzle + '...</p>';

        fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=keyhunt_get_grid&puzzle=' + puzzle + '&divisions=256')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    renderKeyhuntGrid(container, data.data);
                } else {
                    container.innerHTML = '<p style="color: #ff4444; text-align: center;">Error: ' + (data.data || 'Unknown error') + '</p>';
                }
            })
            .catch(err => {
                container.innerHTML = '<p style="color: #ff4444; text-align: center;">Error loading grid: ' + err.message + '</p>';
            });
    }

    function renderKeyhuntGrid(container, data) {
        let html = '<div class="keyhunt-grid">';

        data.cells.forEach((cell, index) => {
            let cellClass = 'empty';
            let sourceCount = 0;
            if (cell.local_blocks > 0) sourceCount++;
            if (cell.synced_blocks > 0) sourceCount++;
            if (cell.pool_blocks > 0) sourceCount++;
            if (cell.browser_blocks > 0) sourceCount++;

            if (sourceCount >= 2) cellClass = 'multi';
            else if (cell.local_blocks > 0) cellClass = 'local';
            else if (cell.synced_blocks > 0) cellClass = 'synced';
            else if (cell.pool_blocks > 0) cellClass = 'pool';
            else if (cell.browser_blocks > 0) cellClass = 'browser';
            else if (cell.total_pct > 0) cellClass = 'partial';

            const pct = cell.total_pct > 0 ? (cell.total_pct >= 1 ? Math.round(cell.total_pct) + '%' : '<1%') : index;

            html += '<div class="cell ' + cellClass + '" ' +
                'data-start="' + cell.start_hex + '" ' +
                'data-end="' + cell.end_hex + '" ' +
                'data-local="' + (cell.local_blocks || 0) + '" ' +
                'data-synced="' + (cell.synced_blocks || 0) + '" ' +
                'data-pool="' + (cell.pool_blocks || 0) + '" ' +
                'data-browser="' + (cell.browser_blocks || 0) + '" ' +
                'data-total="' + cell.total_pct.toFixed(4) + '" ' +
                'onmouseenter="showKeyhuntTooltip(event, this)" ' +
                'onmouseleave="hideKeyhuntTooltip()">' +
                pct + '</div>';
        });

        html += '</div>';
        html += '<div id="keyhunt-tooltip" class="keyhunt-tooltip"></div>';

        // Stats summary
        const totalPct = data.cells.reduce((sum, c) => sum + c.total_pct, 0) / data.cells.length;
        html += '<div style="margin-top: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px;">';
        html += '<strong>Coverage:</strong> ' + totalPct.toFixed(6) + '% | ';
        html += '<strong>Grid Range:</strong> 0x' + data.grid_start + ' - 0x' + data.grid_end + ' | ';
        html += '<strong>Cell Size:</strong> ' + formatKeyhuntNumber(data.cell_size) + ' keys';
        html += '</div>';

        container.innerHTML = html;
    }

    function showKeyhuntTooltip(event, cell) {
        const tooltip = document.getElementById('keyhunt-tooltip');
        if (!tooltip) return;

        tooltip.innerHTML =
            '<div class="row"><span class="label">Start:</span><span class="value">0x' + cell.dataset.start + '</span></div>' +
            '<div class="row"><span class="label">End:</span><span class="value">0x' + cell.dataset.end + '</span></div>' +
            '<hr style="border-color: #333; margin: 5px 0;">' +
            '<div class="row"><span class="label">Local Blocks:</span><span class="value" style="color: #00ff88;">' + cell.dataset.local + '</span></div>' +
            '<div class="row"><span class="label">Team Synced:</span><span class="value" style="color: #00d4ff;">' + cell.dataset.synced + '</span></div>' +
            '<div class="row"><span class="label">Pool Blocks:</span><span class="value" style="color: #4a9eff;">' + cell.dataset.pool + '</span></div>' +
            '<div class="row"><span class="label">Browser:</span><span class="value" style="color: #aa44ff;">' + cell.dataset.browser + '</span></div>' +
            '<hr style="border-color: #333; margin: 5px 0;">' +
            '<div class="row"><span class="label">Total Coverage:</span><span class="value">' + cell.dataset.total + '%</span></div>';

        tooltip.style.display = 'block';
        tooltip.style.left = (event.clientX + 15) + 'px';
        tooltip.style.top = (event.clientY + 15) + 'px';
    }

    function hideKeyhuntTooltip() {
        const tooltip = document.getElementById('keyhunt-tooltip');
        if (tooltip) tooltip.style.display = 'none';
    }

    function formatKeyhuntNumber(num) {
        if (!num) return '0';
        if (num >= 1e15) return (num / 1e15).toFixed(2) + 'P';
        if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return num.toLocaleString();
    }

    // Load grid on page load
    document.addEventListener('DOMContentLoaded', function() {
        loadKeyhuntGrid(71);
    });
    </script>
    <?php
}

/**
 * AJAX handler for grid data
 */
function keyhunt_ajax_get_grid() {
    $puzzle = intval($_GET['puzzle'] ?? 71);
    $divisions = intval($_GET['divisions'] ?? 256);

    if ($divisions < 16) $divisions = 16;
    if ($divisions > 256) $divisions = 256;

    $data = keyhunt_generate_grid_data($puzzle, $divisions);
    wp_send_json_success($data);
}
add_action('wp_ajax_keyhunt_get_grid', 'keyhunt_ajax_get_grid');
add_action('wp_ajax_nopriv_keyhunt_get_grid', 'keyhunt_ajax_get_grid');

/**
 * AJAX handler for prefix breakdown (loaded on-demand)
 */
function keyhunt_ajax_prefix_breakdown() {
    global $wpdb;

    $puzzle = intval($_GET['puzzle'] ?? 71);
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    // Define prefixes for each puzzle
    $prefixes = array();
    if ($puzzle == 71) {
        $prefixes = array(
            array('label' => '0x4', 'start' => '4000000000000000000', 'end' => '4ffffffffffffffff'),
            array('label' => '0x5', 'start' => '5000000000000000000', 'end' => '5ffffffffffffffff'),
            array('label' => '0x6', 'start' => '6000000000000000000', 'end' => '6ffffffffffffffff'),
            array('label' => '0x7', 'start' => '7000000000000000000', 'end' => '7ffffffffffffffff'),
        );
    } elseif ($puzzle == 72) {
        $prefixes = array(
            array('label' => '0x8', 'start' => '8000000000000000000', 'end' => '8ffffffffffffffff'),
            array('label' => '0x9', 'start' => '9000000000000000000', 'end' => '9ffffffffffffffff'),
            array('label' => '0xA', 'start' => 'a000000000000000000', 'end' => 'affffffffffffffff'),
            array('label' => '0xB', 'start' => 'b000000000000000000', 'end' => 'bffffffffffffffff'),
            array('label' => '0xC', 'start' => 'c000000000000000000', 'end' => 'cffffffffffffffff'),
            array('label' => '0xD', 'start' => 'd000000000000000000', 'end' => 'dffffffffffffffff'),
            array('label' => '0xE', 'start' => 'e000000000000000000', 'end' => 'effffffffffffffff'),
            array('label' => '0xF', 'start' => 'f000000000000000000', 'end' => 'ffffffffffffffffff'),
        );
    } else {
        wp_send_json_success(array()); // No prefix breakdown for other puzzles
        return;
    }

    $results = array();

    foreach ($prefixes as $prefix) {
        $range_size = gmp_sub(gmp_init($prefix['end'], 16), gmp_init($prefix['start'], 16));
        $range_size = gmp_add($range_size, gmp_init(1));

        // Use LIKE for faster prefix matching instead of >= AND <=
        $prefix_char = strtolower(substr($prefix['label'], 2, 1));

        // Count keys in this range - use simpler query with LIKE
        $range_keys = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(keys_checked) FROM $scans_table WHERE puzzle = %d AND block_start LIKE %s",
            $puzzle, $prefix_char . '%'
        )) ?: 0;

        // Count pool blocks in this range
        $pool_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d AND block_start LIKE %s",
            $puzzle, $prefix_char . '%'
        )) ?: 0;
        $pool_keys = bcmul($pool_count, '35184372088831');

        $total_range_keys = gmp_add(gmp_init($range_keys), gmp_init($pool_keys));
        $range_pct = gmp_cmp($range_size, 0) > 0 ?
            floatval(gmp_strval(gmp_mul($total_range_keys, gmp_init(10000000)))) / floatval(gmp_strval($range_size)) * 100 / 10000000 : 0;

        $results[] = array(
            'label' => $prefix['label'],
            'keys_scanned' => gmp_strval($total_range_keys),
            'keys_scanned_fmt' => keyhunt_format_keys(gmp_strval($total_range_keys)),
            'range_size' => gmp_strval($range_size),
            'range_size_fmt' => keyhunt_format_keys(gmp_strval($range_size)),
            'percentage' => $range_pct
        );
    }

    wp_send_json_success($results);
}
add_action('wp_ajax_keyhunt_prefix_breakdown', 'keyhunt_ajax_prefix_breakdown');

/**
 * AJAX handler for analytics overview (loaded on-demand)
 */
function keyhunt_ajax_analytics_overview() {
    global $wpdb;

    $puzzle = intval($_GET['puzzle'] ?? 71);
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    // Calculate puzzle keyspace
    $puzzle_start = gmp_pow(2, $puzzle - 1);
    $puzzle_end = gmp_sub(gmp_pow(2, $puzzle), 1);
    $total_keyspace = gmp_sub($puzzle_end, $puzzle_start);

    // Get master keys (optimized query)
    $master_keys = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(s.keys_checked) FROM $scans_table s
         INNER JOIN $clients_table c ON s.client_id = c.id
         WHERE s.puzzle = %d AND c.is_master = 1",
        $puzzle
    )) ?: 0;

    // Get team keys (optimized query)
    $team_keys = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(s.keys_checked) FROM $scans_table s
         INNER JOIN $clients_table c ON s.client_id = c.id
         WHERE s.puzzle = %d AND c.is_master = 0",
        $puzzle
    )) ?: 0;

    // Get browser keys
    $browser_keys_total = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(keys_checked) FROM $scans_table WHERE puzzle = %d AND source_type = 'browser'",
        $puzzle
    )) ?: 0;

    // Get pool keys (count * keys per block)
    $pool_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d",
        $puzzle
    )) ?: 0;
    $pool_keys_total = bcmul($pool_count, '35184372088831');

    // Calculate totals
    $all_keys_scanned = gmp_add(gmp_add(gmp_init($master_keys), gmp_init($team_keys)), gmp_add(gmp_init($browser_keys_total), gmp_init($pool_keys_total)));
    $keys_remaining = gmp_sub($total_keyspace, $all_keys_scanned);
    if (gmp_cmp($keys_remaining, 0) < 0) $keys_remaining = gmp_init(0);

    // Calculate percentages
    $total_keyspace_float = floatval(gmp_strval($total_keyspace));
    $master_pct = $total_keyspace_float > 0 ? (floatval($master_keys) / $total_keyspace_float) * 100 : 0;
    $team_pct = $total_keyspace_float > 0 ? (floatval($team_keys) / $total_keyspace_float) * 100 : 0;
    $browser_pct = $total_keyspace_float > 0 ? (floatval($browser_keys_total) / $total_keyspace_float) * 100 : 0;
    $pool_pct = $total_keyspace_float > 0 ? (floatval($pool_keys_total) / $total_keyspace_float) * 100 : 0;
    $total_pct = $master_pct + $team_pct + $browser_pct + $pool_pct;

    // Get recent scans (last 100) - single optimized query
    $recent_scans = $wpdb->get_results($wpdb->prepare(
        "SELECT s.*, c.client_name, c.is_master
         FROM $scans_table s
         LEFT JOIN $clients_table c ON s.client_id = c.id
         WHERE s.puzzle = %d
         ORDER BY s.scanned_at DESC
         LIMIT 100",
        $puzzle
    ), ARRAY_A);

    // Format recent scans for JSON
    $formatted_scans = array();
    foreach ($recent_scans as $scan) {
        $formatted_scans[] = array(
            'time' => date('M j H:i', strtotime($scan['scanned_at'])),
            'client_name' => substr($scan['client_name'] ?? 'Unknown', 0, 20),
            'is_master' => (bool)$scan['is_master'],
            'block_start' => substr($scan['block_start'], 0, 12),
            'block_end' => substr($scan['block_end'], 0, 12),
            'keys_checked' => keyhunt_format_keys($scan['keys_checked']),
            'completion_pct' => floatval($scan['completion_pct'] ?? 100)
        );
    }

    wp_send_json_success(array(
        'master_keys' => keyhunt_format_keys($master_keys),
        'master_pct' => number_format($master_pct, 8),
        'team_keys' => keyhunt_format_keys($team_keys),
        'team_pct' => number_format($team_pct, 8),
        'browser_keys' => keyhunt_format_keys($browser_keys_total),
        'browser_pct' => number_format($browser_pct, 8),
        'pool_keys' => keyhunt_format_keys($pool_keys_total),
        'pool_pct' => number_format($pool_pct, 8),
        'total_keyspace' => keyhunt_format_keys(gmp_strval($total_keyspace)),
        'all_keys_scanned' => keyhunt_format_keys(gmp_strval($all_keys_scanned)),
        'keys_remaining' => keyhunt_format_keys(gmp_strval($keys_remaining)),
        'total_pct' => number_format($total_pct, 8),
        'chart_data' => array(
            'master' => min(floatval($master_keys), 9007199254740991),
            'team' => min(floatval($team_keys), 9007199254740991),
            'browser' => min(floatval($browser_keys_total), 9007199254740991),
            'pool' => min(floatval($pool_keys_total), 9007199254740991)
        ),
        'progress_bars' => array(
            'master' => min($master_pct * 100, 25),
            'team' => min($team_pct * 100, 25),
            'browser' => min($browser_pct * 100, 25),
            'pool' => min($pool_pct * 100, 25)
        ),
        'recent_scans' => $formatted_scans
    ));
}
add_action('wp_ajax_keyhunt_analytics_overview', 'keyhunt_ajax_analytics_overview');

/**
 * Generate grid data for a puzzle
 */
function keyhunt_generate_grid_data($puzzle, $divisions = 256) {
    global $wpdb;

    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    // Calculate puzzle range
    $grid_start = gmp_pow(2, $puzzle - 1);
    $grid_end = gmp_sub(gmp_pow(2, $puzzle), 1);
    $grid_size = gmp_sub($grid_end, $grid_start);
    $cell_size = gmp_div($grid_size, $divisions);

    // Get all scanned blocks for this puzzle
    $scans = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start, block_end, source_type, client_id FROM $scans_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    // Get pool blocks
    $pool_blocks = $wpdb->get_results($wpdb->prepare(
        "SELECT block_start, block_end FROM $pool_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    // Get my client_id (for local vs synced distinction - admin sees all as "local" essentially)
    // In shortcode context, we might want to distinguish based on viewer

    $cells = array();

    for ($i = 0; $i < $divisions; $i++) {
        $cell_start = gmp_add($grid_start, gmp_mul($cell_size, $i));
        $cell_end = gmp_add($cell_start, gmp_sub($cell_size, 1));

        $local_blocks = 0;
        $synced_blocks = 0;
        $pool_block_count = 0;
        $browser_blocks = 0;
        $coverage = gmp_init(0);

        // Check scanned blocks
        foreach ($scans as $scan) {
            $b_start = gmp_init($scan['block_start'], 16);
            $b_end = gmp_init($scan['block_end'], 16);

            // Check overlap
            if (gmp_cmp($b_start, $cell_end) <= 0 && gmp_cmp($b_end, $cell_start) >= 0) {
                $overlap_start = gmp_cmp($cell_start, $b_start) > 0 ? $cell_start : $b_start;
                $overlap_end = gmp_cmp($cell_end, $b_end) < 0 ? $cell_end : $b_end;
                $overlap_size = gmp_add(gmp_sub($overlap_end, $overlap_start), 1);
                $coverage = gmp_add($coverage, $overlap_size);

                $source = $scan['source_type'] ?? 'visualizer';
                if ($source === 'browser') {
                    $browser_blocks++;
                } elseif ($source === 'server' || $source === 'synced') {
                    $synced_blocks++;
                } else {
                    $local_blocks++;
                }
            }
        }

        // Check pool blocks
        foreach ($pool_blocks as $pool) {
            $b_start = gmp_init($pool['block_start'], 16);
            $b_end = gmp_init($pool['block_end'], 16);

            if (gmp_cmp($b_start, $cell_end) <= 0 && gmp_cmp($b_end, $cell_start) >= 0) {
                $pool_block_count++;
                // Pool blocks are typically large, add their coverage
                $overlap_start = gmp_cmp($cell_start, $b_start) > 0 ? $cell_start : $b_start;
                $overlap_end = gmp_cmp($cell_end, $b_end) < 0 ? $cell_end : $b_end;
                $overlap_size = gmp_add(gmp_sub($overlap_end, $overlap_start), 1);
                $coverage = gmp_add($coverage, $overlap_size);
            }
        }

        // Calculate percentage
        $pct = 0;
        if (gmp_cmp($cell_size, 0) > 0) {
            $pct = floatval(gmp_strval(gmp_mul($coverage, 100))) / floatval(gmp_strval($cell_size));
            if ($pct > 100) $pct = 100;
        }

        $cells[] = array(
            'index' => $i,
            'start_hex' => strtoupper(gmp_strval($cell_start, 16)),
            'end_hex' => strtoupper(gmp_strval($cell_end, 16)),
            'local_blocks' => $local_blocks,
            'synced_blocks' => $synced_blocks,
            'pool_blocks' => $pool_block_count,
            'browser_blocks' => $browser_blocks,
            'total_pct' => round($pct, 6)
        );
    }

    return array(
        'puzzle' => $puzzle,
        'grid_start' => strtoupper(gmp_strval($grid_start, 16)),
        'grid_end' => strtoupper(gmp_strval($grid_end, 16)),
        'cell_size' => floatval(gmp_strval($cell_size)),
        'divisions' => $divisions,
        'cells' => $cells
    );
}

// ============================================================================
// SHORTCODES
// ============================================================================

/**
 * Shortcode: [keyhunt_grid puzzle="71" divisions="16"]
 * Displays the visual grid for a puzzle
 */
function keyhunt_shortcode_grid($atts) {
    $atts = shortcode_atts(array(
        'puzzle' => 71,
        'divisions' => 16,
        'height' => '400px'
    ), $atts);

    $puzzle = intval($atts['puzzle']);
    $divisions = intval($atts['divisions']);
    if ($divisions < 4) $divisions = 4;
    if ($divisions > 64) $divisions = 64; // Limit for frontend performance

    $unique_id = 'keyhunt-grid-' . uniqid();

    ob_start();
    ?>
    <style>
        .keyhunt-frontend-grid {
            display: grid;
            grid-template-columns: repeat(<?php echo $divisions; ?>, 1fr);
            gap: 2px;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            padding: 15px;
            border-radius: 10px;
            max-width: 100%;
        }
        .keyhunt-frontend-grid .cell {
            aspect-ratio: 1;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            color: #fff;
            text-shadow: 0 0 2px #000;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            min-height: 25px;
            font-family: monospace;
        }
        .keyhunt-frontend-grid .cell:hover {
            transform: scale(1.15);
            box-shadow: 0 0 15px rgba(0, 212, 255, 0.6);
            z-index: 10;
        }
        .keyhunt-frontend-grid .cell.empty { background: #1a1a2e; border: 1px solid #333; }
        .keyhunt-frontend-grid .cell.local { background: linear-gradient(135deg, #1e5f3a, #00ff88); }
        .keyhunt-frontend-grid .cell.synced { background: linear-gradient(135deg, #2a4a5f, #00d4ff); }
        .keyhunt-frontend-grid .cell.pool { background: linear-gradient(135deg, #1e3a5f, #4a9eff); }
        .keyhunt-frontend-grid .cell.browser { background: linear-gradient(135deg, #4a1e5f, #aa44ff); }
        .keyhunt-frontend-grid .cell.multi { background: linear-gradient(135deg, #5f4a1e, #ffaa00); }

        .keyhunt-legend {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 15px;
            font-size: 12px;
            color: #666;
        }
        .keyhunt-legend-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .keyhunt-legend-color {
            width: 16px;
            height: 16px;
            border-radius: 3px;
        }

        .keyhunt-tooltip-frontend {
            position: fixed;
            background: rgba(20, 20, 40, 0.95);
            border: 1px solid #00d4ff;
            border-radius: 8px;
            padding: 12px;
            color: #fff;
            font-size: 11px;
            max-width: 280px;
            z-index: 99999;
            display: none;
            pointer-events: none;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5);
        }
        .keyhunt-tooltip-frontend .row {
            display: flex;
            justify-content: space-between;
            margin: 4px 0;
        }
        .keyhunt-tooltip-frontend .label { color: #888; }
        .keyhunt-tooltip-frontend .value { font-family: monospace; }
    </style>

    <div id="<?php echo $unique_id; ?>-container" style="margin: 20px 0;">
        <div style="text-align: center; padding: 20px; color: #00d4ff;">Loading Puzzle #<?php echo $puzzle; ?> grid...</div>
    </div>
    <div id="<?php echo $unique_id; ?>-tooltip" class="keyhunt-tooltip-frontend"></div>

    <script>
    (function() {
        const container = document.getElementById('<?php echo $unique_id; ?>-container');
        const tooltip = document.getElementById('<?php echo $unique_id; ?>-tooltip');

        fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=keyhunt_get_grid&puzzle=<?php echo $puzzle; ?>&divisions=<?php echo $divisions; ?>')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    renderGrid(data.data);
                } else {
                    container.innerHTML = '<p style="color: #ff4444; text-align: center;">Error loading grid</p>';
                }
            })
            .catch(err => {
                container.innerHTML = '<p style="color: #ff4444; text-align: center;">Error: ' + err.message + '</p>';
            });

        function renderGrid(data) {
            let html = '<h3 style="margin-bottom: 10px; color: #333;">Puzzle #' + data.puzzle + ' - Keyspace Coverage</h3>';
            html += '<div class="keyhunt-frontend-grid">';

            data.cells.forEach((cell, index) => {
                let cellClass = 'empty';
                let sourceCount = 0;
                if (cell.local_blocks > 0) sourceCount++;
                if (cell.synced_blocks > 0) sourceCount++;
                if (cell.pool_blocks > 0) sourceCount++;
                if (cell.browser_blocks > 0) sourceCount++;

                if (sourceCount >= 2) cellClass = 'multi';
                else if (cell.local_blocks > 0) cellClass = 'local';
                else if (cell.synced_blocks > 0) cellClass = 'synced';
                else if (cell.pool_blocks > 0) cellClass = 'pool';
                else if (cell.browser_blocks > 0) cellClass = 'browser';

                const pct = cell.total_pct > 0 ? (cell.total_pct >= 1 ? Math.round(cell.total_pct) + '%' : '<1%') : '';

                html += '<div class="cell ' + cellClass + '" ' +
                    'data-start="' + cell.start_hex + '" ' +
                    'data-end="' + cell.end_hex + '" ' +
                    'data-local="' + (cell.local_blocks || 0) + '" ' +
                    'data-synced="' + (cell.synced_blocks || 0) + '" ' +
                    'data-pool="' + (cell.pool_blocks || 0) + '" ' +
                    'data-browser="' + (cell.browser_blocks || 0) + '" ' +
                    'data-total="' + cell.total_pct.toFixed(4) + '">' +
                    pct + '</div>';
            });

            html += '</div>';

            // Legend
            html += '<div class="keyhunt-legend">';
            html += '<div class="keyhunt-legend-item"><div class="keyhunt-legend-color" style="background: linear-gradient(135deg, #1e5f3a, #00ff88);"></div> Local Scans</div>';
            html += '<div class="keyhunt-legend-item"><div class="keyhunt-legend-color" style="background: linear-gradient(135deg, #2a4a5f, #00d4ff);"></div> Team Synced</div>';
            html += '<div class="keyhunt-legend-item"><div class="keyhunt-legend-color" style="background: linear-gradient(135deg, #1e3a5f, #4a9eff);"></div> Pool Data</div>';
            html += '<div class="keyhunt-legend-item"><div class="keyhunt-legend-color" style="background: linear-gradient(135deg, #4a1e5f, #aa44ff);"></div> Browser</div>';
            html += '<div class="keyhunt-legend-item"><div class="keyhunt-legend-color" style="background: linear-gradient(135deg, #5f4a1e, #ffaa00);"></div> Multiple</div>';
            html += '<div class="keyhunt-legend-item"><div class="keyhunt-legend-color" style="background: #1a1a2e; border: 1px solid #444;"></div> Unscanned</div>';
            html += '</div>';

            // Stats
            const totalPct = data.cells.reduce((sum, c) => sum + c.total_pct, 0) / data.cells.length;
            html += '<div style="margin-top: 15px; padding: 12px; background: #f0f0f0; border-radius: 5px; font-size: 13px;">';
            html += '<strong>Total Coverage:</strong> ' + totalPct.toFixed(6) + '%';
            html += '</div>';

            container.innerHTML = html;

            // Add tooltip handlers
            container.querySelectorAll('.cell').forEach(cell => {
                cell.addEventListener('mouseenter', function(e) {
                    tooltip.innerHTML =
                        '<div class="row"><span class="label">Range Start:</span><span class="value">0x' + this.dataset.start.substring(0, 12) + '...</span></div>' +
                        '<div class="row"><span class="label">Range End:</span><span class="value">0x' + this.dataset.end.substring(0, 12) + '...</span></div>' +
                        '<hr style="border-color: #333; margin: 8px 0;">' +
                        '<div class="row"><span class="label">Local Blocks:</span><span class="value" style="color: #00ff88;">' + this.dataset.local + '</span></div>' +
                        '<div class="row"><span class="label">Team Synced:</span><span class="value" style="color: #00d4ff;">' + this.dataset.synced + '</span></div>' +
                        '<div class="row"><span class="label">Pool Blocks:</span><span class="value" style="color: #4a9eff;">' + this.dataset.pool + '</span></div>' +
                        '<div class="row"><span class="label">Browser:</span><span class="value" style="color: #aa44ff;">' + this.dataset.browser + '</span></div>' +
                        '<hr style="border-color: #333; margin: 8px 0;">' +
                        '<div class="row"><span class="label">Coverage:</span><span class="value" style="color: #ffaa00;">' + this.dataset.total + '%</span></div>';
                    tooltip.style.display = 'block';
                    tooltip.style.left = (e.clientX + 15) + 'px';
                    tooltip.style.top = (e.clientY + 15) + 'px';
                });
                cell.addEventListener('mousemove', function(e) {
                    tooltip.style.left = (e.clientX + 15) + 'px';
                    tooltip.style.top = (e.clientY + 15) + 'px';
                });
                cell.addEventListener('mouseleave', function() {
                    tooltip.style.display = 'none';
                });
            });
        }
    })();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('keyhunt_grid', 'keyhunt_shortcode_grid');

/**
 * Shortcode: [keyhunt_stats]
 * Displays overall statistics
 */
function keyhunt_shortcode_stats($atts) {
    global $wpdb;

    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $total_scans = $wpdb->get_var("SELECT COUNT(*) FROM $scans_table");
    $total_keys = $wpdb->get_var("SELECT SUM(keys_checked) FROM $scans_table");
    $total_pool = $wpdb->get_var("SELECT COUNT(*) FROM $pool_table");
    $total_clients = $wpdb->get_var("SELECT COUNT(*) FROM $clients_table");
    $active_clients = $wpdb->get_var("SELECT COUNT(*) FROM $clients_table WHERE last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE)");

    ob_start();
    ?>
    <div class="keyhunt-stats-widget" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 20px; border-radius: 10px; color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <h3 style="color: #00d4ff; margin-top: 0; border-bottom: 1px solid #333; padding-bottom: 10px;">KeyHunt Mining Statistics</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 15px;">
            <div style="background: rgba(0,255,136,0.1); padding: 15px; border-radius: 8px; text-align: center; border: 1px solid rgba(0,255,136,0.3);">
                <div style="font-size: 24px; font-weight: bold; color: #00ff88;"><?php echo keyhunt_format_keys($total_keys); ?></div>
                <div style="font-size: 11px; color: #888;">Keys Checked</div>
            </div>
            <div style="background: rgba(0,212,255,0.1); padding: 15px; border-radius: 8px; text-align: center; border: 1px solid rgba(0,212,255,0.3);">
                <div style="font-size: 24px; font-weight: bold; color: #00d4ff;"><?php echo number_format($total_scans); ?></div>
                <div style="font-size: 11px; color: #888;">Blocks Scanned</div>
            </div>
            <div style="background: rgba(255,153,0,0.1); padding: 15px; border-radius: 8px; text-align: center; border: 1px solid rgba(255,153,0,0.3);">
                <div style="font-size: 24px; font-weight: bold; color: #ff9900;"><?php echo number_format($total_pool); ?></div>
                <div style="font-size: 11px; color: #888;">Pool Blocks</div>
            </div>
            <div style="background: rgba(170,68,255,0.1); padding: 15px; border-radius: 8px; text-align: center; border: 1px solid rgba(170,68,255,0.3);">
                <div style="font-size: 24px; font-weight: bold; color: #aa44ff;"><?php echo $active_clients; ?> / <?php echo $total_clients; ?></div>
                <div style="font-size: 11px; color: #888;">Active / Total Clients</div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('keyhunt_stats', 'keyhunt_shortcode_stats');

/**
 * Shortcode: [keyhunt_progress puzzle="71"]
 * Displays a progress bar for a puzzle
 */
function keyhunt_shortcode_progress($atts) {
    global $wpdb;

    $atts = shortcode_atts(array(
        'puzzle' => 71,
        'show_keys' => 'true'
    ), $atts);

    $puzzle = intval($atts['puzzle']);
    $show_keys = $atts['show_keys'] === 'true';

    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $pool_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_POOL;

    // Get stats for this puzzle
    $scan_stats = $wpdb->get_row($wpdb->prepare(
        "SELECT COUNT(*) as blocks, SUM(keys_checked) as keys_checked FROM $scans_table WHERE puzzle = %d",
        $puzzle
    ), ARRAY_A);

    $pool_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $pool_table WHERE puzzle = %d",
        $puzzle
    ));

    // Calculate total keyspace for puzzle
    $total_keyspace = gmp_sub(gmp_pow(2, $puzzle), gmp_pow(2, $puzzle - 1));
    $total_keyspace_str = gmp_strval($total_keyspace);

    // Calculate coverage percentage (rough estimate based on blocks)
    $keys_checked = floatval($scan_stats['keys_checked'] ?? 0);
    $total_ks = floatval($total_keyspace_str);
    $coverage_pct = $total_ks > 0 ? ($keys_checked / $total_ks) * 100 : 0;
    if ($coverage_pct > 100) $coverage_pct = 100;

    ob_start();
    ?>
    <div class="keyhunt-progress-widget" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 20px; border-radius: 10px; color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <h4 style="color: #00d4ff; margin: 0;">Puzzle #<?php echo $puzzle; ?></h4>
            <span style="color: #888; font-size: 12px;"><?php echo number_format($scan_stats['blocks'] ?? 0); ?> blocks scanned</span>
        </div>

        <div style="background: #0a0a1a; border-radius: 10px; height: 30px; overflow: hidden; position: relative;">
            <div style="background: linear-gradient(90deg, #00ff88 0%, #00cc6a 100%); height: 100%; width: <?php echo min(100, $coverage_pct); ?>%; transition: width 0.5s; border-radius: 10px;"></div>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; font-weight: bold; text-shadow: 0 0 5px #000;">
                <?php echo number_format($coverage_pct, 8); ?>%
            </div>
        </div>

        <?php if ($show_keys): ?>
        <div style="display: flex; justify-content: space-between; margin-top: 12px; font-size: 12px;">
            <div>
                <span style="color: #00ff88;"><?php echo keyhunt_format_keys($keys_checked); ?></span>
                <span style="color: #666;"> keys checked</span>
            </div>
            <div>
                <span style="color: #ff9900;"><?php echo number_format($pool_count); ?></span>
                <span style="color: #666;"> pool blocks</span>
            </div>
            <div>
                <span style="color: #888;">Total: <?php echo keyhunt_format_keys($total_keyspace_str); ?> keys</span>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('keyhunt_progress', 'keyhunt_shortcode_progress');

/**
 * Shortcode: [keyhunt_clients]
 * Displays connected clients
 */
function keyhunt_shortcode_clients($atts) {
    global $wpdb;

    $atts = shortcode_atts(array(
        'show_offline' => 'false'
    ), $atts);

    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;
    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;

    $where = $atts['show_offline'] === 'true' ? '' : 'WHERE last_seen > DATE_SUB(NOW(), INTERVAL 1 HOUR)';

    $clients = $wpdb->get_results(
        "SELECT c.*,
                TIMESTAMPDIFF(MINUTE, c.last_seen, NOW()) as minutes_ago,
                (SELECT SUM(keys_checked) FROM $scans_table WHERE client_id = c.client_id) as actual_keys
         FROM $clients_table c $where
         ORDER BY c.last_seen DESC",
        ARRAY_A
    );

    ob_start();
    ?>
    <div class="keyhunt-clients-widget" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 20px; border-radius: 10px; color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <h3 style="color: #00d4ff; margin-top: 0; border-bottom: 1px solid #333; padding-bottom: 10px;">Connected Miners</h3>

        <?php if (empty($clients)): ?>
            <p style="color: #888; text-align: center;">No active clients</p>
        <?php else: ?>
            <div style="display: grid; gap: 10px;">
                <?php foreach ($clients as $client): ?>
                <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-weight: bold; color: #fff;">
                            <?php if ($client['minutes_ago'] < 10): ?>
                                <span style="color: #00ff88;">●</span>
                            <?php elseif ($client['minutes_ago'] < 60): ?>
                                <span style="color: #ffaa00;">●</span>
                            <?php else: ?>
                                <span style="color: #666;">○</span>
                            <?php endif; ?>
                            <?php echo esc_html($client['client_name'] ?: $client['client_id']); ?>
                        </div>
                        <div style="font-size: 11px; color: #888;">
                            Last seen: <?php echo $client['minutes_ago']; ?> min ago
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="color: #00ff88; font-weight: bold;"><?php echo keyhunt_format_keys($client['actual_keys'] ?: $client['total_keys_checked']); ?></div>
                        <div style="font-size: 11px; color: #888;"><?php echo number_format($client['blocks_submitted']); ?> blocks</div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('keyhunt_clients', 'keyhunt_shortcode_clients');

/**
 * Shortcode: [keyhunt_leaderboard limit="10"]
 * Displays top contributors
 */
function keyhunt_shortcode_leaderboard($atts) {
    global $wpdb;

    $atts = shortcode_atts(array(
        'limit' => 10,
        'puzzle' => ''
    ), $atts);

    $limit = intval($atts['limit']);
    $puzzle_filter = !empty($atts['puzzle']) ? intval($atts['puzzle']) : null;

    $scans_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_SCANS;
    $clients_table = $wpdb->prefix . KEYHUNT_SYNC_TABLE_CLIENTS;

    $where = $puzzle_filter ? $wpdb->prepare("WHERE s.puzzle = %d", $puzzle_filter) : '';

    $leaderboard = $wpdb->get_results($wpdb->prepare(
        "SELECT
            s.client_id,
            c.client_name,
            SUM(s.keys_checked) as total_keys,
            COUNT(*) as total_blocks,
            MAX(s.scanned_at) as last_activity
         FROM $scans_table s
         LEFT JOIN $clients_table c ON s.client_id = c.client_id
         $where
         GROUP BY s.client_id
         ORDER BY total_keys DESC
         LIMIT %d",
        $limit
    ), ARRAY_A);

    ob_start();
    ?>
    <div class="keyhunt-leaderboard-widget" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 20px; border-radius: 10px; color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <h3 style="color: #00d4ff; margin-top: 0; border-bottom: 1px solid #333; padding-bottom: 10px;">
            🏆 Top Contributors
            <?php if ($puzzle_filter): ?><span style="color: #888; font-size: 14px;"> - Puzzle #<?php echo $puzzle_filter; ?></span><?php endif; ?>
        </h3>

        <?php if (empty($leaderboard)): ?>
            <p style="color: #888; text-align: center;">No data yet</p>
        <?php else: ?>
            <div style="display: grid; gap: 8px;">
                <?php foreach ($leaderboard as $rank => $entry): ?>
                <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; display: flex; align-items: center; gap: 15px;
                    <?php if ($rank === 0): ?>border: 1px solid gold; background: rgba(255, 215, 0, 0.1);<?php endif; ?>
                    <?php if ($rank === 1): ?>border: 1px solid silver; background: rgba(192, 192, 192, 0.1);<?php endif; ?>
                    <?php if ($rank === 2): ?>border: 1px solid #cd7f32; background: rgba(205, 127, 50, 0.1);<?php endif; ?>
                ">
                    <div style="font-size: 20px; font-weight: bold; width: 35px; text-align: center;
                        <?php if ($rank === 0): ?>color: gold;<?php elseif ($rank === 1): ?>color: silver;<?php elseif ($rank === 2): ?>color: #cd7f32;<?php else: ?>color: #666;<?php endif; ?>
                    ">
                        <?php if ($rank < 3): ?>
                            <?php echo array('🥇', '🥈', '🥉')[$rank]; ?>
                        <?php else: ?>
                            #<?php echo $rank + 1; ?>
                        <?php endif; ?>
                    </div>
                    <div style="flex: 1;">
                        <div style="font-weight: bold; color: #fff;"><?php echo esc_html($entry['client_name'] ?: substr($entry['client_id'], 0, 8)); ?></div>
                        <div style="font-size: 11px; color: #888;"><?php echo number_format($entry['total_blocks']); ?> blocks</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="color: #00ff88; font-weight: bold; font-size: 16px;"><?php echo keyhunt_format_keys($entry['total_keys']); ?></div>
                        <div style="font-size: 10px; color: #888;">keys checked</div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('keyhunt_leaderboard', 'keyhunt_shortcode_leaderboard');
